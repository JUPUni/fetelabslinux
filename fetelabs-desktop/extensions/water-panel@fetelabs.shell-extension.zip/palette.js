// SPDX-License-Identifier: GPL-2.0-or-later
// Picks the liquid's colours from the wallpaper. The most prominent vivid
// hue wins, weighted toward the bottom of the image where the taskbar sits,
// and keeps that colour's own saturation and brightness so a navy wallpaper
// and a turquoise one don't both come out the same blue. A second, distinct
// hue (if the wallpaper has one) becomes the foam line on the surface.
// Grey or washed-out wallpapers fall back to ocean blue.

import Gio from 'gi://Gio'
import GLib from 'gi://GLib'
import GdkPixbuf from 'gi://GdkPixbuf'

export const OCEAN = {
  deep: [0.02, 0.28, 0.62],
  shallow: [0.1, 0.72, 0.95],
  foam: [0.72, 0.95, 1.0],
  // The Fetelabs wordmark: fetelabs.ai's lime, pink and gold, bright over blue.
  glyphA: [0.61, 0.89, 0.18],
  glyphB: [1.0, 0.45, 0.68],
  glyphC: [1.0, 0.78, 0.2],
}

// The default single colour; picking it gives the hand-tuned OCEAN exactly.
export const OCEAN_HEX = '#1AB8F2'

// Returned when a wallpaper has no real colour, so the caller can use the
// user's own fallback colour instead.
const GREY = { ...OCEAN, grey: true }

const HUE_BINS = 36
const MIN_VIVID_SHARE = 0.00175 // below this much (chroma-weighted) colour, use OCEAN
const MIN_STRIKING_SHARE = 0.0005 // lower bar for a small but vivid subject (red torii on white)
const BOTTOM_WEIGHT = 1.2 // extra weight for the bottom rows, next to the taskbar
const ACCENT_MIN_DIST = 5 // bins (50°) between main and accent hue
const ACCENT_MIN_SHARE = 0.3 // accent must score this fraction of the main hue
const SAMPLE_SIZE = 160
const GLYPH_MIN_SHARE = 0.01 // a lesser colour must score this fraction of the main one
const GLYPH_MIN_DIST = 0.2 // wordmark hues sit at least 72° round the wheel from the water's
const GLYPH_APART = 0.1 // and 36° from each other
const ALGO_VERSION = 7 // bump when the colour maths changes, so cached palettes refresh

const SHADOW_HUE = 0.72 // violet
const LIGHT_HUE = 0.14 // warm sunlight

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v))

// Move hue h up to `amount` of the colour wheel toward `to`, the short way round.
function hueToward(h, to, amount) {
  const diff = ((to - h + 1.5) % 1) - 0.5
  return (h + Math.sign(diff) * Math.min(amount, Math.abs(diff)) + 1) % 1
}

function hsvToRgb(h, s, v) {
  const f = (n) => {
    const k = (n + h * 6) % 6
    return v - v * s * Math.max(0, Math.min(k, 4 - k, 1))
  }
  return [f(5), f(3), f(1)]
}

// Hue histogram: per-bin weight plus the sums needed for a cluster's
// average hue, saturation and brightness.
class HueBins {
  constructor() {
    this.weight = new Float64Array(HUE_BINS)
    this.x = new Float64Array(HUE_BINS)
    this.y = new Float64Array(HUE_BINS)
    this.sat = new Float64Array(HUE_BINS)
    this.val = new Float64Array(HUE_BINS)
  }

  add(bin, hue, s, v, wgt) {
    this.weight[bin] += wgt
    this.x[bin] += Math.cos(hue * 2 * Math.PI) * wgt
    this.y[bin] += Math.sin(hue * 2 * Math.PI) * wgt
    this.sat[bin] += s * wgt
    this.val[bin] += v * wgt
  }

  // A bin together with its neighbours, so a spread-out colour isn't beaten
  // by one narrow spike.
  score(i) {
    const w = this.weight
    return w[(i + HUE_BINS - 1) % HUE_BINS] * 0.5 + w[i] + w[(i + 1) % HUE_BINS] * 0.5
  }

  // Best-scoring bin at least ACCENT_MIN_DIST away from every bin in skip.
  best(skip = []) {
    let best = -1
    let bestScore = 0
    for (let i = 0; i < HUE_BINS; i++) {
      const near = skip.some((k) => k >= 0 &&
        Math.min(Math.abs(i - k), HUE_BINS - Math.abs(i - k)) < ACCENT_MIN_DIST)
      if (near) continue
      const sc = this.score(i)
      if (sc > bestScore) {
        bestScore = sc
        best = i
      }
    }
    return [best, bestScore]
  }

  cluster(c) {
    let x = 0, y = 0, wt = 0, s = 0, v = 0
    for (const i of [c - 1, c, c + 1]) {
      const j = (i + HUE_BINS) % HUE_BINS
      x += this.x[j]
      y += this.y[j]
      wt += this.weight[j]
      s += this.sat[j]
      v += this.val[j]
    }
    return {
      hue: ((Math.atan2(y, x) / (2 * Math.PI)) + 1) % 1,
      sat: s / wt,
      val: v / wt,
    }
  }
}

export function paletteFromPixbuf(pb) {
  const px = pb.get_pixels()
  const stride = pb.get_rowstride()
  const nc = pb.get_n_channels()
  const w = pb.get_width()
  const h = pb.get_height()
  // The main colour is picked by how much of the picture it covers; the foam
  // accent by vividness (chroma squared), so a small bright subject such as
  // pink blossoms or a red gate still gets its moment.
  const area = new HueBins()
  const vivid = new HueBins()
  let total = 0

  for (let y = 0; y < h; y++) {
    const yf = y / (h - 1 || 1)
    const rowW = 1 + BOTTOM_WEIGHT * yf * yf
    for (let x = 0; x < w; x++) {
      const o = y * stride + x * nc
      const r = px[o] / 255
      const g = px[o + 1] / 255
      const b = px[o + 2] / 255
      const max = Math.max(r, g, b)
      const min = Math.min(r, g, b)
      total += rowW
      const d = max - min
      const s = max ? d / max : 0
      if (s < 0.2 || max < 0.08) continue

      let hue
      if (max === r) hue = ((g - b) / d + 6) % 6
      else if (max === g) hue = (b - r) / d + 2
      else hue = (r - g) / d + 4
      hue /= 6

      const bin = Math.floor(hue * HUE_BINS) % HUE_BINS
      area.add(bin, hue, s, max, d * rowW)
      vivid.add(bin, hue, s, max, d * d * rowW)
    }
  }

  // Grey test on vividness: faint tints don't count, a small vivid subject does.
  const [vBest, vScore] = vivid.best()
  if (vBest < 0 || vScore / total < MIN_STRIKING_SHARE) return GREY
  const vMain = vivid.cluster(vBest)
  const striking = vMain.sat > 0.4 && vMain.val > 0.45
  if (!striking && vScore / total < MIN_VIVID_SHARE) return GREY

  const [best] = area.best()
  const main = area.cluster(best)

  const [accent, accentScore] = vivid.best([best])
  const acc = accent >= 0 && accentScore >= vivid.score(best) * ACCENT_MIN_SHARE
    ? vivid.cluster(accent)
    : null

  // The wordmark takes the wallpaper's lesser colours, the ones furthest
  // round the wheel from the water, so it pops out of it. Ranked by how far
  // away they are times how vivid, not by how much of the picture they cover.
  const lesser = []
  for (let i = 0; i < HUE_BINS; i++) {
    const sc = vivid.score(i)
    if (!vivid.weight[i] || sc < vivid.score(vBest) * GLYPH_MIN_SHARE) continue
    const c = vivid.cluster(i)
    if (hueDist(c.hue, main.hue) < GLYPH_MIN_DIST || c.sat < 0.25) continue
    lesser.push({ ...c, rank: Math.sqrt(sc) * (0.4 + hueDist(c.hue, main.hue)) })
  }
  lesser.sort((x, y) => y.rank - x.rank)

  return buildPalette(main, acc, lesser)
}

const hueDist = (a, b) => Math.min(Math.abs(a - b), 1 - Math.abs(a - b))

// A lesser colour made vivid and bright enough to pop through the water.
const glyphTone = ({ hue, sat, val }) => hsvToRgb(hue, clamp(sat * 1.25, 0.62, 0.92), clamp(val * 1.4, 0.95, 1))

// Three wordmark colours, all well away from the water's hue and from each
// other: the wallpaper's own where it has them, then the water's complement
// and its split-complements.
function glyphColours(hue, lesser) {
  const picks = []
  const fits = (h) => hueDist(h, hue) >= GLYPH_MIN_DIST && picks.every((p) => hueDist(p.hue, h) >= GLYPH_APART)
  for (const c of lesser) if (picks.length < 3 && fits(c.hue)) picks.push(c)
  for (const d of [0.5, 0.36, 0.64, 0.28, 0.72]) {
    const h = (hue + d) % 1
    if (picks.length < 3 && fits(h)) picks.push({ hue: h, sat: 0.8, val: 1 })
  }
  return picks.map(glyphTone)
}

// Painter's gradient: the depths lean toward violet and the surface toward
// warm light, instead of just darkening one hue (which turns orange brown
// and yellow olive).
function buildPalette(main, acc, lesser = []) {
  const { hue, sat, val } = main
  const [glyphA, glyphB, glyphC] = glyphColours(hue, [...lesser, ...(acc ? [acc] : [])])
  return {
    glyphA,
    glyphB,
    glyphC,
    deep: hsvToRgb(hueToward(hue, SHADOW_HUE, 0.06), clamp(sat + 0.1, 0.72, 1), clamp(val * 0.75, 0.48, 0.72)),
    shallow: hsvToRgb(hueToward(hue, LIGHT_HUE, 0.025), clamp(sat * 1.05, 0.55, 0.9), clamp(val * 1.4, 0.9, 1)),
    foam: acc
      ? hsvToRgb(acc.hue, clamp(acc.sat * 0.55, 0.25, 0.5), 1)
      : hsvToRgb(hueToward(hue, LIGHT_HUE, 0.04), 0.25, 1),
  }
}

export function parseHex(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec((hex || '').trim())
  if (!m) return null
  return [0, 2, 4].map((i) => parseInt(m[1].slice(i, i + 2), 16) / 255)
}

function rgbToHsv([r, g, b]) {
  const max = Math.max(r, g, b)
  const d = max - Math.min(r, g, b)
  let hue = 0
  if (d) {
    if (max === r) hue = ((g - b) / d + 6) % 6
    else if (max === g) hue = (b - r) / d + 2
    else hue = (r - g) / d + 4
  }
  return { hue: hue / 6, sat: max ? d / max : 0, val: max }
}

// Palette built around one colour the user picked.
export function paletteFromColor(hex) {
  const rgb = parseHex(hex)
  if (!rgb || hex.trim().toUpperCase() === OCEAN_HEX) return OCEAN
  return buildPalette(rgbToHsv(rgb), null)
}

// A colour pinned to one wallpaper: "#surface" or "#surface #depths". The
// wallpaper's own accent stays as the foam line.
export function pinnedPalette(spec, auto) {
  const [surface, depths] = (spec || '').trim().split(/\s+/)
  const rgb = parseHex(surface)
  if (!rgb) return auto
  const pal = buildPalette(rgbToHsv(rgb), null)
  pal.shallow = rgb
  if (parseHex(depths)) pal.deep = parseHex(depths)
  if (auto && !auto.grey) {
    pal.foam = auto.foam
    // The wallpaper's wordmark colours, unless the pinned water is close to them.
    const hue = rgbToHsv(rgb).hue
    const glyphs = [auto.glyphA, auto.glyphB, auto.glyphC]
    if (glyphs.every((g) => g && hueDist(rgbToHsv(g).hue, hue) >= GLYPH_MIN_DIST))
      [pal.glyphA, pal.glyphB, pal.glyphC] = glyphs
  }
  return pal
}

export function loadPalette(path, cancellable) {
  return new Promise((resolve) => {
    const file = Gio.File.new_for_path(path)
    file.read_async(GLib.PRIORITY_LOW, cancellable, (f, res) => {
      let stream
      try {
        stream = f.read_finish(res)
      } catch {
        resolve(GREY)
        return
      }
      GdkPixbuf.Pixbuf.new_from_stream_at_scale_async(
        stream, SAMPLE_SIZE, SAMPLE_SIZE, true, cancellable, (_s, r) => {
          try {
            resolve(paletteFromPixbuf(GdkPixbuf.Pixbuf.new_from_stream_finish(r)))
          } catch {
            resolve(GREY)
          }
          stream.close_async(0, null, null)
        })
    })
  })
}

// Palettes keyed by path + mtime, kept on disk so a wallpaper change can
// start its colour fade in the same frame the wallpaper starts fading.
export class PaletteCache {
  constructor(cancellable) {
    this._cancel = cancellable
    this._dir = GLib.build_filenamev([GLib.get_user_cache_dir(), 'water-panel'])
    this._file = GLib.build_filenamev([this._dir, 'palettes.json'])
    this._mem = new Map()
    this._pending = new Map()
    // Read without blocking the shell; a palette worked out before this
    // finishes stays (the in-memory one is newer).
    Gio.File.new_for_path(this._file).load_contents_async(cancellable, (f, res) => {
      try {
        const [, data] = f.load_contents_finish(res)
        const obj = JSON.parse(new TextDecoder().decode(data))
        for (const [k, v] of Object.entries(obj))
          if (k.startsWith(`v${ALGO_VERSION}|`) && !this._mem.has(k)) this._mem.set(k, v)
      } catch {}
    })
  }

  _key(path) {
    try {
      const info = Gio.File.new_for_path(path).query_info('time::modified', 0, null)
      return `v${ALGO_VERSION}|${path}|${info.get_attribute_uint64('time::modified')}`
    } catch {
      return null
    }
  }

  get(path) {
    const key = this._key(path)
    if (!key) return Promise.resolve(GREY)
    if (this._mem.has(key)) return Promise.resolve(this._mem.get(key))
    if (this._pending.has(key)) return this._pending.get(key)
    const p = loadPalette(path, this._cancel).then((pal) => {
      this._pending.delete(key)
      this._mem.set(key, pal)
      this._scheduleSave()
      return pal
    })
    this._pending.set(key, p)
    return p
  }

  // Work through every image in a folder in the background, one at a time.
  async prewarm(dirPath) {
    let names = []
    try {
      const en = Gio.File.new_for_path(dirPath).enumerate_children('standard::name', 0, null)
      let info
      while ((info = en.next_file(null)))
        if (/\.(jpe?g|png|webp)$/i.test(info.get_name())) names.push(info.get_name())
      en.close(null)
    } catch {
      return
    }
    for (const n of names) {
      if (this._cancel.is_cancelled()) return
      await this.get(GLib.build_filenamev([dirPath, n]))
    }
  }

  _scheduleSave() {
    if (this._saveId) return
    this._saveId = GLib.timeout_add_seconds(GLib.PRIORITY_LOW, 5, () => {
      this._saveId = 0
      this.save()
      return GLib.SOURCE_REMOVE
    })
  }

  save() {
    try {
      GLib.mkdir_with_parents(this._dir, 0o755)
      GLib.file_set_contents(this._file, JSON.stringify(Object.fromEntries(this._mem)))
    } catch {}
  }

  destroy() {
    if (this._saveId) GLib.source_remove(this._saveId)
    this._saveId = 0
    this.save()
  }
}
