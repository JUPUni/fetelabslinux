// SPDX-License-Identifier: GPL-2.0-or-later
// Water Panel preferences.

import Adw from 'gi://Adw'
import Gdk from 'gi://Gdk'
import Gio from 'gi://Gio'
import GLib from 'gi://GLib'
import Gtk from 'gi://Gtk'

import { ExtensionPreferences } from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js'

// Links shown on the About page.
const X_URL = 'https://x.com/mostlyjola'
const INSTAGRAM_URL = 'https://instagram.com/fetelabs'
// Donations: USDC on Solana only. The wallet link pins the official USDC
// mint, so wallets won't offer SOL or other tokens for it.
const DONATE_SOLANA_USDC = 'Dox9t9toz7BwwHJaqqsTpt9J74DWkXidP921FJQgWGE5'
const USDC_MINT = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'

const hexOf = (rgba) =>
  '#' + [rgba.red, rgba.green, rgba.blue]
    .map((c) => Math.round(c * 255).toString(16).padStart(2, '0'))
    .join('')
    .toUpperCase()

function rgbaOf(hex) {
  const rgba = new Gdk.RGBA()
  rgba.parse(hex)
  return rgba
}

function colorButton() {
  return new Gtk.ColorDialogButton({
    dialog: new Gtk.ColorDialog({ with_alpha: false }),
    valign: Gtk.Align.CENTER,
  })
}

// Combo row bound to a string (enum) setting.
function choiceRow(settings, key, title, subtitle, choices) {
  const row = new Adw.ComboRow({
    title,
    subtitle,
    model: Gtk.StringList.new(choices.map(([, label]) => label)),
  })
  const sync = () => {
    const i = choices.findIndex(([v]) => v === settings.get_string(key))
    if (i >= 0 && row.selected !== i) row.selected = i
  }
  sync()
  row.connect('notify::selected', () => settings.set_string(key, choices[row.selected][0]))
  settings.connect(`changed::${key}`, sync)
  return row
}

function spinRow(settings, key, title, subtitle, lower, upper, step, digits) {
  const row = new Adw.SpinRow({
    title,
    subtitle,
    digits,
    adjustment: new Gtk.Adjustment({ lower, upper, step_increment: step, page_increment: step * 5 }),
  })
  settings.bind(key, row, 'value', Gio.SettingsBindFlags.DEFAULT)
  return row
}

function switchRow(settings, key, title, subtitle) {
  const row = new Adw.SwitchRow({ title, subtitle })
  settings.bind(key, row, 'active', Gio.SettingsBindFlags.DEFAULT)
  return row
}

// Runs a command and reports whether it succeeded.
function check(argv) {
  return new Promise((resolve) => {
    try {
      const proc = Gio.Subprocess.new(argv,
        Gio.SubprocessFlags.STDOUT_SILENCE | Gio.SubprocessFlags.STDERR_SILENCE)
      proc.wait_check_async(null, (p, res) => {
        try {
          resolve(p.wait_check_finish(res))
        } catch {
          resolve(false)
        }
      })
    } catch {
      resolve(false)
    }
  })
}

export default class WaterPanelPrefs extends ExtensionPreferences {
  fillPreferencesWindow(window) {
    const settings = this.getSettings()
    window.set_default_size(640, 760)
    window.add(this._lookPage(settings))
    window.add(this._motionPage(settings))
    window.add(this._taskbarPage(settings))
    window.add(this._aboutPage(window))
  }

  _aboutPage(window) {
    const page = new Adw.PreferencesPage({ title: 'About', icon_name: 'help-about-symbolic' })

    const head = new Adw.PreferencesGroup()
    page.add(head)
    const box = new Gtk.Box({ orientation: Gtk.Orientation.VERTICAL, spacing: 6, margin_top: 12, margin_bottom: 12 })
    box.append(new Gtk.Label({ label: 'Water Panel', css_classes: ['title-1'] }))
    box.append(new Gtk.Label({ label: 'by Fetelabs', css_classes: ['dim-label'] }))
    box.append(new Gtk.Label({
      label: `Version ${this.metadata.version ?? ''}`.trim(),
      css_classes: ['dim-label', 'caption'],
    }))
    head.add(box)

    const links = new Adw.PreferencesGroup({ title: 'Follow' })
    page.add(links)
    for (const [title, subtitle, url] of [
      ['X', '@mostlyjola', X_URL],
      ['Instagram', '@fetelabs', INSTAGRAM_URL],
    ]) {
      const row = new Adw.ActionRow({ title, subtitle, activatable: true })
      row.add_suffix(new Gtk.Image({ icon_name: 'adw-external-link-symbolic' }))
      row.connect('activated', () => Gtk.show_uri(window, url, Gdk.CURRENT_TIME))
      links.add(row)
    }

    if (DONATE_SOLANA_USDC) {
      const donate = new Adw.PreferencesGroup({
        title: 'Support',
        description: 'If Water Panel makes your desktop nicer, you can leave a tip. ' +
          'Send USDC on the Solana network only. SOL, other tokens, or USDC on ' +
          'any other network sent to this address will be lost.',
      })
      page.add(donate)
      const row = new Adw.ActionRow({
        title: 'USDC on Solana only',
        subtitle: DONATE_SOLANA_USDC,
        subtitle_selectable: true,
      })
      const copy = new Gtk.Button({
        icon_name: 'edit-copy-symbolic',
        tooltip_text: 'Copy address',
        valign: Gtk.Align.CENTER,
        css_classes: ['flat'],
      })
      copy.connect('clicked', () => {
        copy.get_clipboard().set(DONATE_SOLANA_USDC)
        window.add_toast(new Adw.Toast({ title: 'Address copied' }))
      })
      const wallet = new Gtk.Button({
        icon_name: 'adw-external-link-symbolic',
        tooltip_text: 'Open in a Solana wallet (USDC)',
        valign: Gtk.Align.CENTER,
        css_classes: ['flat'],
      })
      wallet.connect('clicked', () => Gtk.show_uri(window,
        `solana:${DONATE_SOLANA_USDC}?spl-token=${USDC_MINT}&label=Water%20Panel`, Gdk.CURRENT_TIME))
      row.add_suffix(copy)
      row.add_suffix(wallet)
      donate.add(row)
    }
    return page
  }

  _lookPage(settings) {
    const page = new Adw.PreferencesPage({ title: 'Look', icon_name: 'applications-graphics-symbolic' })

    // Colour
    const colour = new Adw.PreferencesGroup({ title: 'Colour' })
    page.add(colour)
    colour.add(choiceRow(settings, 'color-mode', 'Colour source', null, [
      ['wallpaper', 'Match the wallpaper'],
      ['custom', 'Single colour'],
    ]))

    const customRow = new Adw.ActionRow({
      title: 'Single colour',
      subtitle: 'Used in single-colour mode, and for wallpapers with no real colour',
    })
    const customBtn = colorButton()
    customBtn.rgba = rgbaOf(settings.get_string('custom-color'))
    customBtn.connect('notify::rgba', () => {
      const hex = hexOf(customBtn.rgba)
      if (hex !== settings.get_string('custom-color')) settings.set_string('custom-color', hex)
    })
    settings.connect('changed::custom-color', () => {
      const hex = settings.get_string('custom-color')
      if (hex !== hexOf(customBtn.rgba)) customBtn.rgba = rgbaOf(hex)
    })
    const resetBtn = new Gtk.Button({
      icon_name: 'edit-undo-symbolic',
      tooltip_text: 'Back to ocean blue',
      valign: Gtk.Align.CENTER,
      css_classes: ['flat'],
    })
    resetBtn.connect('clicked', () => settings.reset('custom-color'))
    customRow.add_suffix(resetBtn)
    customRow.add_suffix(customBtn)
    colour.add(customRow)

    colour.add(this._pinRow(settings))

    // Shape
    const shape = new Adw.PreferencesGroup({ title: 'Shape' })
    page.add(shape)
    shape.add(choiceRow(settings, 'corner-style', 'Corners', null, [
      ['taskbar', 'Match the taskbar'],
      ['pill', 'Pill'],
      ['custom', 'Custom radius'],
    ]))
    const radius = spinRow(settings, 'corner-radius', 'Corner radius', 'Pixels', 0, 60, 1, 0)
    const syncRadius = () => (radius.sensitive = settings.get_string('corner-style') === 'custom')
    syncRadius()
    settings.connect('changed::corner-style', syncRadius)
    shape.add(radius)

    // Liquid
    const liquid = new Adw.PreferencesGroup({ title: 'Liquid' })
    page.add(liquid)
    liquid.add(spinRow(settings, 'wave-height', 'Wave height', 'Tallest wave, as a share of the taskbar height', 0.2, 1, 0.02, 2))
    liquid.add(spinRow(settings, 'opacity', 'Opacity', null, 0.1, 1, 0.05, 2))
    liquid.add(switchRow(settings, 'surface-line', 'Surface line', 'A bright line along the top of the water'))
    liquid.add(switchRow(settings, 'back-wave', 'Back wave', 'A slower wave behind, for depth'))
    liquid.add(switchRow(settings, 'wordmark', 'Fetelabs wordmark',
      'While Spotify plays, the logo shows through the water where waves splash over it'))
    return page
  }

  // Pin a colour to whatever wallpaper is showing now.
  _pinRow(settings) {
    const bg = new Gio.Settings({ schema_id: 'org.gnome.desktop.background' })
    const iface = new Gio.Settings({ schema_id: 'org.gnome.desktop.interface' })
    const row = new Adw.ActionRow({ title: 'Pin a colour to this wallpaper' })
    const btn = colorButton()
    const clear = new Gtk.Button({
      icon_name: 'edit-clear-symbolic',
      tooltip_text: 'Unpin',
      valign: Gtk.Align.CENTER,
      css_classes: ['flat'],
    })
    row.add_suffix(clear)
    row.add_suffix(btn)

    const current = () => {
      const dark = iface.get_string('color-scheme') === 'prefer-dark'
      const uri = bg.get_string(dark ? 'picture-uri-dark' : 'picture-uri')
      const path = uri ? Gio.File.new_for_uri(uri).get_path() : null
      return path ? GLib.path_get_basename(path) : null
    }
    const pins = () => settings.get_value('wallpaper-colors').deepUnpack()
    let syncing = false
    const sync = () => {
      syncing = true
      const name = current()
      const pin = name ? pins()[name] : null
      row.subtitle = name
        ? (pin ? `${name}: pinned` : `${name}: automatic`)
        : 'No wallpaper image'
      row.sensitive = !!name
      clear.sensitive = !!pin
      btn.rgba = rgbaOf(pin ? pin.split(/\s+/)[0] : '#808080')
      syncing = false
    }
    btn.connect('notify::rgba', () => {
      const name = current()
      if (syncing || !name) return
      const all = pins()
      all[name] = hexOf(btn.rgba)
      settings.set_value('wallpaper-colors', new GLib.Variant('a{ss}', all))
    })
    clear.connect('clicked', () => {
      const all = pins()
      delete all[current()]
      settings.set_value('wallpaper-colors', new GLib.Variant('a{ss}', all))
    })
    for (const sig of ['changed::picture-uri', 'changed::picture-uri-dark'])
      bg.connect(sig, sync)
    iface.connect('changed::color-scheme', sync)
    settings.connect('changed::wallpaper-colors', sync)
    sync()
    return row
  }

  _motionPage(settings) {
    const page = new Adw.PreferencesPage({ title: 'Motion', icon_name: 'media-playlist-shuffle-symbolic' })

    const feel = new Adw.PreferencesGroup({ title: 'Feel' })
    page.add(feel)
    feel.add(spinRow(settings, 'responsiveness', 'Rise', 'How fast the water jumps to a beat', 0.1, 1, 0.05, 2))
    feel.add(spinRow(settings, 'fall-speed', 'Fall', 'How fast it settles back (1 = default)', 0.25, 3, 0.05, 2))
    feel.add(spinRow(settings, 'surface-tension', 'Surface tension', 'How much neighbouring bars pull on each other', 0, 0.5, 0.01, 2))

    const detail = new Adw.PreferencesGroup({
      title: 'Detail',
      description: 'Higher values look smoother but use a little more CPU.',
    })
    page.add(detail)
    detail.add(spinRow(settings, 'bands', 'Bars', 'Frequency bands across the taskbar', 16, 128, 4, 0))
    detail.add(spinRow(settings, 'frame-rate', 'Analysis rate', 'Audio frames per second', 30, 144, 10, 0))
    return page
  }

  _taskbarPage(settings) {
    const page = new Adw.PreferencesPage({ title: 'Taskbar', icon_name: 'view-app-grid-symbolic' })

    const apps = new Adw.PreferencesGroup({
      title: 'Hidden apps',
      description: 'Keep these apps off the taskbar, e.g. a music player you control from the top bar. ' +
        'Use desktop file IDs separated by commas, like spotify.desktop.',
    })
    page.add(apps)
    const entry = new Adw.EntryRow({ title: 'Desktop file IDs', show_apply_button: true })
    const sync = () => (entry.text = settings.get_strv('hidden-apps').join(', '))
    sync()
    settings.connect('changed::hidden-apps', sync)
    entry.connect('apply', () => {
      const ids = entry.text.split(',').map((s) => s.trim()).filter(Boolean)
      settings.set_strv('hidden-apps', ids)
    })
    apps.add(entry)

    const req = new Adw.PreferencesGroup({
      title: 'Requirements',
      description: 'The audio analysis runs in a small Python helper.',
    })
    page.add(req)
    const items = [
      ['Python 3 with NumPy', ['python3', '-c', 'import numpy'], 'Install python3-numpy'],
      ['parec', ['sh', '-c', 'command -v parec'], 'Install pulseaudio-utils (works with PipeWire too)'],
      ['pactl', ['sh', '-c', 'command -v pactl'], 'Install pulseaudio-utils'],
      ['Fetelabs Task Bar, Zorin Taskbar or Dash to Panel', null, null],
    ]
    for (const [title, argv, fix] of items) {
      const row = new Adw.ActionRow({ title })
      const icon = new Gtk.Image({ icon_name: 'content-loading-symbolic' })
      row.add_suffix(icon)
      req.add(row)
      if (!argv) {
        row.subtitle = 'One of these extensions must be enabled'
        icon.icon_name = 'dialog-information-symbolic'
        continue
      }
      check(argv).then((ok) => {
        icon.icon_name = ok ? 'emblem-ok-symbolic' : 'dialog-warning-symbolic'
        row.subtitle = ok ? 'Found' : fix
      })
    }
    return page
  }
}
