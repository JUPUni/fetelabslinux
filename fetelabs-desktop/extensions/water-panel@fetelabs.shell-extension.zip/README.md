# Water Panel

by **Fetelabs** (https://fetelabs.ai). Follow [@mostlyjola on X](https://x.com/mostlyjola) and [@fetelabs on Instagram](https://instagram.com/fetelabs).

A GNOME Shell extension that turns your taskbar into a liquid audio
visualizer. The water rises and ripples with whatever is playing, and takes
its colours from your wallpaper, fading in step with GNOME's own wallpaper
crossfade.

Works with **Fetelabs Task Bar**, **Zorin Taskbar** (Zorin OS) or **Dash to Panel**, on
GNOME 46–48.

## Install

From extensions.gnome.org once it is listed there, or from the zip:

    gnome-extensions install --force water-panel.zip

Then log out and back in (GNOME on Wayland only loads new extensions at
login) and turn it on:

    gnome-extensions enable water-panel@fetelabs

## Requirements

The audio analysis runs in a small Python helper (`analyzer.py`):

- `python3` with NumPy
- `parec` and `pactl` (from `pulseaudio-utils`; they work on PipeWire too)

Debian / Ubuntu / Zorin OS:

    sudo apt install python3-numpy pulseaudio-utils

The Taskbar page in the preferences shows whether each one is found.

## Settings

Open them from the Extensions app, or run
`gnome-extensions prefs water-panel@fetelabs`.

- **Look:** colour from the wallpaper or a single colour, a pinned colour per
  wallpaper, corners (match the taskbar, pill or a custom radius), wave
  height, opacity, surface line, back wave, Fetelabs wordmark.
- **Motion:** how fast the water rises and falls, surface tension, number of
  bars, analysis rate.
- **Taskbar:** apps to keep off the taskbar.

Wallpapers with no real colour (grey, black and white) use the single
colour, ocean blue by default.

## The wordmark

While Spotify is playing (its desktop app, ncspot or spotifyd, read from
MPRIS), "JOLA x", the Fetelabs test tube and name sit hidden in the middle
of the taskbar. They show through the water only where a wave has just
surged up over them, then fade within a third of a second. Each letter takes
one of three colours from the wallpaper, picked far round the colour wheel
from the water's own so the mark pops, with a thin outline in whatever
colour contrasts most with that letter and the water, and a soft
glow. Other players and
sounds still move the water but never show the mark. Turn it off under
Look → Liquid → Fetelabs wordmark.

## How it works

`analyzer.py` records the monitor of your default output with `parec`, runs
a two-resolution FFT (a long window for the bass, a short one for the highs)
and streams one frame of band levels per tick. The extension draws those
levels with spring physics into an `St.DrawingArea` placed behind the
taskbar's icons, and paints the taskbar's background itself so the liquid
sits between the two.

Wallpaper colours are worked out once per image and cached in
`~/.cache/water-panel/`.

## Building

    ./pack.sh

makes the zip for extensions.gnome.org in `dist/`.

## Support

Water Panel is free. If it makes your desktop nicer, tips are welcome:

**USDC on Solana only:** `Dox9t9toz7BwwHJaqqsTpt9J74DWkXidP921FJQgWGE5`

Only send USDC on the Solana network. SOL, other tokens, or USDC on any other
network (Ethereum, Base, etc.) sent to this address will be lost. The About
page in the preferences has a copy button and a wallet link that is locked to
USDC.

## License

GPL-2.0-or-later. See `LICENSE`.

The wordmark's letter shapes come from Rubik Wet Paint, copyright 2020 The
Rubik Filtered Project Authors, under the SIL Open Font License 1.1 (see
`OFL-RubikWetPaint.txt`). `tools/wordmark-glyphs.py` regenerates
`wordmark-glyphs.js` from the font.
