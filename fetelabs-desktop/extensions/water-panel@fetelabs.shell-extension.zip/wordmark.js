// SPDX-License-Identifier: GPL-2.0-or-later
// The wordmark hidden in the middle of the taskbar: "JOLA x", the test tube
// and "FETELABS" in fetelabs.ai's Rubik Wet Paint. It is only seen through
// the water, and only where a wave has just surged up over it, then it fades
// again within a third of a second. It only wakes while Spotify is playing.
//
// Nothing here imports Shell modules, so tools can render it offline.

import Cairo from 'cairo'
import Gio from 'gi://Gio'
import GLib from 'gi://GLib'

import { PRE, PRE_LETTERS, PRE_PATH, WORD, WORD_LETTERS, WORD_PATH } from './wordmark-glyphs.js'

// Layout, as fractions of the taskbar height.
const EM = 0.5 // font size
const ICON_EM = 1.32 // test tube height, in em
const GAP_EM = 0.3 // between tube and word
// Test tube artwork (fetelabs.ai logo) is 96 x 203 in its own units.
const ICON_BOX = { x: 46, y: -12, w: 96, h: 203 }

// Splash: the water has to reach this far up the bar (fraction from the
// bottom) before the mark shows at all, and is fully over it at FLOOR + SPAN.
const REVEAL_FLOOR = 0.2
const REVEAL_SPAN = 0.42
const RISE_MIN = 13 // level/s: slower swells than this reveal nothing
const RISE_FULL = 28 // level/s: a surge this fast reveals it fully
const SURGE_BASE = 0.72 // strength of a surge that only just counts
const ATTACK_S = 0.02
const SPREAD = [1, 0.85, 0.55, 0.25] // share of a hit reaching bands 0..3 away
const FADE_S = 0.3 // "fades quickly"
const MAX_ALPHA = 1
const OUTLINE_EM = 0.07 // outline stroke width; the letters cover its inner half

// Refraction: the mark wobbles a little under moving water.
const STRIPS = 22
const WOBBLE = 1.3 / 48 // of the bar height

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v))

// Both words, in the word's own em units: "FETELABS" at the origin and
// "JOLA x" preDx em to its left.
function traceWord(cr, preDx) {
  tracePath(cr, WORD_PATH)
  cr.save()
  cr.translate(preDx, 0)
  tracePath(cr, PRE_PATH)
  cr.restore()
}

function tracePath(cr, p) {
  for (let i = 0; i < p.length;) {
    switch (p[i]) {
    case 'M':
      cr.moveTo(p[i + 1], p[i + 2])
      i += 3
      break
    case 'L':
      cr.lineTo(p[i + 1], p[i + 2])
      i += 3
      break
    case 'C':
      cr.curveTo(p[i + 1], p[i + 2], p[i + 3], p[i + 4], p[i + 5], p[i + 6])
      i += 7
      break
    default: // Z
      cr.closePath()
      i += 1
    }
  }
}

// The tube body: M70 38 V160 A30 30 0 0 0 130 160 V38 Z
function traceTube(cr) {
  cr.moveTo(70, 38)
  cr.lineTo(70, 160)
  cr.arcNegative(100, 160, 30, Math.PI, 0)
  cr.lineTo(130, 38)
  cr.closePath()
}

// One liquid band inside the tube: "M x y q14-16 28 0 t28 0 ... V210 H x Z".
function traceWave(cr, x, y) {
  cr.moveTo(x, y)
  let up = true
  for (let k = 0; k < 5; k++, x += 28, up = !up) {
    const cy = y + (up ? -16 : 16)
    // quadratic (x+14, cy) -> (x+28, y) as a cubic
    cr.curveTo(x + 28 / 3, y + (cy - y) * 2 / 3, x + 28 - 28 / 3, y + (cy - y) * 2 / 3, x + 28, y)
  }
  cr.lineTo(x, 210)
  cr.lineTo(x - 140, 210)
  cr.closePath()
}

function roundRect(cr, x, y, w, h, r) {
  cr.newSubPath()
  cr.arc(x + w - r, y + r, r, -Math.PI / 2, 0)
  cr.arc(x + w - r, y + h - r, r, 0, Math.PI / 2)
  cr.arc(x + r, y + h - r, r, Math.PI / 2, Math.PI)
  cr.arc(x + r, y + r, r, Math.PI, 1.5 * Math.PI)
  cr.closePath()
}

const circle = (cr, x, y, r) => {
  cr.newSubPath()
  cr.arc(x, y, r, 0, 2 * Math.PI)
}

// The logo in its own units, tilted like on the site. `part` picks which
// pieces go on this mask: 'ink' (glass, liquid, bubbles) or 'shine' (cap,
// highlight, bubbles caught in the light).
function drawIcon(cr, part) {
  cr.save()
  cr.translate(100, 110)
  cr.rotate(-12 * Math.PI / 180)
  cr.translate(-100, -110)
  if (part === 'ink') {
    traceTube(cr)
    cr.setSourceRGBA(0, 0, 0, 0.3) // glass
    cr.fillPreserve()
    cr.setLineWidth(6)
    cr.setSourceRGBA(0, 0, 0, 0.9)
    cr.stroke()
    cr.save()
    traceTube(cr)
    cr.clip()
    ;[[44, 100, 0.55], [30, 132, 0.8], [44, 162, 1]].forEach(([x, y, a]) => {
      traceWave(cr, x, y)
      cr.setSourceRGBA(0, 0, 0, a)
      cr.fill()
    })
    cr.restore()
    circle(cr, 94, 18, 6)
    circle(cr, 112, 4, 4)
    circle(cr, 100, -10, 3)
    cr.setSourceRGBA(0, 0, 0, 1)
    cr.fill()
  } else {
    cr.setSourceRGBA(0, 0, 0, 1)
    roundRect(cr, 64, 30, 72, 12, 6)
    circle(cr, 90, 74, 5)
    circle(cr, 110, 60, 3.5)
    cr.fill()
    cr.setLineWidth(5)
    cr.setLineCap(Cairo.LineCap.ROUND)
    cr.moveTo(82, 56)
    cr.lineTo(82, 84)
    cr.moveTo(82, 96)
    cr.lineTo(82, 102)
    cr.stroke()
  }
  cr.restore()
}

// Where everything goes for a bar of height h, in pixels.
function layout(w, h) {
  const em = h * EM
  const iconH = ICON_EM * em
  const iconW = iconH * ICON_BOX.w / ICON_BOX.h
  const gap = GAP_EM * em
  const preW = (PRE.right - PRE.left) * em
  const wordW = (WORD.right - WORD.left) * em
  const total = preW + gap + iconW + gap + wordW
  const x0 = Math.round((w - total) / 2) // left edge of "JOLA x"
  const iconX = x0 + preW + gap
  const wordX = iconX + iconW + gap - WORD.left * em // "FETELABS" origin
  const preDx = (x0 - PRE.left * em - wordX) / em
  // Caps centred on the bar; the paint drips hang below.
  const baseline = h / 2 + 0.355 * em
  const iconTop = baseline + 0.3 * em - iconH
  // Room round the ink for the glow (reaches 0.12 em out), whatever the bar height.
  const pad = Math.ceil(0.13 * em) + 2
  const top = Math.floor(Math.min(iconTop, baseline + WORD.top * em)) - pad
  const bottom = Math.ceil(baseline + WORD.bottom * em) + pad
  return { em, iconH, iconW, gap, wordW, total, x0, iconX, wordX, preDx, baseline, iconTop, top, bottom, pad }
}

// Colours for the mark. Before any wallpaper has been read, or with a palette
// from an older cache, fall back to the foam colour.
const tone = (c, t) => c.map((v) => v + (1 - v) * t)

function rgbToHsv([r, g, b]) {
  const max = Math.max(r, g, b)
  const d = max - Math.min(r, g, b)
  let h = 0
  if (d) h = max === r ? ((g - b) / d + 6) % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4
  return [h / 6, max ? d / max : 0, max]
}

function hsvToRgb(h, s, v) {
  const f = (n) => {
    const k = (n + h * 6) % 6
    return v - v * s * Math.max(0, Math.min(k, 4 - k, 1))
  }
  return [f(5), f(3), f(1)]
}

// Halfway between two colours round the colour wheel, so lime to pink goes
// through gold instead of mud.
function midColour(a, b) {
  const [ha, sa, va] = rgbToHsv(a)
  const [hb, sb, vb] = rgbToHsv(b)
  const diff = ((hb - ha + 1.5) % 1) - 0.5
  return hsvToRgb((ha + diff / 2 + 1) % 1, Math.max(sa, sb), Math.max(va, vb))
}

// WCAG relative luminance and contrast ratio (1..21).
const lin = (v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)
const luma = ([r, g, b]) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)
function contrast(x, y) {
  const [a, b] = [luma(x), luma(y)].sort((m, n) => n - m)
  return (a + 0.05) / (b + 0.05)
}

// The outline colour that makes a letter pop most: of a few candidates (near
// black tinted by the water, white, and the letter's complement dark, mid
// and light), the one best separating the letter from both itself and the
// water around it. Scored on the weaker of the two contrasts, with a nudge
// for hue difference so ties go to the more colourful edge.
function outlineFor(fill, water, deep) {
  const [h] = rgbToHsv(fill)
  const comp = (h + 0.5) % 1
  const candidates = [
    deep.map((v) => v * 0.18),
    [1, 1, 1],
    hsvToRgb(comp, 0.9, 0.22),
    hsvToRgb(comp, 0.85, 0.55),
    hsvToRgb(comp, 0.35, 1),
  ]
  let best = candidates[0]
  let bestScore = -1
  for (const c of candidates) {
    const [ch, cs] = rgbToHsv(c)
    const hueGap = cs > 0.2 ? Math.min(Math.abs(ch - h), 1 - Math.abs(ch - h)) * 2 : 0
    const score = Math.min(contrast(c, fill), contrast(c, water) * 1.3) * (1 + 0.15 * hueGap)
    if (score > bestScore) {
      bestScore = score
      best = c
    }
  }
  return best
}

export class Wordmark {
  constructor() {
    this._key = ''
    this._masks = null
    this._lineKey = ''
    this._lines = null
  }

  // Outline colour per letter colour; recomputed only when the palette moves.
  _outlines(cycle, colors) {
    const water = colors.deep.map((v, i) => (v + colors.shallow[i]) / 2)
    const key = [...cycle.flat(), ...water].map((v) => v.toFixed(3)).join()
    if (key !== this._lineKey) {
      this._lineKey = key
      this._lines = cycle.map((c) => outlineFor(c, water, colors.deep))
    }
    return this._lines
  }

  // Masks (alpha only) are drawn once per bar size and reused every frame.
  _build(w, h) {
    const key = `${w}x${h}`
    if (key === this._key) return this._masks
    this._free()
    const L = layout(w, h)
    const mw = Math.ceil(L.total) + 2 * L.pad
    const mh = L.bottom - L.top
    const ox = L.x0 - L.pad
    const make = () => new Cairo.ImageSurface(Cairo.Format.A8, mw, mh)
    const ink = make()
    const shine = make()
    const glow = make()
    const outline = make()

    const place = (cr, fn) => {
      cr.save()
      cr.translate(-ox, -L.top)
      fn(cr)
      cr.restore()
    }
    const iconAt = (cr) => {
      cr.translate(L.iconX, L.iconTop)
      const s = L.iconH / ICON_BOX.h
      cr.scale(s, s)
      cr.translate(-ICON_BOX.x, -ICON_BOX.y)
    }
    const wordAt = (cr) => {
      cr.translate(L.wordX, L.baseline)
      cr.scale(L.em, L.em)
    }

    let cr = new Cairo.Context(ink)
    place(cr, (c) => {
      c.save()
      iconAt(c)
      drawIcon(c, 'ink')
      c.restore()
      wordAt(c)
      traceWord(c, L.preDx)
      c.setSourceRGBA(0, 0, 0, 1)
      c.fill()
    })
    cr.$dispose()

    cr = new Cairo.Context(shine)
    place(cr, (c) => {
      iconAt(c)
      drawIcon(c, 'shine')
    })
    cr.$dispose()

    // A thin dark outline round the tube and every letter.
    cr = new Cairo.Context(outline)
    place(cr, (c) => {
      c.save()
      iconAt(c)
      c.translate(100, 110)
      c.rotate(-12 * Math.PI / 180)
      c.translate(-100, -110)
      traceTube(c)
      c.restore()
      c.save()
      wordAt(c)
      traceWord(c, L.preDx)
      c.restore()
      c.setLineWidth(OUTLINE_EM * L.em)
      c.setLineJoin(Cairo.LineJoin.ROUND)
      c.setSourceRGBA(0, 0, 0, 1)
      c.stroke()
    })
    cr.$dispose()

    // A soft halo: the same shapes stroked wide at low alpha, several times.
    cr = new Cairo.Context(glow)
    place(cr, (c) => {
      for (const [width, a] of [[0.24, 0.08], [0.15, 0.12], [0.08, 0.17]]) {
        c.save()
        iconAt(c)
        traceTube(c)
        c.restore()
        c.save()
        wordAt(c)
        traceWord(c, L.preDx)
        c.restore()
        c.setLineWidth(width * L.em)
        c.setLineJoin(Cairo.LineJoin.ROUND)
        c.setSourceRGBA(0, 0, 0, a)
        c.stroke()
      }
    })
    cr.$dispose()

    // Where each part sits across the mask (0..1), left to right: the
    // letters of "JOLA x", the tube, then the letters of "FETELABS".
    const at = (dx) => ([a, b]) => [L.wordX + (a + dx) * L.em, L.wordX + (b + dx) * L.em]
    const parts = [...PRE_LETTERS.map(at(L.preDx)), [L.iconX, L.iconX + L.iconW], ...WORD_LETTERS.map(at(0))]
      .map(([a, b]) => [(a - ox) / mw, (b - ox) / mw])

    this._key = key
    this._masks = { ink, shine, glow, outline, ox, oy: L.top, mw, mh, L, parts }
    return this._masks
  }

  _free() {
    if (!this._masks) return
    for (const k of ['ink', 'shine', 'glow', 'outline']) this._masks[k].finish()
    this._masks = null
    this._key = ''
  }

  // cr is already clipped to the bar. clipWater() traces the front water
  // shape. splash has one value per band, band i sits at x = i * w / (n - 1).
  draw(cr, w, h, clipWater, splash, colors, timeS) {
    const n = splash.length
    // A vertical or very short taskbar has no room for it.
    if (w < h * 4 || layout(w, h).total > w * 0.6) return
    const M = this._build(w, h)
    const step = w / (n - 1)
    const i0 = Math.max(0, Math.floor(M.ox / step))
    const i1 = Math.min(n - 1, Math.ceil((M.ox + M.mw) / step))
    let peak = 0
    for (let i = i0; i <= i1; i++) peak = Math.max(peak, splash[i])
    if (peak < 0.004) return

    const a = colors.glyphA ?? tone(colors.foam, 0)
    const b = colors.glyphB ?? tone(colors.foam, 0.4)
    const c = colors.glyphC ?? midColour(a, b)
    const x0 = M.ox
    const x1 = M.ox + M.mw

    cr.save()
    clipWater()
    cr.clip()
    cr.pushGroup()

    // Each part its own colour, cycling through the three, with a quick
    // blend in the gaps between letters.
    const cycle = [a, b, c]
    const ink = new Cairo.LinearGradient(x0, 0, x1, 0)
    M.parts.forEach(([p0, p1], i) => {
      const col = cycle[i % 3]
      ink.addColorStopRGBA(p0, ...col, 1)
      ink.addColorStopRGBA(p1, ...col, 1)
    })
    // Caustic: a band of light drifting across the letters.
    const sweepX = x0 + ((timeS * 0.35) % 1.6 - 0.3) * M.mw
    const caustic = new Cairo.LinearGradient(sweepX - M.L.em, 0, sweepX + M.L.em, h)
    caustic.addColorStopRGBA(0, 1, 1, 1, 0)
    caustic.addColorStopRGBA(0.5, 1, 1, 1, 0.45)
    caustic.addColorStopRGBA(1, 1, 1, 1, 0)

    // Each letter's outline in whatever colour makes it pop most.
    const lines = this._outlines(cycle, colors)
    const lineInk = new Cairo.LinearGradient(x0, 0, x1, 0)
    M.parts.forEach(([p0, p1], i) => {
      lineInk.addColorStopRGBA(p0, ...lines[i % 3], 1)
      lineInk.addColorStopRGBA(p1, ...lines[i % 3], 1)
    })

    // The halo follows the letters' colours, lightened so it glows.
    const glowInk = new Cairo.LinearGradient(x0, 0, x1, 0)
    M.parts.forEach(([p0, p1], i) => {
      const col = tone(cycle[i % 3], 0.3)
      glowInk.addColorStopRGBA(p0, ...col, 0.95)
      glowInk.addColorStopRGBA(p1, ...col, 0.95)
    })

    const shadow = Math.max(1, Math.round(h / 40))
    const sw = M.mw / STRIPS
    for (let s = 0; s < STRIPS; s++) {
      const sx = x0 + s * sw
      const band = Math.round((sx + sw / 2) / step)
      const k = splash[clamp(band, 0, n - 1)]
      if (k < 0.004) continue
      const dy = WOBBLE * h * Math.sin(timeS * 7 + sx * 0.09) * k
      cr.save()
      cr.rectangle(sx, M.oy - 4, sw + 0.5, M.mh + 8)
      cr.clip()
      cr.setSource(glowInk)
      cr.maskSurface(M.glow, x0, M.oy + dy)
      // A shadow in the water's deepest colour keeps it legible on any wallpaper.
      cr.setSourceRGBA(...colors.deep.map((v) => v * 0.35), 0.7)
      cr.maskSurface(M.ink, x0 + shadow * 0.5, M.oy + dy + shadow)
      cr.setSource(lineInk)
      cr.maskSurface(M.outline, x0, M.oy + dy)
      cr.setSource(ink)
      cr.maskSurface(M.ink, x0, M.oy + dy)
      cr.setSource(caustic)
      cr.maskSurface(M.ink, x0, M.oy + dy)
      cr.setSourceRGBA(...tone(b, 0.7), 1)
      cr.maskSurface(M.shine, x0, M.oy + dy)
      cr.restore()
    }

    cr.popGroupToSource()
    // How visible each part is: the splash field across the mark.
    const reveal = new Cairo.LinearGradient(x0, 0, x1, 0)
    for (let i = i0; i <= i1; i++) {
      const t = clamp((i * step - x0) / M.mw, 0, 1)
      reveal.addColorStopRGBA(t, 0, 0, 0, splash[i] * MAX_ALPHA)
    }
    cr.mask(reveal)
    cr.restore()
  }

  destroy() {
    this._free()
  }
}

// Per band: how much the mark is showing there. Rises when the water surges
// up over the mark, then fades away fast.
export class Splash {
  constructor(bands) {
    this.resize(bands)
  }

  resize(bands) {
    this.value = new Float32Array(bands) // what is drawn: softened sideways
    this._held = new Float32Array(bands) // latest hit, fading
    this._v = new Float32Array(bands) // eases toward _held
    this._prev = new Float32Array(bands)
  }

  // Returns true while anything is still showing.
  step(level, dt, waveHeight, active) {
    const { _held: held, _v: v, value } = this
    const n = v.length
    const fade = Math.exp(-dt / FADE_S)
    const attack = 1 - Math.exp(-dt / ATTACK_S)
    for (let i = 0; i < n; i++) {
      const rise = (level[i] - this._prev[i]) / dt
      this._prev[i] = level[i]
      held[i] *= fade
      if (active) {
        const over = clamp((level[i] * waveHeight - REVEAL_FLOOR) / REVEAL_SPAN, 0, 1)
        // A surge past RISE_MIN shows clearly at once; bigger ones show fully.
        const e = (rise - RISE_MIN) / (RISE_FULL - RISE_MIN)
        const hit = e > 0 ? (SURGE_BASE + (1 - SURGE_BASE) * Math.min(1, e)) * Math.sqrt(over) : 0
        // A splash spreads sideways, so a surge in one band lights its neighbours.
        if (hit > 0) {
          for (let d = -SPREAD.length + 1; d < SPREAD.length; d++) {
            const j = i + d
            if (j >= 0 && j < n) held[j] = Math.max(held[j], hit * SPREAD[Math.abs(d)])
          }
        }
      }
    }
    for (let i = 0; i < n; i++) {
      // Quick fade-in toward the hit, then fall with it.
      v[i] = held[i] > v[i] ? v[i] + (held[i] - v[i]) * attack : held[i]
    }
    // Soften sideways (drawing copy only) so the reveal has no hard edges.
    let any = false
    for (let i = 0; i < n; i++) {
      const s = (v[Math.max(0, i - 1)] + 2 * v[i] + v[Math.min(n - 1, i + 1)]) / 4
      value[i] = s < 0.002 ? 0 : s
      if (value[i]) any = true
    }
    return any
  }

  clear() {
    this.value.fill(0)
    this._held.fill(0)
    this._v.fill(0)
  }
}

// Spotify's own MPRIS player (also ncspot, spotifyd, spotify-player).
const SPOTIFY = /^org\.mpris\.MediaPlayer2\.(spotify|ncspot|spotifyd|spotify_player)(\.|$)/
const MPRIS_PATH = '/org/mpris/MediaPlayer2'
const PLAYER_IFACE = 'org.mpris.MediaPlayer2.Player'

// Tells whether Spotify is playing right now, from its MPRIS status.
export class SpotifyWatch {
  constructor(onChange) {
    this._onChange = onChange
    this._bus = Gio.DBus.session
    this._cancel = new Gio.Cancellable()
    this._owners = new Map() // unique bus name -> well-known Spotify name
    this._playing = new Map() // well-known name -> bool
    this.playing = false

    this._nameSub = this._bus.signal_subscribe('org.freedesktop.DBus', 'org.freedesktop.DBus',
      'NameOwnerChanged', '/org/freedesktop/DBus', null, Gio.DBusSignalFlags.NONE,
      (_c, _s, _p, _i, _n, params) => {
        const [name, oldOwner, newOwner] = params.deepUnpack()
        if (!SPOTIFY.test(name)) return
        if (oldOwner) this._owners.delete(oldOwner)
        this._playing.delete(name)
        if (newOwner) this._track(name, newOwner)
        this._update()
      })

    this._propSub = this._bus.signal_subscribe(null, 'org.freedesktop.DBus.Properties',
      'PropertiesChanged', MPRIS_PATH, null, Gio.DBusSignalFlags.NONE,
      (_c, sender, _p, _i, _n, params) => {
        const name = this._owners.get(sender)
        if (!name) return
        const [iface, changed, invalidated] = params.recursiveUnpack()
        if (iface !== PLAYER_IFACE) return
        if ('PlaybackStatus' in changed) {
          this._playing.set(name, changed.PlaybackStatus === 'Playing')
          this._update()
        } else if (invalidated.includes('PlaybackStatus')) {
          this._track(name, sender) // ask for it again
        }
      })

    this._call('org.freedesktop.DBus', '/org/freedesktop/DBus', 'org.freedesktop.DBus',
      'ListNames', null, (r) => {
        for (const name of r.deepUnpack()[0].filter((n) => SPOTIFY.test(n))) {
          this._call('org.freedesktop.DBus', '/org/freedesktop/DBus', 'org.freedesktop.DBus',
            'GetNameOwner', new GLib.Variant('(s)', [name]), (o) => this._track(name, o.deepUnpack()[0]))
        }
      })
  }

  _call(dest, path, iface, method, args, done) {
    this._bus.call(dest, path, iface, method, args, null, Gio.DBusCallFlags.NONE, 2000, this._cancel,
      (bus, res) => {
        let r
        try {
          r = bus.call_finish(res)
        } catch {
          return
        }
        done(r)
      })
  }

  _track(name, owner) {
    this._owners.set(owner, name)
    this._call(owner, MPRIS_PATH, 'org.freedesktop.DBus.Properties', 'Get',
      new GLib.Variant('(ss)', [PLAYER_IFACE, 'PlaybackStatus']), (r) => {
        if (this._owners.get(owner) !== name) return
        this._playing.set(name, r.recursiveUnpack()[0] === 'Playing')
        this._update()
      })
  }

  _update() {
    const playing = [...this._playing.values()].some(Boolean)
    if (playing === this.playing) return
    this.playing = playing
    this._onChange(playing)
  }

  destroy() {
    this._cancel.cancel()
    this._bus.signal_unsubscribe(this._nameSub)
    this._bus.signal_unsubscribe(this._propSub)
    this._owners.clear()
    this._playing.clear()
    this._onChange = () => {}
  }
}
