// SPDX-License-Identifier: GPL-2.0-or-later
// The music glow shared by the bar's tiles (the start button and the media
// controls): the tile's outline lights up and glows with the water's swell,
// in a colour picked to stand out against the water rather than match it.
// glowColor() and glowStyle() are Shell-free; TileGlow drives a tile that has
// no animation of its own (the start button's logo already steps the music,
// so it only borrows the colour and style).

import Clutter from 'gi://Clutter'
import GLib from 'gi://GLib'

import { bandsOf } from './logoDraw.js'

const STALE_MS = 250 // no water frame for this long: the music has stopped
const FALLBACK = [1, 0.96, 0.9]

const lin = (c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4)
const lum = ([r, g, b]) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)
const contrast = (a, b) => {
  const [hi, lo] = [lum(a), lum(b)].sort((x, y) => y - x)
  return (hi + 0.05) / (lo + 0.05)
}

function toHsl([r, g, b]) {
  const max = Math.max(r, g, b)
  const min = Math.min(r, g, b)
  const l = (max + min) / 2
  const d = max - min
  if (d < 1e-6) return [0, 0, l]
  const s = d / (1 - Math.abs(2 * l - 1))
  let h
  if (max === r) h = ((g - b) / d) % 6
  else if (max === g) h = (b - r) / d + 2
  else h = (r - g) / d + 4
  return [(h * 60 + 360) % 360, s, l]
}

function fromHsl(h, s, l) {
  const c = (1 - Math.abs(2 * l - 1)) * s
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1))
  const m = l - c / 2
  const [r, g, b] = h < 60 ? [c, x, 0] : h < 120 ? [x, c, 0] : h < 180 ? [0, c, x]
    : h < 240 ? [0, x, c] : h < 300 ? [x, 0, c] : [c, 0, x]
  return [r + m, g + m, b + m]
}

const hueGap = (a, b) => {
  const d = Math.abs(a - b) % 360
  return d > 180 ? 360 - d : d
}

// A glow colour that stands out against the water: the complement and split
// complements of the water's hue, fully saturated at a few lightnesses, plus
// white; scored on contrast against the bar (between the deep and shallow
// colours, capped at 3:1) plus the hue gap, so it reads as a different
// colour, not just a lighter one. Grey water gets white.
let cacheKey = null
let cacheRgb = null
export function glowColor(colors) {
  if (!colors?.deep || !colors?.shallow) return colors?.foam ?? FALLBACK
  const water = colors.deep.map((v, i) => (v + colors.shallow[i]) / 2)
  const key = water.map((v) => Math.round(v * 64)).join(',')
  if (key === cacheKey) return cacheRgb
  const [h, s] = toHsl(water)
  const cands = [[1, 1, 1]]
  if (s > 0.12) {
    for (const off of [180, 150, 210])
      for (const l of [0.5, 0.6, 0.7, 0.8]) cands.push(fromHsl((h + off) % 360, 1, l))
  }
  let best = cands[0]
  let bestScore = -1
  for (const c of cands) {
    const [ch, cs] = toHsl(c)
    const gap = cs > 0.12 && s > 0.12 ? hueGap(ch, h) / 180 : 0
    // Contrast counts up to 3:1 (enough to read on the bar); past that a
    // vivid, clearly different hue beats a paler one.
    const score = Math.min(3, contrast(c, water)) / 3 + 0.7 * gap
    if (score > bestScore) [best, bestScore] = [c, score]
  }
  cacheKey = key
  cacheRgb = best
  return best
}

// The tile's style at a swell of 0..1 (0: the stylesheet's resting outline).
export function glowStyle(rgb, swell) {
  if (!(swell > 0)) return null
  const [r, g, b] = rgb.map((v) => Math.round(v * 255))
  const a = (0.25 + 0.75 * swell).toFixed(2)
  const glow = (0.6 * swell).toFixed(2)
  return `border-color: rgba(${r},${g},${b},${a}); ` +
    `box-shadow: 0 0 ${Math.round(2 + 10 * swell)}px rgba(${r},${g},${b},${glow});`
}

// Restyling makes St parse CSS and redraw the shadow, so the key only moves
// in eighths of a swell and with a visible change of colour.
export function glowKey(rgb, swell) {
  const step = Math.round(swell * 8)
  return step ? `${step}|${rgb.map((v) => Math.round(v * 32)).join(',')}` : '0'
}

// Glows a tile with the music, the same swell as the start button's logo
// (logoDraw.js swellOf). busy() true: someone else styles the tile for now
// (the player's paint splash); it picks up again once that ends.
export class TileGlow {
  constructor(tile, busy = () => false) {
    this._tile = tile
    this._busy = busy
    this._snd = { all: 0, bass: 0, kick: 0 }
    this._prevBass = 0
    this._lastWater = 0
    this._last = 0
    this._key = null

    this._timeline = new Clutter.Timeline({ actor: tile, duration: 1000, repeat_count: -1 })
    this._timeline.connect('new-frame', () => this._frame())
    tile.connectObject(
      'notify::mapped', () => !tile.mapped && this._rest(),
      'destroy', () => this.destroy(),
      this,
    )
    this._watchHost()
    // The task bar can be turned off and on (a new global object).
    this._pollId = GLib.timeout_add_seconds(GLib.PRIORITY_LOW, 2, () => {
      if ((global.fetelabsTaskbar ?? null) !== this._host) this._watchHost()
      return GLib.SOURCE_CONTINUE
    })
  }

  _watchHost() {
    this._unwatchHost()
    this._host = global.fetelabsTaskbar ?? null
    if (this._host?.connect) this._hostId = this._host.connect('water-frame', () => this._onWater())
  }

  _unwatchHost() {
    if (this._hostId) {
      try {
        this._host?.disconnect(this._hostId)
      } catch {}
    }
    this._hostId = 0
    this._host = null
  }

  _onWater() {
    this._lastWater = GLib.get_monotonic_time() / 1000
    if (this._tile?.mapped && this._timeline && !this._timeline.is_playing()) {
      this._last = 0
      this._timeline.start()
    }
  }

  _frame() {
    const now = GLib.get_monotonic_time() / 1000
    const dt = this._last ? Math.min(0.05, Math.max(0, (now - this._last) / 1000)) : 1 / 60
    this._last = now
    const fresh = now - this._lastWater < STALE_MS
    const raw = bandsOf(fresh ? this._host?.waterLevels : null)
    const s = this._snd
    for (const k of ['all', 'bass']) {
      const tau = raw[k] > s[k] ? 0.04 : 0.25
      s[k] += (raw[k] - s[k]) * (1 - Math.exp(-dt / tau))
    }
    if (dt > 0 && (raw.bass - this._prevBass) / dt > 4 && raw.bass > 0.3) s.kick = 1
    this._prevBass = raw.bass
    s.kick *= Math.exp(-dt / 0.18)

    if (!fresh && s.all < 0.004 && s.kick < 0.01) return this._rest()
    this._style(Math.min(1, 1.5 * s.all + 1.2 * s.bass + 1.5 * s.kick))
  }

  _style(swell) {
    if (!this._tile) return
    if (this._busy()) {
      this._key = null // restyle as soon as the tile is ours again
      return
    }
    const rgb = glowColor(this._host?.waterColors)
    const key = glowKey(rgb, swell)
    if (key === this._key) return
    const now = GLib.get_monotonic_time() / 1000
    if (key !== '0' && now - (this._at ?? 0) < 80) return
    this._at = now
    this._key = key
    this._tile.set_style(glowStyle(rgb, Math.round(swell * 8) / 8))
  }

  _rest() {
    if (!this._tile) return
    this._timeline?.stop()
    this._snd = { all: 0, bass: 0, kick: 0 }
    this._style(0)
  }

  destroy() {
    if (this._pollId) GLib.source_remove(this._pollId)
    this._pollId = 0
    this._unwatchHost()
    this._timeline?.stop()
    this._timeline = null
    this._tile?.disconnectObject(this)
    this._tile = null
  }
}
