// SPDX-License-Identifier: GPL-2.0-or-later
// The Fetelabs logo for the start button, drawn live: the liquid in the tube
// sloshes and rises with the task bar's water, bubbles stream up through it
// with the music, and the bubbles above the tube pulse on the beat.
// The levels come from Fetelabs Task Bar's built-in Water Panel
// (global.fetelabsTaskbar.waterLevels, announced by 'water-frame').

import Clutter from 'gi://Clutter'
import GLib from 'gi://GLib'
import GObject from 'gi://GObject'
import St from 'gi://St'

import { bandsOf, drawLogo, newLogoState, stepLogo, swellOf } from './logoDraw.js'
import { glowColor, glowKey, glowStyle } from './tileGlow.js'

const STALE_MS = 250 // no water frame for this long: the music has stopped

export const LogoIcon = GObject.registerClass(
class LogoIcon extends St.DrawingArea {
    _init(size) {
        super._init({ y_align: Clutter.ActorAlign.CENTER, x_align: Clutter.ActorAlign.CENTER })
        this._st = newLogoState()
        this._lastWater = 0
        this._last = 0
        this.setSize(size)

        this.connect('repaint', () => {
            const cr = this.get_context()
            const [w, h] = this.get_surface_size()
            drawLogo(cr, w, h, this._st)
            cr.$dispose()
        })

        this._timeline = new Clutter.Timeline({ actor: this, duration: 1000, repeat_count: -1 })
        this._timeline.connect('new-frame', () => this._frame())
        // No frame clock off screen (the bar hidden or turned off): stop, and
        // start again with the next water frame once it is back.
        this.connect('notify::mapped', () => {
            if (!this.mapped) {
                this._timeline?.stop()
                this._styleTile(true)
            }
        })

        this._watchHost()
        // The task bar can be turned off and on (a new global object).
        this._pollId = GLib.timeout_add_seconds(GLib.PRIORITY_LOW, 2, () => {
            if ((global.fetelabsTaskbar ?? null) !== this._host) this._watchHost()
            return GLib.SOURCE_CONTINUE
        })
        this.connect('destroy', () => this._onDestroy())
    }

    setSize(size) {
        const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor
        this.set_size(size * scale, size * scale)
        this.queue_repaint()
    }

    _watchHost() {
        this._unwatchHost()
        this._host = global.fetelabsTaskbar ?? null
        if (this._host?.connect)
            this._hostId = this._host.connect('water-frame', () => this._onWater())
    }

    _unwatchHost() {
        if (this._hostId) {
            try {
                this._host?.disconnect(this._hostId)
            } catch {}
        }
        this._hostId = 0
        this._host = null
    }

    _onWater() {
        this._lastWater = GLib.get_monotonic_time() / 1000
        if (this.mapped && this._timeline && !this._timeline.is_playing()) {
            this._last = 0
            this._timeline.start()
        }
    }

    _frame() {
        const now = GLib.get_monotonic_time() / 1000
        const dt = this._last ? Math.min(0.05, Math.max(0, (now - this._last) / 1000)) : 1 / 60
        this._last = now
        const fresh = now - this._lastWater < STALE_MS
        if (this._host?.waterColors)
            this._st.waterColors = this._host.waterColors
        const moving = stepLogo(this._st, bandsOf(fresh ? this._host?.waterLevels : null), dt)
        this.queue_repaint()
        this._styleTile()
        if (!moving && !fresh) {
            this._timeline.stop()
            this._styleTile(true)
        }
    }

    // The start button's tile (the box this sits in): its border lights up
    // and glows with the music, in a colour that stands out against the
    // water (tileGlow.js). Only colour and shadow change, never sizes, so
    // nothing in the bar moves.
    _styleTile(rest = false) {
        const tile = this.get_parent()
        if (!tile)
            return
        const swell = rest ? 0 : Math.round(swellOf(this._st) * 8) / 8
        const rgb = glowColor(this._st.waterColors)
        // Restyling makes St parse CSS and redraw the shadow, so only a few
        // steps, at most ~12 times a second (rest always goes through).
        const key = glowKey(rgb, swell)
        if (key === this._tileKey)
            return
        const now = GLib.get_monotonic_time() / 1000
        if (!rest && now - (this._tileAt ?? 0) < 80)
            return
        this._tileAt = now
        this._tileKey = key
        tile.set_style(glowStyle(rgb, swell))
    }

    _onDestroy() {
        if (this._pollId)
            GLib.source_remove(this._pollId)
        this._pollId = 0
        this._unwatchHost()
        this._timeline?.stop()
        this._timeline = null
        this.get_parent()?.set_style(null)
    }
})
