// SPDX-License-Identifier: GPL-2.0-or-later
// Paint Splash: what the player's spot in the bar turns into while its big
// popup is open. Paint is flung at the tile on the singer's onsets (the
// vocal range of the spectrum, ~300 Hz to 3.4 kHz), blooms into splats with
// wobbling, fingered edges, throws droplets that fly, stretch and land as
// new spots or fall into a pool of paint at the bottom that rises with the
// music, sloshes, and slams on the kick.
//
// Shell free (cairo only), so it can be rendered offline. Units: the tile is
// always H = 32 tall and W wide; the caller scales.

import Cairo from 'cairo'

export const H = 32
const GRAVITY = 520 // units/s²
const DRAG = 1.6 // air, per second
const RING = 22 // points round a splat
const MAX_SPLATS = 16
const MAX_SPECKS = 70
const MAX_DROPS = 70
const MAX_DRIPS = 10
const POOL_DX = 2 // pool column width

// Vocal range in the analyser's 72 log bands (32 Hz .. 16 kHz).
const bandOf = (f, n) => Math.round((Math.log(f / 32) / Math.log(16000 / 32)) * n)

const rand = (a, b) => a + Math.random() * (b - a)
const clamp = (v, a, b) => Math.min(b, Math.max(a, v))
const gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) / 1.5

// The paint: the wallpaper's vivid lesser colours from the water, lifted.
const FALLBACK = {
  deep: [0.02, 0.28, 0.62], shallow: [0.1, 0.72, 0.95], foam: [0.72, 0.95, 1.0],
  glyphA: [0.61, 0.89, 0.18], glyphB: [1.0, 0.45, 0.68], glyphC: [1.0, 0.78, 0.2],
}

function vivid([r, g, b], minL = 0.38) {
  // Push saturation up and keep it out of the mud, like paint from the tube.
  const m = (r + g + b) / 3
  let c = [r, g, b].map((v) => clamp(m + (v - m) * 1.35, 0, 1))
  const l = 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]
  if (l < minL) c = c.map((v) => v + (1 - v) * ((minL - l) / (1 - l)))
  return c
}

const mix = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t)

export class PaintSim {
  constructor(width = 100) {
    this.W = width
    this.t = 0
    this.splats = []
    this.drops = []
    this.drips = []
    this.specks = []
    this.snd = { vocal: 0, all: 0, bass: 0, kick: 0 }
    this._flux = { mean: 0, dev: 0.01 }
    this._prev = null
    this._prevBass = 0
    this._lastOnset = -1
    this._lastKick = -1
    this._nextFlick = 0
    this._nextIdle = 0
    this.fill = 0 // pool rest level, 0..1 of the height
    this.exiting = false
    this.playing = true
    this.setColors(null)
    this._resizePool()
    this.poolColor = this.paints[0]
  }

  resize(width) {
    if (Math.abs(width - this.W) < 0.5) return
    this.W = width
    this._resizePool()
  }

  _resizePool() {
    const n = Math.max(4, Math.ceil(this.W / POOL_DX) + 1)
    const old = this.pool
    this.pool = { h: new Float32Array(n), v: new Float32Array(n) }
    if (old) for (let i = 0; i < n; i++) this.pool.h[i] = old.h[Math.min(old.h.length - 1, i)]
  }

  setColors(c) {
    const p = c ?? FALLBACK
    const key = ['glyphA', 'glyphB', 'glyphC', 'foam', 'shallow'].map((k) => (p[k] ?? FALLBACK[k]).join()).join('|')
    if (key === this._colorKey) return
    this._colorKey = key
    this.paints = [p.glyphA, p.glyphB, p.glyphC, p.foam, p.shallow].map((v, i) => vivid(v ?? FALLBACK[Object.keys(FALLBACK)[i + 1]]))
    this.foam = vivid(p.foam ?? FALLBACK.foam, 0.6)
    this.deep = p.deep ?? FALLBACK.deep
  }

  // ---- what the music does

  // raw: the analyser's levels (0..1, low first), or null when there are none.
  listen(raw, dt) {
    const s = this.snd
    if (!raw?.length) {
      for (const k of ['vocal', 'all', 'bass']) s[k] *= Math.exp(-dt / 0.3)
      this._prev = null
      return null
    }
    const n = raw.length
    const v0 = bandOf(300, n), v1 = bandOf(3400, n), b1 = Math.max(1, Math.round(n * 0.12))
    let vocal = 0, flux = 0, cen = 0, all = 0, bass = 0
    for (let i = 0; i < n; i++) all += raw[i]
    for (let i = 0; i < b1; i++) bass += raw[i]
    for (let i = v0; i < v1; i++) {
      // Weighted toward the middle of the voice (formants ~0.5-2.5 kHz).
      const w = 1 - Math.abs((i - v0) / (v1 - v0) - 0.45) * 0.9
      vocal += raw[i] * w
      cen += raw[i] * (i - v0)
      if (this._prev) flux += Math.max(0, raw[i] - this._prev[i]) * w
    }
    const span = v1 - v0
    const centroid = vocal > 0 ? cen / (vocal * span) : 0.5
    vocal /= span * 0.55
    flux /= span * 0.55
    all /= n
    bass /= b1
    if (!this._prev || this._prev.length !== n) this._prev = new Float32Array(n)
    this._prev.set(raw)

    const ease = (k, v, up, down) => (s[k] += (v - s[k]) * (1 - Math.exp(-dt / (v > s[k] ? up : down))))
    ease('vocal', vocal, 0.03, 0.22)
    ease('all', all, 0.04, 0.25)
    ease('bass', bass, 0.04, 0.25)
    const jump = (bass - this._prevBass) / Math.max(dt, 1e-3)
    this._prevBass = bass
    const kick = jump > 7 && bass > 0.45 && this.t - this._lastKick > 0.3
    if (kick) {
      s.kick = 1
      this._lastKick = this.t
    }
    s.kick *= Math.exp(-dt / 0.18)

    // Onsets: the vocal flux standing out from its own recent average.
    const f = this._flux
    const a = 1 - Math.exp(-dt / 1.2)
    const over = flux - (f.mean + 1.9 * f.dev + 0.005)
    f.mean += (flux - f.mean) * a
    f.dev += (Math.abs(flux - f.mean) - f.dev) * a
    // (Not in the first moments: the averages are still settling, and the
    // intro has just thrown its own paint.)
    const onset = over > 0 && this.t - (this._introAt ?? 0) > 0.35 && this.t - this._lastOnset > 0.14 && s.vocal > 0.06
    return { onset, strength: clamp(over / (3 * f.dev + 0.02), 0, 1) * 0.65 + clamp(s.vocal, 0, 1) * 0.35, centroid, kick }
  }

  get swell() {
    const s = this.snd
    return Math.min(1, 1.5 * s.all + 1.2 * s.bass + 1.5 * s.kick)
  }

  // ---- paint

  paint() {
    // Never the same colour twice in a row: spontaneous, not random mush.
    let i
    do i = Math.floor(Math.random() * this.paints.length)
    while (i === this._lastPaint && this.paints.length > 1)
    this._lastPaint = i
    return this.paints[i]
  }

  // A blob of paint hits the tile at (x, y).
  splash(x, y, strength, color = this.paint()) {
    strength = clamp(strength, 0.05, 1.2)
    const R = 2.2 + 7.5 * strength
    const sp = {
      x, y, R, color, age: 0,
      life: rand(2.6, 4.5) + 2 * strength,
      r: new Float32Array(RING), v: new Float32Array(RING), rest: new Float32Array(RING),
      rot: Math.random() * Math.PI * 2, wet: 1, shrink: 1,
    }
    // Fingers: a few directions throw the edge further out.
    const fingers = 2 + Math.floor(strength * 5 + Math.random() * 3)
    const dir = Array.from({ length: fingers }, () => [Math.random() * Math.PI * 2, rand(0.25, 0.9) * (0.5 + strength)])
    for (let k = 0; k < RING; k++) {
      const a = (k / RING) * Math.PI * 2
      let reach = 1 + 0.12 * gauss()
      for (const [d, amt] of dir) {
        const da = Math.atan2(Math.sin(a - d), Math.cos(a - d))
        reach += amt * Math.exp(-(da * da) / 0.035)
      }
      sp.rest[k] = R * reach
      sp.r[k] = R * 0.15
      sp.v[k] = R * reach * rand(14, 22) // blooms out and overshoots
    }
    this.splats.push(sp)
    if (this.splats.length > MAX_SPLATS) for (const old of this.splats.slice(0, this.splats.length - MAX_SPLATS)) old.life = Math.min(old.life, old.age + 0.3)

    // Droplets flung out along the fingers and at random.
    const n = Math.round(2 + strength * 11)
    for (let k = 0; k < n && this.drops.length < MAX_DROPS; k++) {
      const d = k < dir.length ? dir[k][0] : Math.random() * Math.PI * 2
      const speed = rand(60, 120) + 220 * strength * Math.random()
      this.drops.push({
        x: x + Math.cos(d) * R * 0.6, y: y + Math.sin(d) * R * 0.6,
        vx: Math.cos(d) * speed, vy: Math.sin(d) * speed - rand(20, 80) * strength,
        r: rand(0.6, 1.1) + 1.2 * strength * Math.random(), color, flight: rand(0.12, 0.45),
      })
    }
    // Heavy, fresh paint runs: a drip off the bottom edge.
    if (strength > 0.45 && this.drips.length < MAX_DRIPS && Math.random() < 0.7) {
      const off = gauss() * R * 0.5
      this.drips.push({ x: x + off, y0: y + R * 0.6, y: y + R * 0.6, v: 0, w: rand(0.9, 1.6) * (0.6 + strength), color, age: 0 })
    }
    this.poolColor = mix(this.poolColor, color, 0.25)
  }

  // A hit into the pool: the surface dips, a crown of droplets jumps out.
  _plunge(x, power, color) {
    const p = this.pool
    const i = clamp(Math.round(x / POOL_DX), 0, p.h.length - 1)
    for (let k = -2; k <= 2; k++) {
      const j = i + k
      if (j >= 0 && j < p.h.length) p.v[j] -= power * (k ? 0.5 : 1)
    }
    if (color) this.poolColor = mix(this.poolColor, color, 0.08)
  }

  _crown(x, power) {
    const surf = this.surfaceAt(x)
    const n = Math.round(2 + 4 * power)
    for (let k = 0; k < n && this.drops.length < MAX_DROPS; k++) {
      const side = k % 2 ? 1 : -1
      this.drops.push({
        x: x + side * rand(0.5, 2), y: surf - 0.5, vx: side * rand(15, 70) * (0.5 + power), vy: -rand(80, 170) * (0.4 + power),
        r: rand(0.5, 1.1), color: this.poolColor, flight: 9, fromPool: true,
      })
    }
  }

  surfaceAt(x) {
    const p = this.pool
    const f = clamp(x / POOL_DX, 0, p.h.length - 1)
    const i = Math.floor(f), j = Math.min(p.h.length - 1, i + 1)
    return H - (p.h[i] + (p.h[j] - p.h[i]) * (f - i))
  }

  // Splashing in: one big throw in the middle and two smaller ones beside it.
  intro() {
    this.exiting = false
    this.splats = []
    this.drops = []
    this.drips = []
    this.specks = []
    this.pool.h.fill(0)
    this.pool.v.fill(0)
    this.fill = 0
    this._introAt = this.t
    this.splash(this.W * 0.5, H * 0.46, 1.1)
    this.splash(this.W * rand(0.15, 0.3), H * rand(0.3, 0.6), rand(0.35, 0.6))
    this.splash(this.W * rand(0.7, 0.85), H * rand(0.3, 0.6), rand(0.35, 0.6))
    for (let i = 0; i < this.pool.v.length; i++) this.pool.v[i] += rand(20, 45)
  }

  // Drawing back out: the paint shrinks away and the pool drains.
  exit() {
    this.exiting = true
  }

  // ---- one step; returns true while anything moves

  step(dt, hear) {
    if (!(dt > 0)) return true
    dt = Math.min(dt, 0.05)
    this.t += dt
    const s = this.snd

    if (!this.exiting && this.playing) {
      if (hear) {
        if (hear.onset) {
          this._lastOnset = this.t
          // Anywhere on the tile, leaning right as the voice gets brighter;
          // never right on top of the last throw.
          let x
          for (let k = 0; k < 4; k++) {
            x = clamp(this.W * (0.3 * hear.centroid + 0.7 * Math.random()) * 1.1 - this.W * 0.05, 4, this.W - 4)
            if (Math.abs(x - (this._lastX ?? -99)) > this.W * 0.18) break
          }
          this._lastX = x
          this.splash(x, rand(H * 0.18, H * 0.68), 0.25 + hear.strength)
        }
        if (hear.kick) {
          // The kick slams the pool and throws a crown.
          for (let k = 0; k < 2; k++) {
            const x = rand(this.W * 0.15, this.W * 0.85)
            this._plunge(x, 40 + 50 * s.bass)
            this._crown(x, 0.4 + 0.6 * s.bass)
          }
        }
        // A held note keeps flicking fine spray.
        if (s.vocal > 0.18 && this.t > this._nextFlick && this.t - this._lastOnset > 0.2) {
          this._nextFlick = this.t + rand(0.08, 0.35) / (0.5 + s.vocal)
          const sp = this.splats[this.splats.length - 1]
          const x = sp ? sp.x : rand(0, this.W), y = sp ? sp.y : H * 0.4
          const a = Math.random() * Math.PI * 2, v = rand(60, 160) * (0.4 + s.vocal)
          if (this.drops.length < MAX_DROPS)
            this.drops.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 40, r: rand(0.4, 0.9), color: sp?.color ?? this.paint(), flight: rand(0.1, 0.3) })
        }
      } else if (this.t > this._nextIdle) {
        // No spectrum (Water Panel off): keep painting gently anyway.
        this._nextIdle = this.t + rand(0.35, 1.1)
        this.splash(rand(4, this.W - 4), rand(H * 0.2, H * 0.65), rand(0.2, 0.7))
      }
    }

    // The pool fills with the music and drains on the way out.
    const restFill = this.exiting ? -0.05 : this.playing ? 0.1 + 0.22 * clamp(s.all * 1.6, 0, 1) + 0.12 * s.bass : 0.06
    this.fill += (restFill - this.fill) * (1 - Math.exp(-dt / (this.exiting ? 0.12 : 0.5)))
    const p = this.pool, n = p.h.length, rest = Math.max(0, this.fill) * H
    // Shallow water waves, substepped for stability.
    const sub = 8, h = dt / sub
    for (let it = 0; it < sub; it++) {
      for (let i = 0; i < n; i++) {
        const l = p.h[i ? i - 1 : 0], r = p.h[i < n - 1 ? i + 1 : n - 1]
        const lap = l + r - 2 * p.h[i]
        p.v[i] += ((420 / (POOL_DX * POOL_DX)) * lap + 30 * (rest - p.h[i]) - 4.5 * p.v[i]) * h
      }
      for (let i = 0; i < n; i++) p.h[i] = Math.max(0, p.h[i] + p.v[i] * h)
    }

    let moving = rest > 0.05
    // Splats: a damped spring per edge point, with surface tension pulling
    // each toward its neighbours. They dry (lose their sheen), then fade.
    for (const sp of this.splats) {
      sp.age += dt
      sp.wet = Math.exp(-sp.age / 0.9)
      if (this.exiting) sp.shrink *= Math.exp(-dt / 0.12)
      const r = sp.r, v = sp.v, rs = sp.rest
      for (let k = 0; k < RING; k++) {
        const lap = r[(k + RING - 1) % RING] + r[(k + 1) % RING] - 2 * r[k]
        v[k] += (900 * (rs[k] * sp.shrink - r[k]) + 260 * lap - 34 * v[k]) * dt
      }
      for (let k = 0; k < RING; k++) r[k] = Math.max(0, r[k] + v[k] * dt)
      moving = true
    }
    this.splats = this.splats.filter((sp) => sp.age < sp.life + 0.8 && sp.shrink > 0.03)

    // Drips: run down under gravity against the paint's drag, thinning out.
    for (const d of this.drips) {
      d.age += dt
      d.v += (90 - 6 * d.v) * dt
      d.y += d.v * dt
      d.w *= Math.exp(-dt / 2.2)
      if (this.exiting) d.w *= Math.exp(-dt / 0.1)
      if (d.y >= this.surfaceAt(d.x)) {
        this._plunge(d.x, 6 * d.w, d.color)
        d.dead = true
      }
    }
    this.drips = this.drips.filter((d) => !d.dead && d.w > 0.15)

    // Droplets: ballistic with drag; they land on the tile when their flight
    // is over, or fall into the pool.
    for (const d of this.drops) {
      d.vx -= d.vx * DRAG * dt
      d.vy += (GRAVITY - d.vy * DRAG) * dt
      d.x += d.vx * dt
      d.y += d.vy * dt
      d.flight -= dt
      if (d.x < 0 || d.x > this.W) {
        d.x = clamp(d.x, 0, this.W)
        d.vx *= -0.3
      }
      if (d.y < 0) {
        d.y = 0
        d.vy *= -0.3
      }
      if (d.vy > 0 && d.y >= this.surfaceAt(d.x)) {
        const speed = Math.hypot(d.vx, d.vy)
        this._plunge(d.x, d.r * speed * 0.12, d.color)
        if (speed > 150 && !d.fromPool && Math.random() < 0.35) this._crown(d.x, 0.25)
        d.dead = true
      } else if (d.flight <= 0) {
        // Lands on the tile: a speck, squashed along the way it was going.
        if (!this.exiting) {
          this.specks.push({ x: d.x, y: d.y, r: d.r * rand(0.9, 1.3), a: Math.atan2(d.vy, d.vx), s: 1 + Math.min(1.2, Math.hypot(d.vx, d.vy) / 220), color: d.color, age: 0, life: rand(1.5, 3.5) })
          if (this.specks.length > MAX_SPECKS) this.specks.shift()
        }
        d.dead = true
      }
      moving = true
    }
    this.drops = this.drops.filter((d) => !d.dead)

    for (const sp of this.specks) sp.age += this.exiting ? dt * 6 : dt
    this.specks = this.specks.filter((sp) => sp.age < sp.life)
    return moving || this.specks.length > 0
  }

  get done() {
    return this.exiting && !this.splats.length && !this.drops.length && !this.drips.length && !this.specks.length && this.pool.h.every((v) => v < 0.1)
  }

  // ---- drawing (cr in surface pixels; w x h surface; radius = tile corners)

  draw(cr, w, h, radius = 10, alpha = 1) {
    const k = h / H
    this.resize(w / k)
    cr.save()
    cr.setOperator(Cairo.Operator.CLEAR)
    cr.paint()
    cr.setOperator(Cairo.Operator.OVER)
    roundRect(cr, 0, 0, w, h, radius)
    cr.clip()
    cr.scale(k, k)

    // Drips sit on the tile under the fresh paint.
    cr.setLineCap(Cairo.LineCap.ROUND)
    for (const d of this.drips) {
      cr.setSourceRGBA(...d.color, 0.92 * alpha)
      cr.setLineWidth(d.w)
      cr.moveTo(d.x, d.y0)
      cr.curveTo(d.x, (d.y0 + d.y) / 2, d.x + 0.3, d.y - 0.5, d.x, d.y)
      cr.stroke()
      cr.arc(d.x, d.y, d.w * 0.75, 0, Math.PI * 2)
      cr.fill()
    }

    for (const sp of this.specks) {
      const fade = clamp((sp.life - sp.age) / 0.6, 0, 1) * alpha
      cr.save()
      cr.translate(sp.x, sp.y)
      cr.rotate(sp.a)
      cr.scale(sp.s, 1 / Math.sqrt(sp.s))
      cr.arc(0, 0, sp.r, 0, Math.PI * 2)
      cr.restore()
      cr.setSourceRGBA(...sp.color, 0.9 * fade)
      cr.fill()
    }

    for (const sp of this.splats) {
      const fade = clamp((sp.life + 0.8 - sp.age) / 0.8, 0, 1) * alpha
      if (fade <= 0) continue
      ringPath(cr, sp, 0, 0.6)
      cr.setSourceRGBA(0, 0, 0, 0.22 * fade)
      cr.fill()
      ringPath(cr, sp)
      // Paint is thicker in the middle: a soft radial body.
      const g = new Cairo.RadialGradient(sp.x - sp.R * 0.25, sp.y - sp.R * 0.3, 0, sp.x, sp.y, sp.R * 1.4)
      g.addColorStopRGBA(0, ...mix(sp.color, [1, 1, 1], 0.18), fade)
      g.addColorStopRGBA(1, ...mix(sp.color, [0, 0, 0], 0.12), fade)
      cr.setSource(g)
      cr.fillPreserve()
      // A thin darker rim, so paint over paint still reads as two layers.
      cr.setSourceRGBA(...mix(sp.color, [0, 0, 0], 0.35), 0.45 * fade)
      cr.setLineWidth(0.35)
      cr.stroke()
      if (sp.wet > 0.05) {
        // Wet sheen, gone as it dries.
        cr.setSourceRGBA(1, 1, 1, 0.55 * sp.wet * fade)
        cr.save()
        cr.translate(sp.x - sp.R * 0.32, sp.y - sp.R * 0.38)
        cr.scale(1, 0.55)
        cr.arc(0, 0, Math.max(0.4, sp.R * 0.28 * sp.shrink), 0, Math.PI * 2)
        cr.restore()
        cr.fill()
      }
    }

    // The pool: surface curve, a gradient body and a foam line.
    const p = this.pool
    if (p.h.some((v) => v > 0.05)) {
      cr.moveTo(0, H + 1)
      cr.lineTo(0, H - p.h[0])
      for (let i = 1; i < p.h.length; i++) {
        const x0 = (i - 1) * POOL_DX, x1 = i * POOL_DX
        cr.curveTo(x0 + POOL_DX / 2, H - p.h[i - 1], x1 - POOL_DX / 2, H - p.h[i], x1, H - p.h[i])
      }
      cr.lineTo(this.W, H + 1)
      cr.closePath()
      const top = H - Math.max(...p.h)
      const g = new Cairo.LinearGradient(0, top, 0, H)
      g.addColorStopRGBA(0, ...mix(this.poolColor, [1, 1, 1], 0.12), 0.95 * alpha)
      g.addColorStopRGBA(1, ...mix(this.poolColor, this.deep, 0.55), 0.95 * alpha)
      cr.setSource(g)
      cr.fillPreserve()
      cr.newPath()
      cr.moveTo(0, H - p.h[0])
      for (let i = 1; i < p.h.length; i++) {
        const x0 = (i - 1) * POOL_DX, x1 = i * POOL_DX
        cr.curveTo(x0 + POOL_DX / 2, H - p.h[i - 1], x1 - POOL_DX / 2, H - p.h[i], x1, H - p.h[i])
      }
      cr.setLineWidth(0.7)
      cr.setSourceRGBA(...this.foam, 0.7 * alpha)
      cr.stroke()
    }

    // Droplets in flight, stretched along their speed.
    for (const d of this.drops) {
      const speed = Math.hypot(d.vx, d.vy)
      cr.save()
      cr.translate(d.x, d.y)
      cr.rotate(Math.atan2(d.vy, d.vx))
      cr.scale(1 + Math.min(2.2, speed / 140), 1 / (1 + Math.min(0.5, speed / 600)))
      cr.arc(0, 0, d.r, 0, Math.PI * 2)
      cr.restore()
      cr.setSourceRGBA(...d.color, alpha)
      cr.fill()
    }
    cr.restore()
  }
}

function roundRect(cr, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2)
  cr.newSubPath()
  cr.arc(x + w - r, y + r, r, -Math.PI / 2, 0)
  cr.arc(x + w - r, y + h - r, r, 0, Math.PI / 2)
  cr.arc(x + r, y + h - r, r, Math.PI / 2, Math.PI)
  cr.arc(x + r, y + r, r, Math.PI, 1.5 * Math.PI)
  cr.closePath()
}

// A smooth closed curve through the splat's edge (midpoint quadratics).
function ringPath(cr, sp, dx = 0, dy = 0) {
  const pts = []
  for (let k = 0; k < RING; k++) {
    const a = sp.rot + (k / RING) * Math.PI * 2
    pts.push([sp.x + dx + Math.cos(a) * sp.r[k], sp.y + dy + Math.sin(a) * sp.r[k]])
  }
  const mid = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]
  let m = mid(pts[RING - 1], pts[0])
  cr.newPath()
  cr.moveTo(...m)
  for (let k = 0; k < RING; k++) {
    const c = pts[k], n = mid(c, pts[(k + 1) % RING])
    // Quadratic (m, c, n) as a cubic.
    cr.curveTo(m[0] + (2 / 3) * (c[0] - m[0]), m[1] + (2 / 3) * (c[1] - m[1]), n[0] + (2 / 3) * (c[0] - n[0]), n[1] + (2 / 3) * (c[1] - n[1]), n[0], n[1])
    m = n
  }
  cr.closePath()
}
