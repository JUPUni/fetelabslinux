// SPDX-License-Identifier: GPL-2.0-or-later
// Paint Splash: what the player's spot in the bar turns into while its big
// popup is open. Paint is flung at the tile on the singer's onsets (the
// vocal range of the spectrum, ~300 Hz to 3.4 kHz), blooms into splats with
// wobbling, fingered edges, throws droplets that fly, stretch and land as
// new spots. Paint that reaches the tile's sides sticks and runs down them;
// paint that reaches the floor squashes flat and beads along the bottom
// edge. The kick shakes every wet splat and flings spray off it.
//
// Shell free (cairo only), so it can be rendered offline. Units: the tile is
// always H = 32 tall and W wide; the caller scales.

import Cairo from 'cairo'

export const H = 32
const GRAVITY = 520 // units/s²
const DRAG = 1.6 // air, per second
const RING = 22 // points round a splat
const MAX_SPLATS = 16
const MAX_SPECKS = 70
const MAX_DROPS = 70
const MAX_DRIPS = 18
const MAX_BEADS = 24
const WALL = 0.6 // how close to an edge counts as hitting it

// Vocal range in the analyser's 72 log bands (32 Hz .. 16 kHz).
const bandOf = (f, n) => Math.round((Math.log(f / 32) / Math.log(16000 / 32)) * n)

const rand = (a, b) => a + Math.random() * (b - a)
const clamp = (v, a, b) => Math.min(b, Math.max(a, v))
const gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) / 1.5

// The paint: the wallpaper's vivid lesser colours from the water, lifted.
const FALLBACK = {
  deep: [0.02, 0.28, 0.62], shallow: [0.1, 0.72, 0.95], foam: [0.72, 0.95, 1.0],
  glyphA: [0.61, 0.89, 0.18], glyphB: [1.0, 0.45, 0.68], glyphC: [1.0, 0.78, 0.2],
}

function vivid([r, g, b], minL = 0.38) {
  // Push saturation up and keep it out of the mud, like paint from the tube.
  const m = (r + g + b) / 3
  let c = [r, g, b].map((v) => clamp(m + (v - m) * 1.35, 0, 1))
  const l = 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]
  if (l < minL) c = c.map((v) => v + (1 - v) * ((minL - l) / (1 - l)))
  return c
}

const mix = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t)

export class PaintSim {
  constructor(width = 100) {
    this.W = width
    this.t = 0
    this.splats = []
    this.drops = []
    this.drips = []
    this.specks = []
    this.beads = [] // paint gathered on the floor edge
    this.snd = { vocal: 0, all: 0, bass: 0, kick: 0 }
    this._flux = { mean: 0, dev: 0.01 }
    this._prev = null
    this._prevBass = 0
    this._lastOnset = -1
    this._lastKick = -1
    this._nextFlick = 0
    this._nextIdle = 0
    this.exiting = false
    this.playing = true
    this.setColors(null)
  }

  resize(width) {
    if (Math.abs(width - this.W) < 0.5) return
    this.W = width
  }

  setColors(c) {
    const p = c ?? FALLBACK
    const key = ['glyphA', 'glyphB', 'glyphC', 'foam', 'shallow'].map((k) => (p[k] ?? FALLBACK[k]).join()).join('|')
    if (key === this._colorKey) return
    this._colorKey = key
    this.paints = ['glyphA', 'glyphB', 'glyphC', 'foam', 'shallow'].map((k) => vivid(p[k] ?? FALLBACK[k]))
  }

  // ---- what the music does

  // raw: the analyser's levels (0..1, low first), or null when there are none.
  listen(raw, dt) {
    const s = this.snd
    this._clock = (this._clock ?? 0) + dt
    if (!raw?.length) {
      for (const k of ['vocal', 'all', 'bass']) s[k] *= Math.exp(-dt / 0.3)
      this._prev = null
      return null
    }
    const n = raw.length
    if (this._prev?.length !== n) this._prev = null
    else if (this._same(raw)) return this._hear && { ...this._hear, onset: false, kick: false } // the display outran the analyser
    const v0 = bandOf(300, n), v1 = bandOf(3400, n), b1 = Math.max(1, Math.round(n * 0.12))
    let vocal = 0, flux = 0, cen = 0, all = 0, bass = 0
    for (let i = 0; i < n; i++) all += raw[i]
    for (let i = 0; i < b1; i++) bass += raw[i]
    for (let i = v0; i < v1; i++) {
      // Weighted toward the middle of the voice (formants ~0.5-2.5 kHz).
      const w = 1 - Math.abs((i - v0) / (v1 - v0) - 0.45) * 0.9
      vocal += raw[i] * w
      cen += raw[i] * (i - v0)
      if (this._prev) flux += Math.max(0, raw[i] - this._prev[i]) * w
    }
    const span = v1 - v0
    const centroid = vocal > 0 ? cen / (vocal * span) : 0.5
    vocal /= span * 0.55
    flux /= span * 0.55
    all /= n
    bass /= b1
    if (!this._prev) this._prev = new Float32Array(n)
    this._prev.set(raw)
    // The rates below go by the time since the last new spectrum.
    dt = Math.min(0.1, Math.max(dt, this._clock - (this._heardAt ?? this._clock - dt)))
    this._heardAt = this._clock

    const ease = (k, v, up, down) => (s[k] += (v - s[k]) * (1 - Math.exp(-dt / (v > s[k] ? up : down))))
    ease('vocal', vocal, 0.03, 0.22)
    ease('all', all, 0.04, 0.25)
    ease('bass', bass, 0.04, 0.25)
    const jump = (bass - this._prevBass) / Math.max(dt, 1e-3)
    this._prevBass = bass
    const kick = jump > 7 && bass > 0.45 && this.t - this._lastKick > 0.3
    if (kick) {
      s.kick = 1
      this._lastKick = this.t
    }
    s.kick *= Math.exp(-dt / 0.18)

    // Onsets: the vocal flux standing out from its own recent average.
    const f = this._flux
    const a = 1 - Math.exp(-dt / 1.2)
    const over = flux - (f.mean + 1.9 * f.dev + 0.005)
    f.mean += (flux - f.mean) * a
    f.dev += (Math.abs(flux - f.mean) - f.dev) * a
    // (Not in the first moments: the averages are still settling, and the
    // intro has just thrown its own paint.)
    const onset = over > 0 && this.t - (this._introAt ?? 0) > 0.35 && this.t - this._lastOnset > 0.14 && s.vocal > 0.06
    return (this._hear = { onset, strength: clamp(over / (3 * f.dev + 0.02), 0, 1) * 0.65 + clamp(s.vocal, 0, 1) * 0.35, centroid, kick })
  }

  _same(raw) {
    const p = this._prev
    for (let i = 0; i < raw.length; i++) if (raw[i] !== p[i]) return false
    return true
  }

  get swell() {
    const s = this.snd
    return Math.min(1, 1.5 * s.all + 1.2 * s.bass + 1.5 * s.kick)
  }

  // ---- paint

  paint() {
    // Never the same colour twice in a row: spontaneous, not random mush.
    let i
    do i = Math.floor(Math.random() * this.paints.length)
    while (i === this._lastPaint && this.paints.length > 1)
    this._lastPaint = i
    return this.paints[i]
  }

  // A blob of paint hits the tile at (x, y).
  splash(x, y, strength, color = this.paint()) {
    strength = clamp(strength, 0.05, 1.2)
    const R = 2.2 + 7.5 * strength
    const sp = {
      x, y, R, color, age: 0,
      life: rand(2.6, 4.5) + 2 * strength,
      r: new Float32Array(RING), v: new Float32Array(RING), rest: new Float32Array(RING),
      rot: Math.random() * Math.PI * 2, wet: 1, shrink: 1,
    }
    // Fingers: a few directions throw the edge further out.
    const fingers = 2 + Math.floor(strength * 5 + Math.random() * 3)
    const dir = Array.from({ length: fingers }, () => [Math.random() * Math.PI * 2, rand(0.25, 0.9) * (0.5 + strength)])
    for (let k = 0; k < RING; k++) {
      const a = (k / RING) * Math.PI * 2
      let reach = 1 + 0.12 * gauss()
      for (const [d, amt] of dir) {
        const da = Math.atan2(Math.sin(a - d), Math.cos(a - d))
        reach += amt * Math.exp(-(da * da) / 0.035)
      }
      sp.rest[k] = R * reach
      sp.r[k] = R * 0.15
      sp.v[k] = R * reach * rand(14, 22) // blooms out and overshoots
    }
    this.splats.push(sp)
    if (this.splats.length > MAX_SPLATS) for (const old of this.splats.slice(0, this.splats.length - MAX_SPLATS)) old.life = Math.min(old.life, old.age + 0.3)

    // Droplets flung out along the fingers and at random.
    const n = Math.round(2 + strength * 11)
    for (let k = 0; k < n && this.drops.length < MAX_DROPS; k++) {
      const d = k < dir.length ? dir[k][0] : Math.random() * Math.PI * 2
      const speed = rand(60, 120) + 220 * strength * Math.random()
      this.drops.push({
        x: x + Math.cos(d) * R * 0.6, y: y + Math.sin(d) * R * 0.6,
        vx: Math.cos(d) * speed, vy: Math.sin(d) * speed - rand(20, 80) * strength,
        r: rand(0.6, 1.1) + 1.2 * strength * Math.random(), color, flight: rand(0.12, 0.45),
      })
    }
    // Heavy, fresh paint runs: drips off its lower edge, more the heavier.
    const runs = strength > 0.35 ? 1 + (Math.random() < strength - 0.3 ? 1 : 0) : 0
    for (let k = 0; k < runs; k++) this._drip(x + gauss() * R * 0.6, y + R * rand(0.4, 0.8), rand(0.9, 1.6) * (0.6 + strength), color)
    // A splat that reaches a side wets it, and that runs down the side.
    if (x - R * 1.3 < WALL * 3) this._drip(0.7, y + rand(-0.3, 0.5) * R, rand(1, 1.8) * (0.6 + strength), color, true)
    if (x + R * 1.3 > this.W - WALL * 3) this._drip(this.W - 0.7, y + rand(-0.3, 0.5) * R, rand(1, 1.8) * (0.6 + strength), color, true)
  }

  // A run of paint: starts slow, finds its speed against the paint's drag,
  // and leaves itself behind as a trail, thinning till it stops.
  _drip(x, y, w, color, wall = false) {
    if (this.drips.length >= MAX_DRIPS || y >= H - 1) return
    this.drips.push({ x, y0: y, y, v: rand(0, 4), w, w0: w, color, age: 0, wall, wob: rand(0, 6), stopped: false, dry: 0 })
  }

  // Paint reaching the floor: it flattens into a bead along the bottom edge,
  // merging with any wet bead already there.
  _bead(x, amount, color, vx = 0) {
    for (const b of this.beads) {
      if (Math.abs(b.x - x) < b.w * 0.5 + 1.5) {
        const m = b.m + amount
        b.x = (b.x * b.m + x * amount) / m
        b.color = mix(b.color, color, amount / m)
        b.m = Math.min(m, 9)
        b.vx += (vx * amount) / m
        b.w = 2 + 1.6 * Math.sqrt(b.m)
        b.age = Math.min(b.age, 0.2)
        return
      }
    }
    this.beads.push({ x, m: amount, w: 2 + 1.6 * Math.sqrt(amount), vx: vx * 0.4, color, age: 0, life: rand(3, 5.5), wob: 0, wv: 6 * amount })
    if (this.beads.length > MAX_BEADS) this.beads.shift()
  }

  // Paint hitting a hard edge fast throws a few tiny secondary droplets.
  _rebound(x, y, vx, vy, color, n) {
    for (let k = 0; k < n && this.drops.length < MAX_DROPS; k++) {
      this.drops.push({ x, y, vx: vx + rand(-50, 50), vy: vy + rand(-40, 10), r: rand(0.3, 0.6), color, flight: rand(0.05, 0.18), small: true })
    }
  }

  // Splashing in: one big throw in the middle and two smaller ones beside it.
  intro() {
    this.exiting = false
    this.splats = []
    this.drops = []
    this.drips = []
    this.specks = []
    this.beads = []
    this._introAt = this.t
    this.splash(this.W * 0.5, H * 0.46, 1.1)
    this.splash(this.W * rand(0.15, 0.3), H * rand(0.3, 0.6), rand(0.35, 0.6))
    this.splash(this.W * rand(0.7, 0.85), H * rand(0.3, 0.6), rand(0.35, 0.6))
  }

  // Drawing back out: the paint shrinks away.
  exit() {
    this.exiting = true
  }

  // ---- one step; returns true while anything moves

  // engine: whether a spectrum exists at all (false: the Water Panel is off,
  // so paint gently on its own; true but no hear: the music is quiet).
  step(dt, hear, engine = true) {
    if (!(dt > 0)) return true
    dt = Math.min(dt, 0.05)
    this.t += dt
    const s = this.snd

    if (!this.exiting && this.playing) {
      if (hear) {
        if (hear.onset) {
          this._lastOnset = this.t
          // Anywhere on the tile, leaning right as the voice gets brighter;
          // never right on top of the last throw.
          let x
          for (let k = 0; k < 4; k++) {
            x = clamp(this.W * (0.3 * hear.centroid + 0.7 * Math.random()) * 1.1 - this.W * 0.05, 4, this.W - 4)
            if (Math.abs(x - (this._lastX ?? -99)) > this.W * 0.18) break
          }
          this._lastX = x
          this.splash(x, rand(H * 0.18, H * 0.68), 0.25 + hear.strength)
        }
        if (hear.kick) {
          // The kick hits the whole tile: wet splats shudder and shed spray,
          // beads on the floor jump, runs lurch down.
          const power = 0.4 + 0.6 * s.bass
          for (const sp of this.splats) {
            if (sp.wet < 0.08) continue
            for (let k = 0; k < RING; k++) sp.v[k] += sp.R * rand(-18, 26) * power * sp.wet
            const n = Math.round(1 + 3 * power * sp.wet)
            for (let k = 0; k < n && this.drops.length < MAX_DROPS; k++) {
              const a = Math.random() * Math.PI * 2, v = rand(70, 170) * power
              const r0 = sp.R * 0.9
              this.drops.push({ x: sp.x + Math.cos(a) * r0, y: sp.y + Math.sin(a) * r0, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 50 * power, r: rand(0.4, 0.9), color: sp.color, flight: rand(0.12, 0.35) })
            }
          }
          for (const b of this.beads) if (b.age < 1.5) this._rebound(b.x, H - 0.6, 0, -rand(90, 150) * power, b.color, b.m > 2 ? 2 : 1)
          for (const d of this.drips) if (!d.stopped) d.v += 25 * power
        }
        // A held note keeps flicking fine spray.
        if (s.vocal > 0.18 && this.t > this._nextFlick && this.t - this._lastOnset > 0.2) {
          this._nextFlick = this.t + rand(0.08, 0.35) / (0.5 + s.vocal)
          const sp = this.splats[this.splats.length - 1]
          const x = sp ? sp.x : rand(0, this.W), y = sp ? sp.y : H * 0.4
          const a = Math.random() * Math.PI * 2, v = rand(60, 160) * (0.4 + s.vocal)
          if (this.drops.length < MAX_DROPS)
            this.drops.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 40, r: rand(0.4, 0.9), color: sp?.color ?? this.paint(), flight: rand(0.1, 0.3) })
        }
      } else if (!engine && this.t > this._nextIdle) {
        // No spectrum (Water Panel off): keep painting gently anyway.
        this._nextIdle = this.t + rand(0.35, 1.1)
        this.splash(rand(4, this.W - 4), rand(H * 0.2, H * 0.65), rand(0.2, 0.7))
      }
    }

    let moving = false
    // Splats: a damped spring per edge point, with surface tension pulling
    // each toward its neighbours. They dry (lose their sheen), then fade.
    for (const sp of this.splats) {
      sp.age += dt
      sp.wet = Math.exp(-sp.age / 0.9)
      if (this.exiting) sp.shrink *= Math.exp(-dt / 0.12)
      const r = sp.r, v = sp.v, rs = sp.rest
      for (let k = 0; k < RING; k++) {
        const lap = r[(k + RING - 1) % RING] + r[(k + 1) % RING] - 2 * r[k]
        v[k] += (900 * (rs[k] * sp.shrink - r[k]) + 260 * lap - 34 * v[k]) * dt
      }
      for (let k = 0; k < RING; k++) r[k] = Math.max(0, r[k] + v[k] * dt)
      moving = true
    }
    this.splats = this.splats.filter((sp) => sp.age < sp.life + 0.8 && sp.shrink > 0.03)

    // Drips: viscous runs. Gravity against the paint's drag gives a slow
    // terminal speed; the paint left on the trail thins the head until it
    // stops dead and dries where it is. One that makes the floor beads there.
    for (const d of this.drips) {
      d.age += dt
      if (!d.stopped) {
        const head = d.w / d.w0 // how much paint is left at the head
        d.v += ((70 + 50 * head) - 5.5 * d.v) * dt
        d.y += d.v * dt
        d.w -= d.v * dt * 0.012 * (d.wall ? 0.6 : 1) // lays paint on the way
        if (d.w < 0.35) d.stopped = true
        if (d.y >= H - d.w * 0.4) {
          d.y = H - d.w * 0.4
          this._bead(d.x, 0.6 + d.w, d.color)
          d.stopped = true
        }
      } else d.dry += dt
      if (this.exiting) d.dry += dt * 8
    }
    this.drips = this.drips.filter((d) => d.dry < 3)

    // Droplets: ballistic with drag. They stop on the tile when their flight
    // is over, stick to a side wall (and run down it), or hit the floor and
    // squash into a bead.
    for (const d of this.drops) {
      d.vx -= d.vx * DRAG * dt
      d.vy += (GRAVITY - d.vy * DRAG) * dt
      d.x += d.vx * dt
      d.y += d.vy * dt
      d.flight -= dt
      if (d.y < d.r) {
        d.y = d.r
        d.vy *= -0.25
        d.vx *= 0.6
      }
      const hitL = d.x < d.r, hitR = d.x > this.W - d.r
      if (hitL || hitR) {
        d.x = hitL ? 0.5 : this.W - 0.5
        if (!this.exiting) {
          this.specks.push({ x: d.x, y: d.y, r: d.r * 1.2, a: Math.PI / 2, s: 1 + Math.min(1, Math.abs(d.vy) / 200), color: d.color, age: 0, life: rand(2, 3.5) })
          if (!d.small && d.r > 0.6) this._drip(d.x + (hitL ? 0.3 : -0.3), d.y, d.r * 1.3, d.color, true)
          if (Math.abs(d.vx) > 140 && !d.small) this._rebound(d.x, d.y, -d.vx * 0.25, d.vy * 0.4, d.color, 2)
        }
        d.dead = true
      } else if (d.y >= H - d.r * 0.5) {
        if (!this.exiting) {
          this._bead(clamp(d.x, 1, this.W - 1), d.r * d.r * 0.8, d.color, d.vx)
          if (d.vy > 160 && !d.small) this._rebound(d.x, H - 0.8, d.vx * 0.3, -d.vy * 0.3, d.color, Math.random() < 0.5 ? 2 : 1)
        }
        d.dead = true
      } else if (d.flight <= 0) {
        // Lands on the tile: a speck, squashed along the way it was going.
        if (!this.exiting) {
          this.specks.push({ x: d.x, y: d.y, r: d.r * rand(0.9, 1.3), a: Math.atan2(d.vy, d.vx), s: 1 + Math.min(1.2, Math.hypot(d.vx, d.vy) / 220), color: d.color, age: 0, life: rand(1.5, 3.5) })
          if (this.specks.length > MAX_SPECKS) this.specks.shift()
          // A fat, fast drop is wet enough to run.
          if (d.r > 1.3 && Math.random() < 0.4) this._drip(d.x, d.y + d.r * 0.5, d.r * 0.9, d.color)
        }
        d.dead = true
      }
      moving = true
    }
    this.drops = this.drops.filter((d) => !d.dead)
    if (this.specks.length > MAX_SPECKS) this.specks.splice(0, this.specks.length - MAX_SPECKS)

    // Beads on the floor: spread a little sideways with what hit them,
    // wobble from the impact (a damped spring on their height), then dry.
    for (const b of this.beads) {
      b.age += this.exiting ? dt * 6 : dt
      b.x = clamp(b.x + b.vx * dt, b.w * 0.5, this.W - b.w * 0.5)
      b.vx *= Math.exp(-dt / 0.08)
      b.wv += (-900 * b.wob - 18 * b.wv) * dt
      b.wob += b.wv * dt
    }
    this.beads = this.beads.filter((b) => b.age < b.life)

    for (const sp of this.specks) sp.age += this.exiting ? dt * 6 : dt
    this.specks = this.specks.filter((sp) => sp.age < sp.life)
    return moving || this.specks.length > 0 || this.drips.length > 0 || this.beads.length > 0
  }

  get done() {
    return this.exiting && !this.splats.length && !this.drops.length && !this.drips.length && !this.specks.length && !this.beads.length
  }

  // ---- drawing (cr in surface pixels; w x h surface; radius = tile corners)

  draw(cr, w, h, radius = 10, alpha = 1) {
    const k = h / H
    this.resize(w / k)
    cr.save()
    cr.setOperator(Cairo.Operator.CLEAR)
    cr.paint()
    cr.setOperator(Cairo.Operator.OVER)
    roundRect(cr, 0, 0, w, h, radius)
    cr.clip()
    cr.scale(k, k)

    // Drips sit on the tile under the fresh paint.
    cr.setLineCap(Cairo.LineCap.ROUND)
    for (const d of this.drips) {
      const fade = clamp(1 - (d.dry - 1.8) / 1.2, 0, 1) * alpha
      if (fade <= 0) continue
      // The trail narrows from where it left the paint to the head, with a
      // slight sideways meander like real runs.
      const len = d.y - d.y0, steps = Math.max(2, Math.ceil(len / 1.5))
      const wig = (y) => (d.wall ? 0 : 0.35 * Math.sin(y * 0.7 + d.wob))
      cr.setSourceRGBA(...d.color, 0.92 * fade)
      cr.moveTo(d.x - d.w0 * 0.45, d.y0)
      for (let i = 1; i <= steps; i++) {
        const y = d.y0 + (len * i) / steps, t = i / steps
        cr.lineTo(d.x + wig(y) - (d.w0 + (d.w - d.w0) * t) * 0.45, y)
      }
      for (let i = steps; i >= 0; i--) {
        const y = d.y0 + (len * i) / steps, t = i / steps
        cr.lineTo(d.x + wig(y) + (d.w0 + (d.w - d.w0) * t) * 0.45, y)
      }
      cr.closePath()
      cr.fill()
      // The head: a hanging teardrop, fuller while it's still moving.
      const hr = Math.max(0.3, d.w * (d.stopped ? 0.55 : 0.75))
      cr.save()
      cr.translate(d.x + wig(d.y), d.y)
      cr.scale(1, d.stopped ? 1 : 1.25)
      cr.arc(0, 0, hr, 0, Math.PI * 2)
      cr.restore()
      cr.fill()
      if (!d.stopped) {
        cr.setSourceRGBA(1, 1, 1, 0.45 * fade)
        cr.arc(d.x + wig(d.y) - hr * 0.3, d.y - hr * 0.3, hr * 0.3, 0, Math.PI * 2)
        cr.fill()
      }
    }

    for (const sp of this.specks) {
      const fade = clamp((sp.life - sp.age) / 0.6, 0, 1) * alpha
      cr.save()
      cr.translate(sp.x, sp.y)
      cr.rotate(sp.a)
      cr.scale(sp.s, 1 / Math.sqrt(sp.s))
      cr.arc(0, 0, sp.r, 0, Math.PI * 2)
      cr.restore()
      cr.setSourceRGBA(...sp.color, 0.9 * fade)
      cr.fill()
    }

    for (const sp of this.splats) {
      const fade = clamp((sp.life + 0.8 - sp.age) / 0.8, 0, 1) * alpha
      if (fade <= 0) continue
      ringPath(cr, sp, 0, 0.6)
      cr.setSourceRGBA(0, 0, 0, 0.22 * fade)
      cr.fill()
      ringPath(cr, sp)
      // Paint is thicker in the middle: a soft radial body.
      const g = new Cairo.RadialGradient(sp.x - sp.R * 0.25, sp.y - sp.R * 0.3, 0, sp.x, sp.y, sp.R * 1.4)
      g.addColorStopRGBA(0, ...mix(sp.color, [1, 1, 1], 0.18), fade)
      g.addColorStopRGBA(1, ...mix(sp.color, [0, 0, 0], 0.12), fade)
      cr.setSource(g)
      cr.fillPreserve()
      // A thin darker rim, so paint over paint still reads as two layers.
      cr.setSourceRGBA(...mix(sp.color, [0, 0, 0], 0.35), 0.45 * fade)
      cr.setLineWidth(0.35)
      cr.stroke()
      if (sp.wet > 0.05) {
        // Wet sheen, gone as it dries.
        cr.setSourceRGBA(1, 1, 1, 0.55 * sp.wet * fade)
        cr.save()
        cr.translate(sp.x - sp.R * 0.32, sp.y - sp.R * 0.38)
        cr.scale(1, 0.55)
        cr.arc(0, 0, Math.max(0.4, sp.R * 0.28 * sp.shrink), 0, Math.PI * 2)
        cr.restore()
        cr.fill()
      }
    }

    // Beads on the floor edge: flat, domed puddles of paint with a sheen.
    for (const b of this.beads) {
      const fade = clamp((b.life - b.age) / 0.8, 0, 1) * alpha
      if (fade <= 0) continue
      const ht = Math.min(2.8, 0.7 + 0.55 * Math.sqrt(b.m)) * (1 + clamp(b.wob, -0.6, 0.8))
      const hw = (b.w * 0.5) / Math.sqrt(1 + clamp(b.wob, -0.5, 0.8))
      cr.newPath()
      cr.moveTo(b.x - hw - 0.8, H + 0.5)
      cr.curveTo(b.x - hw, H - ht * 0.2, b.x - hw * 0.6, H - ht, b.x, H - ht)
      cr.curveTo(b.x + hw * 0.6, H - ht, b.x + hw, H - ht * 0.2, b.x + hw + 0.8, H + 0.5)
      cr.closePath()
      cr.setSourceRGBA(...b.color, 0.95 * fade)
      cr.fillPreserve()
      cr.setSourceRGBA(...mix(b.color, [0, 0, 0], 0.35), 0.4 * fade)
      cr.setLineWidth(0.35)
      cr.stroke()
      const wet = Math.exp(-b.age / 1.2)
      if (wet > 0.05) {
        cr.setSourceRGBA(1, 1, 1, 0.5 * wet * fade)
        cr.save()
        cr.translate(b.x - hw * 0.25, H - ht * 0.7)
        cr.scale(1, 0.4)
        cr.arc(0, 0, Math.max(0.3, hw * 0.3), 0, Math.PI * 2)
        cr.restore()
        cr.fill()
      }
    }

    // Droplets in flight, stretched along their speed.
    for (const d of this.drops) {
      const speed = Math.hypot(d.vx, d.vy)
      cr.save()
      cr.translate(d.x, d.y)
      cr.rotate(Math.atan2(d.vy, d.vx))
      cr.scale(1 + Math.min(2.2, speed / 140), 1 / (1 + Math.min(0.5, speed / 600)))
      cr.arc(0, 0, d.r, 0, Math.PI * 2)
      cr.restore()
      cr.setSourceRGBA(...d.color, alpha)
      cr.fill()
    }
    cr.restore()
  }
}

function roundRect(cr, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2)
  cr.newSubPath()
  cr.arc(x + w - r, y + r, r, -Math.PI / 2, 0)
  cr.arc(x + w - r, y + h - r, r, 0, Math.PI / 2)
  cr.arc(x + r, y + h - r, r, Math.PI / 2, Math.PI)
  cr.arc(x + r, y + r, r, Math.PI, 1.5 * Math.PI)
  cr.closePath()
}

// A smooth closed curve through the splat's edge (midpoint quadratics).
function ringPath(cr, sp, dx = 0, dy = 0) {
  const pts = []
  for (let k = 0; k < RING; k++) {
    const a = sp.rot + (k / RING) * Math.PI * 2
    pts.push([sp.x + dx + Math.cos(a) * sp.r[k], sp.y + dy + Math.sin(a) * sp.r[k]])
  }
  const mid = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]
  let m = mid(pts[RING - 1], pts[0])
  cr.newPath()
  cr.moveTo(...m)
  for (let k = 0; k < RING; k++) {
    const c = pts[k], n = mid(c, pts[(k + 1) % RING])
    // Quadratic (m, c, n) as a cubic.
    cr.curveTo(m[0] + (2 / 3) * (c[0] - m[0]), m[1] + (2 / 3) * (c[1] - m[1]), n[0] + (2 / 3) * (c[0] - n[0]), n[1] + (2 / 3) * (c[1] - n[1]), n[0], n[1])
    m = n
  }
  cr.closePath()
}
