# Fetelabs Task Bar

A single floating taskbar for GNOME, with the Fetelabs setup built in as the defaults.

It is a fork of **Zorin Taskbar** v70 (© 2016-2025 Jason DeRose and Zorin OS Technologies Ltd.),
which is based on **Dash to Panel**. The original copyright headers are kept in every file.
Licensed GPL-2.0-or-later, the same as upstream; see `LICENSE`.

What changed from Zorin Taskbar:

- its own UUID (`taskbar@fetelabs`) and settings schema (`org.gnome.shell.extensions.fetelabs-taskbar`),
  so it can be installed alongside Zorin's and Zorin updates don't touch it;
- the Fetelabs look as defaults: floating bar with a 16 px margin, rounded corners, larger icons,
  grouped apps.

Turn off Dash to Panel, Dash to Dock or Zorin Taskbar before enabling it: only one taskbar should run.

Made by Fete Labs · https://fetelabs.ai · X @mostlyjola · Instagram @fetelabs

## Support

Fetelabs Task Bar is free. If it makes your desktop nicer, tips are welcome:

**USDC on Solana only:** `Dox9t9toz7BwwHJaqqsTpt9J74DWkXidP921FJQgWGE5`

Only send USDC on the Solana network. SOL, other tokens, or USDC on any other
network (Ethereum, Base, etc.) sent to this address will be lost. The About
page in the preferences has a copy button and a wallet link that is locked to
USDC.

## Build

    ./pack.sh     # writes dist/taskbar@fetelabs.shell-extension.zip for extensions.gnome.org
