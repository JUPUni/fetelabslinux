# Fetelabs Task Bar

A single floating taskbar for GNOME, with the Fetelabs setup built in as the defaults.

It is a fork of **Zorin Taskbar** v70 (© 2016-2025 Jason DeRose and Zorin OS Technologies Ltd.),
which is based on **Dash to Panel**. The original copyright headers are kept in every file.
Licensed GPL-2.0-or-later, the same as upstream; see `LICENSE`.

What changed from Zorin Taskbar:

- its own UUID (`taskbar@fetelabs`) and settings schema (`org.gnome.shell.extensions.fetelabs-taskbar`),
  so it can be installed alongside Zorin's and Zorin updates don't touch it;
- the Fetelabs look as defaults: floating bar with a 16 px margin, rounded corners, larger icons,
  grouped apps;
- **Water Panel built in**: the bar is a liquid audio visualizer (see the Water tab in the settings).

## Water Panel

`water/` is Water Panel's engine, copied from the Water Panel repo by its
`tools/sync-to-taskbar.sh` (see `water/SOURCE`); edit it there, not here. Its settings live under
`org.gnome.shell.extensions.fetelabs-taskbar.water`, with an `enabled` switch. While it is on, the
task bar sets `global.fetelabsTaskbar.builtInWater` and emits `water-changed`, and a standalone
Water Panel steps aside so the water is never drawn twice.

While Spotify plays, the Fetelabs wordmark shows through the water: a word of your own (JOLA by
default, set on the Water tab), the live test tube (the same drawing as Fetelabs Menu's start
button, moving with the same water) and FETELABS, with paint drips that fall into the waves.

The audio analysis needs python3 with NumPy and parec (`sudo apt install python3-numpy
pulseaudio-utils`). Without them the task bar works as normal, without the water.

Turn off Dash to Panel, Dash to Dock or Zorin Taskbar before enabling it: only one taskbar should run.

Made by Fete Labs · https://fetelabs.ai · X @mostlyjola · Instagram @fetelabs

## Player

Media controls live at the start of the bar: the app's icon, then back, play and
next. Click the icon for the mini player: the cover art first, then a seek bar,
shuffle and repeat floating on a small tank of water that moves with the music
(stir it with the pointer). While it is open the bar's controls turn into a paint
splash that plays to the vocals. Double-click the icon to open the app;
middle-click plays and pauses. The player
follows only the media apps listed on the Player tab (add or remove them there,
or add one that is playing right now in one click) and stays in the bar when
none is running: press play and it starts the first app on the list.

It can also start playing at login: Spotify opens with its window minimised
and plays your Liked Songs (or any Spotify link you give it) on shuffle, found
from the desktop app itself, with no web API or login.

Scripts and voice assistants can drive the same player on the session bus:

    gdbus call --session --dest ai.fetelabs.TaskbarPlayer \
      --object-path /ai/fetelabs/TaskbarPlayer \
      --method ai.fetelabs.TaskbarPlayer.Next

Methods: Play, Pause, PlayPause, Next, Previous, PlayDefault, PlayUri(uri,
shuffle) and Status (status, title, artist, app).

## Show Desktop: the Dragon Ball

The Show Desktop button at the end of the bar is a four-star Dragon Ball, drawn
live: the liquid inside sloshes with the music, the stars stay put. Set the number
of stars (1-7) or switch back to a plain icon in the Show Desktop button's options
(the gear next to it on the Position tab); a plain icon can kick on the beat and glow in the water's colour.

## Support

Fetelabs Task Bar is free. If it makes your desktop nicer, tips are welcome:

**USDC on Solana only:** `Dox9t9toz7BwwHJaqqsTpt9J74DWkXidP921FJQgWGE5`

Only send USDC on the Solana network. SOL, other tokens, or USDC on any other
network (Ethereum, Base, etc.) sent to this address will be lost. The About
page in the preferences has a copy button and a wallet link that is locked to
USDC.

## Build

    ./pack.sh     # writes dist/taskbar@fetelabs.shell-extension.zip for extensions.gnome.org
