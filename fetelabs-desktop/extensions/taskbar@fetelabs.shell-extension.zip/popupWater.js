// SPDX-License-Identifier: GPL-2.0-or-later
// Water in the player popup, under the artwork: a small tank behind the
// progress bar and controls, filled by the same physics as the bar's water
// (water/physics.js: springs to the music, the wave equation between
// columns, capillary ripples, reflecting walls), driven by the bar's own
// analyser levels (global.fetelabsTaskbar.waterRaw) in the wallpaper's
// colours (waterColors). Bubbles rise on the beat, wobble as they go and
// pop at the surface with a small ripple. With no music it settles to a
// calm, slowly breathing level; moving the pointer through it stirs ripples.
//
// It only runs while the popup is open and on screen.

import Cairo from 'cairo'
import Clutter from 'gi://Clutter'
import GLib from 'gi://GLib'
import GObject from 'gi://GObject'
import St from 'gi://St'

import { Liquid } from './water/physics.js'
import { OCEAN, copyPalette } from './water/palette.js'

const BANDS = 40
const STALE_MS = 250 // no water frame for this long: the music has stopped
const REST = 0.14 // calm level with no music (share of the tank's height)
const GAIN = 0.6 // how far the music lifts it above the calm level
const BUBBLES_MAX = 28
const BUOYANCY = 260 // px/s² upward, before drag
const DRAG = 2.2 // 1/s: bubbles reach a terminal speed instead of shooting up
const RADIUS = 20 // the cover's radius: the card's 28px minus its 8px inset
const BACK_ALPHA = 0.45
const CFG = {
  responsiveness: 0.55, // a touch softer than the bar: bigger, rounder swells
  fallSpeed: 0.55,
  surfaceTension: 0.42,
  waveHeight: 1,
  wordmark: false,
}

// Smooth curve through the points (Catmull-Rom as cubic Béziers).
function tracePath(cr, pts) {
  cr.moveTo(pts[0][0], pts[0][1])
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[Math.max(0, i - 1)]
    const p1 = pts[i]
    const p2 = pts[i + 1]
    const p3 = pts[Math.min(pts.length - 1, i + 2)]
    cr.curveTo(
      p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6,
      p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6,
      p2[0], p2[1],
    )
  }
}

function roundedRect(cr, w, h, r) {
  r = Math.min(r, h / 2, w / 2)
  cr.newSubPath()
  cr.arc(w - r, r, r, -Math.PI / 2, 0)
  cr.arc(w - r, h - r, r, 0, Math.PI / 2)
  cr.arc(r, h - r, r, Math.PI / 2, Math.PI)
  cr.arc(r, r, r, Math.PI, 1.5 * Math.PI)
  cr.closePath()
}

export const PopupWater = GObject.registerClass(
class PopupWater extends St.DrawingArea {
  _init() {
    super._init({ style_class: 'fetelabs-player-water', x_expand: true, y_expand: true, reactive: true })
    this._liquid = new Liquid(BANDS, CFG)
    this._colors = copyPalette(OCEAN)
    // Start at the calm level, not empty, so opening never shows a fill-up.
    this._liquid.level.fill(REST)
    this._liquid.back.fill(REST)
    this._clock = 0
    this._last = 0
    this._lastWater = 0
    this._pointer = null
    this._bubbles = []
    this._bass = 0
    this._bassAvg = 0
    this._spawn = 0

    this.connect('repaint', () => this._repaint())
    this._timeline = new Clutter.Timeline({ actor: this, duration: 1000, repeat_count: -1 })
    this._timeline.connect('new-frame', () => this._frame())
    this.connect('notify::mapped', () => {
      if (this.mapped) this.start()
      else this.stop()
    })
    this.connect('motion-event', (_a, event) => this._stir(event))
    this.connect('leave-event', () => (this._pointer = null))
    this.connect('destroy', () => this._onDestroy())
  }

  start() {
    this._watchHost()
    this._last = 0
    if (this._timeline && !this._timeline.is_playing()) this._timeline.start()
  }

  stop() {
    this._timeline?.stop()
    this._unwatchHost()
    this._pointer = null
  }

  _watchHost() {
    const host = global.fetelabsTaskbar ?? null
    if (host === this._host) return
    this._unwatchHost()
    this._host = host
    if (host?.connect) this._hostId = host.connect('water-frame', () => (this._lastWater = GLib.get_monotonic_time() / 1000))
  }

  _unwatchHost() {
    if (this._hostId) {
      try {
        this._host?.disconnect(this._hostId)
      } catch {}
    }
    this._hostId = 0
    this._host = null
  }

  // The pointer pushes the surface along as it moves through the water.
  _stir(event) {
    const [x, y] = event.get_coords()
    const [ok, lx, ly] = this.transform_stage_point(x, y)
    if (!ok) return Clutter.EVENT_PROPAGATE
    const now = GLib.get_monotonic_time() / 1000
    const p = this._pointer
    this._pointer = { x: lx, y: ly, t: now }
    if (!p || now - p.t > 100) return Clutter.EVENT_PROPAGATE
    const [w, h] = this.get_size()
    const col = Math.round((lx / Math.max(1, w)) * (BANDS - 1))
    const surface = h * (1 - this._liquid.level[Math.max(0, Math.min(BANDS - 1, col))])
    // Strongest right at the surface, fading with depth (and nothing in the air).
    const near = Math.max(0, 1 - Math.abs(ly - surface) / (h * 0.35))
    const speed = Math.min(1.5, Math.hypot(lx - p.x, ly - p.y) / Math.max(1, now - p.t))
    if (near > 0) {
      const push = -(ly - p.y) / Math.max(1, h) * 60 - speed * 0.6
      for (let d = -1; d <= 1; d++) this._liquid.impulse(col + d, push * near * (d ? 0.5 : 1))
    }
    return Clutter.EVENT_PROPAGATE
  }

  _frame() {
    const now = GLib.get_monotonic_time() / 1000
    const dt = this._last ? Math.min(0.05, Math.max(0, (now - this._last) / 1000)) : 1 / 60
    this._last = now
    this._clock += dt
    if ((global.fetelabsTaskbar ?? null) !== this._host) this._watchHost()
    const host = this._host
    if (host?.waterColors) this._colors = host.waterColors

    const raw = now - this._lastWater < STALE_MS ? host?.waterRaw ?? host?.waterLevels : null
    const t = this._liquid.target
    for (let i = 0; i < BANDS; i++) {
      // A slow swell so still water still breathes.
      const calm = REST + 0.025 * Math.sin(this._clock * 0.9 + i * 0.32) + 0.012 * Math.sin(this._clock * 1.7 - i * 0.55)
      let music = 0
      if (raw?.length) {
        // Average the analyser's bands that fall in this column (lows on the left, as in the bar).
        const a = Math.floor((i / BANDS) * raw.length)
        const b = Math.max(a + 1, Math.floor(((i + 1) / BANDS) * raw.length))
        for (let j = a; j < b; j++) music += raw[j]
        music /= b - a
      }
      t[i] = Math.min(0.97, calm + GAIN * music)
    }
    this._liquid.step(dt)
    this._stepBubbles(raw, dt)
    this.queue_repaint()
  }

  // Bubbles: a trickle with the music, a burst on each beat. Each one rises
  // under buoyancy against drag, sways, and pops when it reaches the surface.
  _stepBubbles(raw, dt) {
    let bass = 0
    if (raw?.length) {
      const n = Math.max(1, Math.round(raw.length * 0.12))
      for (let i = 0; i < n; i++) bass += raw[i]
      bass /= n
    }
    const ease = (v, cur, up, down) => cur + (v - cur) * (1 - Math.exp(-dt / (v > cur ? up : down)))
    const prev = this._bass
    this._bass = ease(bass, this._bass, 0.03, 0.2)
    this._bassAvg = ease(this._bass, this._bassAvg, 0.6, 0.6)
    const beat = this._bass > this._bassAvg * 1.2 + 0.04 && prev <= this._bassAvg * 1.2 + 0.04
    const [w, h] = this.get_size()
    const level = this._liquid.level
    this._spawn += dt * this._bass * 6
    let burst = beat ? 3 + Math.round(this._bass * 4) : 0
    while ((this._spawn >= 1 || burst > 0) && this._bubbles.length < BUBBLES_MAX) {
      if (burst > 0) burst--
      else this._spawn -= 1
      const x = 8 + Math.random() * (w - 16)
      this._bubbles.push({
        x, x0: x, y: h - 2, vy: -20 - Math.random() * 30,
        r: 1.2 + Math.random() * (beat ? 3 : 2),
        phase: Math.random() * Math.PI * 2, sway: 2 + Math.random() * 4, age: 0,
      })
    }
    this._spawn = Math.min(this._spawn, 1)
    const keep = []
    for (const b of this._bubbles) {
      b.age += dt
      // Bigger bubbles are more buoyant and rise faster.
      b.vy += (-BUOYANCY * (0.6 + b.r * 0.15) - DRAG * b.vy) * dt
      b.y += b.vy * dt
      b.x = b.x0 + Math.sin(b.age * 5 + b.phase) * b.sway * Math.min(1, b.age * 2)
      const col = Math.max(0, Math.min(BANDS - 1, Math.round((b.x / Math.max(1, w)) * (BANDS - 1))))
      const surface = h * (1 - level[col])
      if (b.y - b.r <= surface) {
        this._liquid.impulse(col, 0.25 + b.r * 0.12) // the pop lifts the surface a little
        continue
      }
      keep.push(b)
    }
    this._bubbles = keep
  }

  _repaint() {
    const cr = this.get_context()
    try {
      const [w, h] = this.get_surface_size()
      const { level, back } = this._liquid
      const c = this._colors
      const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor
      roundedRect(cr, w, h, RADIUS * scale * (w / Math.max(1, this.get_width())))
      cr.clip()
      cr.setSourceRGBA(0.114, 0.114, 0.13, 1) // the cover's empty colour, #1d1d21
      cr.paint()

      const step = w / (BANDS - 1)
      const surfaceOf = (vals) => Array.from({ length: BANDS }, (_, i) => [i * step, h - vals[i] * h])
      const fillUnder = (pts) => {
        tracePath(cr, pts)
        cr.lineTo(w, h)
        cr.lineTo(0, h)
        cr.closePath()
      }
      const layer = (pts, alpha) => {
        fillUnder(pts)
        const top = Math.min(...pts.map(([, y]) => y))
        const g = new Cairo.LinearGradient(0, h, 0, top)
        g.addColorStopRGBA(0, ...c.deep, alpha)
        g.addColorStopRGBA(1, ...c.shallow, Math.min(1, alpha * 1.15))
        cr.setSource(g)
        cr.fill()
      }

      layer(surfaceOf(back), BACK_ALPHA)
      const front = surfaceOf(level)
      layer(front, 0.88)

      // Light just under the surface: a soft band of foam colour that fades down.
      cr.save()
      fillUnder(front)
      cr.clip()
      const top = Math.min(...front.map(([, y]) => y))
      const sheen = new Cairo.LinearGradient(0, top, 0, top + h * 0.22)
      sheen.addColorStopRGBA(0, ...c.foam, 0.22)
      sheen.addColorStopRGBA(1, ...c.foam, 0)
      cr.setSource(sheen)
      cr.paint()
      cr.restore()

      // Bubbles: a thin foam ring with a highlight, clipped to the water.
      if (this._bubbles.length) {
        const k = w / Math.max(1, this.get_width())
        cr.save()
        fillUnder(front)
        cr.clip()
        for (const b of this._bubbles) {
          const x = b.x * k, y = b.y * k, r = b.r * k
          cr.newSubPath()
          cr.arc(x, y, r, 0, 2 * Math.PI)
          cr.setSourceRGBA(...c.foam, 0.1)
          cr.fillPreserve()
          cr.setLineWidth(Math.max(0.8, 0.5 * k))
          cr.setSourceRGBA(...c.foam, 0.55)
          cr.stroke()
          cr.newSubPath()
          cr.arc(x - r * 0.35, y - r * 0.35, r * 0.3, 0, 2 * Math.PI)
          cr.setSourceRGBA(1, 1, 1, 0.55)
          cr.fill()
        }
        cr.restore()
      }

      // The surface line, with a faint glow behind it.
      tracePath(cr, front)
      cr.setLineWidth(5 * scale)
      cr.setSourceRGBA(...c.foam, 0.12)
      cr.stroke()
      tracePath(cr, front)
      cr.setLineWidth(1.6 * scale)
      cr.setSourceRGBA(...c.foam, 0.9)
      cr.stroke()
    } finally {
      cr.$dispose()
    }
  }

  _onDestroy() {
    this.stop()
    this._timeline = null
  }
})
