// SPDX-License-Identifier: GPL-2.0-or-later
// The wordmark hidden in the middle of the taskbar: a custom word ("JOLA" by
// default), the live Fetelabs test tube and "FETELABS", in fetelabs.ai's
// Rubik Wet Paint. It is only seen through the water: when a wave surges up
// over it the whole mark shows at full strength, holds a moment, then fades.
// Paint drips hang under the letters as pendant drops (drips.js), filling
// with the music and falling on the hits into the water below, in a vivid
// colour of their own. The tube is the start button's live logo
// (tubeLogo.js), moving with the same water. It only wakes while Spotify is
// playing.
//
// Nothing here imports Shell modules, so tools can render it offline.

import Cairo from 'cairo'
import Gio from 'gi://Gio'
import GLib from 'gi://GLib'

import { DripSim, dripGradients, drawDripsOver, drawDripsUnder } from './drips.js'
import { TUBE_BOX, TUBE_REACH, drawTube, newLogoState, stepLogo, traceSilhouette } from './tubeLogo.js'
import { WORD, WORD_PATH, WORD_LETTERS } from './wordmark-glyphs.js'
import { setText } from './wordText.js'

// Layout, as fractions of the taskbar height.
const EM = 0.5 // font size
const ICON_EM = 1.9 // test tube height (its ink at rest), in em
const GAP_EM = 0.6 // between the tube and each word
const TOO_WIDE = 0.72 // the whole mark may take this share of the bar at most

// Splash: the water has to reach this far up the bar (fraction from the
// bottom) before the mark shows at all.
const REVEAL_FLOOR = 0.2
const RISE_MIN = 13 // level/s: slower swells than this reveal nothing
const ATTACK_S = 0.02
const SPREAD = 3 // a hit counts this many bands either side
const HOLD_S = 0.18 // stays fully visible this long after a hit
const FADE_S = 0.3 // then fades quickly
// Stroke widths round every letter; the letters cover their inner halves.
const RIM_EM = 0.24 // outer rim, in the colour of the water's surface line
const KEY_EM = 0.13 // thin dark keyline between the rim and the letters
const LINE_CONTRAST = 3.2 // keyline vs letters, WCAG ratio

// Refraction: the mark wobbles a little under moving water.
const STRIPS = 22
const WOBBLE = 1.3 / 48 // of the bar height

// Drips: from the lowest point of each painted drip in the letters.
const DRIP_MIN_Y = 0.05 // em below the baseline: lower points are drip tips
const DRIP_CLUSTER = 0.06 // em: tips closer than this are one drip
// Extra drips on letters whose paint has few of its own: in the custom
// text, 2 on a letter with none and 1 on a letter with one; in FETELABS,
// both Es and the S.
const EXTRA_WORD = { 1: 2, 3: 2, 7: 2 }
const EXTRA_GAP = 0.12 // em, no closer than this to another drip

// The drips' own colour: whichever of the brand colours stands out most
// from the letters and the water.
const hex = (s) => [1, 3, 5].map((i) => parseInt(s.slice(i, i + 2), 16) / 255)
const DRIP_CHOICES = ['#1FB5A8', '#9BE22D', '#FF2E88', '#F4B400'].map(hex) // teal, lime, soca pink, gold

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v))

// True when the colours match what cache last held; otherwise stores them.
// (Compares in place, so nothing is allocated per frame.)
function samePalette(cache, ...cols) {
  let same = true, k = 0
  for (const c of cols) {
    for (let i = 0; i < 3; i++, k++) {
      if (!(Math.abs(cache[k] - c[i]) <= 0.0005)) { // NaN (nothing cached yet) counts as changed
        same = false
        cache[k] = c[i]
      }
    }
  }
  return same
}

// Both words, in the word's own em units: "FETELABS" at the origin and the
// custom text preDx em to its left.
function traceWord(cr, preDx, pre) {
  tracePath(cr, WORD_PATH)
  if (!pre) return
  cr.save()
  cr.translate(preDx, 0)
  tracePath(cr, pre.path)
  cr.restore()
}

function tracePath(cr, p) {
  for (let i = 0; i < p.length;) {
    switch (p[i]) {
    case 'M':
      cr.moveTo(p[i + 1], p[i + 2])
      i += 3
      break
    case 'L':
      cr.lineTo(p[i + 1], p[i + 2])
      i += 3
      break
    case 'C':
      cr.curveTo(p[i + 1], p[i + 2], p[i + 3], p[i + 4], p[i + 5], p[i + 6])
      i += 7
      break
    default: // Z
      cr.closePath()
      i += 1
    }
  }
}

// The outline as straight segments (curves cut in 12), em units.
function flatten(path) {
  const segs = []
  let x = 0, y = 0, sx = 0, sy = 0
  for (let i = 0; i < path.length;) {
    const op = path[i]
    if (op === 'M') {
      x = sx = path[i + 1]
      y = sy = path[i + 2]
      i += 3
    } else if (op === 'L') {
      segs.push([x, y, path[i + 1], path[i + 2]])
      x = path[i + 1]
      y = path[i + 2]
      i += 3
    } else if (op === 'C') {
      const [x1, y1, x2, y2, x3, y3] = path.slice(i + 1, i + 7)
      let px = x, py = y
      for (let k = 1; k <= 12; k++) {
        const t = k / 12, u = 1 - t
        const qx = u * u * u * x + 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t * x3
        const qy = u * u * u * y + 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t * y3
        segs.push([px, py, qx, qy])
        px = qx
        py = qy
      }
      x = x3
      y = y3
      i += 7
    } else {
      segs.push([x, y, sx, sy])
      x = sx
      y = sy
      i += 1
    }
  }
  return segs
}

// Lowest point of the outline straight below x (em), or null.
function bottomAt(segs, x) {
  let best = null
  for (const [ax, ay, bx, by] of segs) {
    if ((ax - x) * (bx - x) > 0 || ax === bx) continue
    const y = ay + (by - ay) * (x - ax) / (bx - ax)
    if (best === null || y > best) best = y
  }
  return best
}

// New drip points along the bottom edge of the chosen letters, spaced away
// from the drips already painted there.
function extraTips(path, letters, extra, dx, existing) {
  const segs = flatten(path)
  const out = []
  const taken = existing.map(([x]) => x)
  for (const [idx, count] of Object.entries(extra)) {
    const [l, r] = letters[idx]
    const w = r - l
    for (let n = 0; n < count; n++) {
      // Of a row of candidates across the letter, the one farthest from any drip.
      let pick = null, far = 0
      for (let k = 0; k <= 16; k++) {
        const x = l + w * (0.15 + 0.7 * k / 16)
        const d = Math.min(...taken.map((t) => Math.abs(t - (x + dx))), Infinity)
        if (d > far) {
          far = d
          pick = x
        }
      }
      if (pick === null || far < EXTRA_GAP) break
      const y = bottomAt(segs, pick)
      if (y === null) break
      taken.push(pick + dx)
      out.push([pick + dx, y])
    }
  }
  return out
}

// How many extra drips each letter of the custom text gets: up to two per
// letter, counting the ones its paint already has.
function extraFor(letters, tips, dx) {
  const extra = {}
  letters.forEach(([l, r], i) => {
    const own = tips.filter(([x]) => x >= l + dx - 0.02 && x <= r + dx + 0.02).length
    if (own < 2) extra[i] = 2 - own
  })
  return extra
}

// Drip tips in the letters (em units, word origin): the lowest point of each
// paint drip hanging under the baseline.
function dripTips(path, dx) {
  const pts = []
  for (let i = 0; i < path.length;) {
    const op = path[i]
    const n = op === 'C' ? 7 : op === 'Z' ? 1 : 3
    if (n > 1 && path[i + n - 1] > DRIP_MIN_Y) pts.push([path[i + n - 2] + dx, path[i + n - 1]])
    i += n
  }
  pts.sort((a, b) => a[0] - b[0])
  const tips = []
  let lastX = -Infinity
  for (const p of pts) {
    if (p[0] - lastX < DRIP_CLUSTER) {
      if (p[1] > tips[tips.length - 1][1]) tips[tips.length - 1] = p
    } else {
      tips.push(p)
    }
    lastX = p[0]
  }
  return tips
}

// Where everything goes for a bar of height h, in pixels. pre is the custom
// text as set by wordText.js, or null for none (the mark recentres).
function layout(w, h, pre) {
  const em = h * EM
  const iconH = ICON_EM * em
  const iconW = iconH * TUBE_BOX.w / TUBE_BOX.h
  const gap = GAP_EM * em
  const preW = pre ? (pre.box.right - pre.box.left) * em : 0
  const preRoom = pre ? preW + gap : 0
  const wordW = (WORD.right - WORD.left) * em
  const total = preRoom + iconW + gap + wordW
  const x0 = Math.round((w - total) / 2) // left edge of the mark
  const iconX = x0 + preRoom
  const wordX = iconX + iconW + gap - WORD.left * em // "FETELABS" origin
  const preDx = pre ? (x0 - pre.box.left * em - wordX) / em : 0
  // Caps a little above centre, so the paint drips have room to hang.
  const baseline = h / 2 + 0.15 * em
  const iconTop = (h - iconH) / 2 // centred on the bar
  const scale = iconH / TUBE_BOX.h // px per logo unit
  const reach = Math.ceil(TUBE_REACH * scale) // the moving bubbles go this far past the box
  // Room round the ink for the glow (reaches 0.12 em out), whatever the bar height.
  const pad = Math.ceil(0.13 * em) + 2
  const inkTop = Math.min(WORD.top, pre ? pre.box.top : 0)
  const inkBottom = Math.max(WORD.bottom, pre ? pre.box.bottom : 0)
  const top = Math.floor(Math.min(iconTop, baseline + inkTop * em)) - pad
  const bottom = Math.ceil(Math.max(baseline + inkBottom * em, iconTop + iconH)) + pad
  return { em, iconH, iconW, gap, wordW, total, x0, iconX, wordX, preDx, baseline, iconTop, scale, reach, top, bottom, pad }
}

// Colours for the mark. Before any wallpaper has been read, or with a palette
// from an older cache, fall back to the foam colour.
function rgbToHsv([r, g, b]) {
  const max = Math.max(r, g, b)
  const d = max - Math.min(r, g, b)
  let h = 0
  if (d) h = max === r ? ((g - b) / d + 6) % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4
  return [h / 6, max ? d / max : 0, max]
}

function hsvToRgb(h, s, v) {
  const f = (n) => {
    const k = (n + h * 6) % 6
    return v - v * s * Math.max(0, Math.min(k, 4 - k, 1))
  }
  return [f(5), f(3), f(1)]
}

// WCAG relative luminance and contrast ratio (1..21).
const lin = (v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)
const luma = ([r, g, b]) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)
export function contrast(x, y) {
  const [a, b] = [luma(x), luma(y)].sort((m, n) => n - m)
  return (a + 0.05) / (b + 0.05)
}

// The keyline is the surface line's own hue with its brightness moved
// (darker or lighter, whichever is nearer) until it stands clear of the
// letters, so rim, keyline and waves read as one pen.
function lineFor(fill, foam) {
  const [h, s0, v0] = rgbToHsv(foam)
  const s = Math.max(s0, 0.45)
  let best = foam
  let bestScore = contrast(foam, fill)
  for (let k = 1; k <= 20 && bestScore < LINE_CONTRAST; k++) {
    for (const v of [v0 - k * 0.045, v0 + k * 0.045]) {
      if (v < 0.08 || v > 1) continue
      // Darker steps deepen the hue too, so it never turns grey.
      const c = hsvToRgb(h, v < v0 ? Math.min(1, s + (v0 - v) * 0.6) : s0 * (1 - (v - v0)), v)
      const score = contrast(c, fill)
      if (score > bestScore) {
        bestScore = score
        best = c
      }
    }
  }
  return best
}

// How far apart two hues are, 0 (same) to 1 (opposite), counting only as
// much as the other colour has a hue at all (grey has none).
function hueApart(c, other) {
  const [h1] = rgbToHsv(c)
  const [h2, s2] = rgbToHsv(other)
  const d = Math.abs(h1 - h2)
  return Math.min(d, 1 - d) * 2 * Math.min(1, s2 * 2) + (1 - Math.min(1, s2 * 2)) * 0.5
}

// The brand colour that stands out most from both the letters and the
// shallow water: WCAG contrast against the nearer of the two, weighted by
// how far round the colour wheel it sits from the nearer hue.
export function pickDripColor(fill, shallow) {
  let best = DRIP_CHOICES[0], bestScore = -Infinity
  for (const c of DRIP_CHOICES) {
    const score = Math.min(contrast(c, fill), contrast(c, shallow)) * (0.35 + Math.min(hueApart(c, fill), hueApart(c, shallow)))
    if (score > bestScore) {
      bestScore = score
      best = c
    }
  }
  return best
}

export class Wordmark {
  // rand: a () => [0, 1) source, so offline renders can be repeatable.
  constructor(rand = Math.random) {
    this._key = ''
    this._masks = null
    this._lineKey = new Float64Array(6).fill(NaN)
    this._lines = null
    this._styleKey = new Float64Array(12).fill(NaN)
    this._style = null
    this._sim = new DripSim(rand)
    this._tube = newLogoState(rand)
    // Handed to the drip simulation every frame (reused, not reallocated).
    this._simEnv = { level: null, bandStep: 1, em: 1, h: 1, w: 1, waveHeight: 1, impact: null, timeS: 0 }
  }

  // Outline colour; recomputed only when the palette moves.
  _line(fill, foam) {
    if (!samePalette(this._lineKey, fill, foam)) this._lines = lineFor(fill, foam)
    return this._lines
  }

  // The drips' colour, keyline and gloss; recomputed only when the palette moves.
  // Also the mark's shadow colour, from the water's deepest one.
  _dripStyle(fill, shallow, foam, deep, em) {
    if (!samePalette(this._styleKey, fill, shallow, foam, deep)) {
      const drip = pickDripColor(fill, shallow)
      this._style = {
        drip, line: lineFor(drip, foam), foam, ...dripGradients(fill, drip), rimW: 0, keyW: 0,
        shadow: deep.map((v) => v * 0.35),
      }
    }
    this._style.foam = foam
    this._style.rimW = RIM_EM * em
    this._style.keyW = KEY_EM * em
    return this._style
  }

  // Masks (alpha only) are drawn once per bar size and text, and reused
  // every frame. The tube gets its own small surface, redrawn every frame.
  _build(w, h, text) {
    const key = `${w}x${h}:${text}`
    if (key === this._key) return this._masks
    this._free()
    const pre = setText(text)
    const L = layout(w, h, pre)
    const mw = Math.ceil(L.total) + 2 * L.pad
    const mh = L.bottom - L.top
    const ox = L.x0 - L.pad
    const make = () => new Cairo.ImageSurface(Cairo.Format.A8, mw, mh)
    const ink = make()
    const glow = make()
    const outline = make()
    const rim = make()
    const silhouette = make()
    const iw = Math.ceil(L.iconW) + 2 * L.reach
    const ih = Math.ceil(L.iconH) + 2 * L.reach
    const icon = new Cairo.ImageSurface(Cairo.Format.ARGB32, iw, ih)

    const place = (cr, fn) => {
      cr.save()
      cr.translate(-ox, -L.top)
      fn(cr)
      cr.restore()
    }
    const iconAt = (cr) => {
      cr.translate(L.iconX, L.iconTop)
      cr.scale(L.scale, L.scale)
      cr.translate(-TUBE_BOX.x, -TUBE_BOX.y)
    }
    const wordAt = (cr) => {
      cr.translate(L.wordX, L.baseline)
      cr.scale(L.em, L.em)
    }

    // The letters take the wallpaper's colour, so they are masks.
    let cr = new Cairo.Context(ink)
    place(cr, (c) => {
      wordAt(c)
      traceWord(c, L.preDx, pre)
      c.setSourceRGBA(0, 0, 0, 1)
      c.fill()
    })
    cr.$dispose()

    // The tube at rest, for its shadow.
    cr = new Cairo.Context(silhouette)
    place(cr, (c) => {
      iconAt(c)
      traceSilhouette(c)
      c.setSourceRGBA(0, 0, 0, 1)
      c.fill()
    })
    cr.$dispose()

    // The rim and the keyline round every letter.
    const strokeMask = (surface, width) => {
      const cx = new Cairo.Context(surface)
      place(cx, (c) => {
        c.save()
        wordAt(c)
        traceWord(c, L.preDx, pre)
        c.restore()
        c.setLineWidth(width * L.em)
        c.setLineJoin(Cairo.LineJoin.ROUND)
        c.setSourceRGBA(0, 0, 0, 1)
        c.stroke()
      })
      cx.$dispose()
    }
    strokeMask(rim, RIM_EM)
    strokeMask(outline, KEY_EM)

    // A soft halo: the same shapes stroked wide at low alpha, several times.
    // The tube's halo follows its resting silhouette, so it stays visible on
    // dark water.
    cr = new Cairo.Context(glow)
    place(cr, (c) => {
      for (const [width, a] of [[0.24, 0.08], [0.15, 0.12], [0.08, 0.17]]) {
        c.save()
        iconAt(c)
        traceSilhouette(c)
        c.restore()
        c.save()
        wordAt(c)
        traceWord(c, L.preDx, pre)
        c.restore()
        c.setLineWidth(width * L.em)
        c.setLineJoin(Cairo.LineJoin.ROUND)
        c.setSourceRGBA(0, 0, 0, a)
        c.stroke()
      }
    })
    cr.$dispose()

    // Drip tips, in bar pixels.
    const wordTips = dripTips(WORD_PATH, 0)
    const tips = [...wordTips, ...extraTips(WORD_PATH, WORD_LETTERS, EXTRA_WORD, 0, wordTips)]
    if (pre) {
      const preTips = dripTips(pre.path, L.preDx)
      tips.push(...preTips, ...extraTips(pre.path, pre.letters, extraFor(pre.letters, preTips, L.preDx), L.preDx, preTips))
    }
    this._sim.reset(tips.map(([x, y]) => [L.wordX + x * L.em, L.baseline + y * L.em]))

    this._key = key
    // The tube's own context stays open: it is redrawn every frame.
    const iconCr = new Cairo.Context(icon)
    // Caustic: a band of light drifting across the letters, made once and
    // moved into place each frame.
    const caustic = new Cairo.LinearGradient(-L.em, 0, L.em, h)
    caustic.addColorStopRGBA(0, 1, 1, 1, 0)
    caustic.addColorStopRGBA(0.5, 1, 1, 1, 0.45)
    caustic.addColorStopRGBA(1, 1, 1, 1, 0)
    this._masks = {
      ink, glow, outline, rim, silhouette, icon, iconCr, caustic, ox, oy: L.top, mw, mh, L,
      iconOx: L.iconX - L.reach, iconOy: L.iconTop - L.reach,
    }
    return this._masks
  }

  _free() {
    if (!this._masks) return
    this._masks.iconCr.$dispose()
    for (const k of ['ink', 'glow', 'outline', 'rim', 'silhouette', 'icon']) this._masks[k].finish()
    this._masks = null
    this._key = ''
  }

  // The live tube into its own surface: cleared, then drawn.
  _paintTube(M) {
    const cr = M.iconCr
    cr.save()
    cr.setOperator(Cairo.Operator.CLEAR)
    cr.paint()
    cr.restore()
    cr.save()
    cr.translate(M.L.reach, M.L.reach)
    cr.scale(M.L.scale, M.L.scale)
    cr.translate(-TUBE_BOX.x, -TUBE_BOX.y)
    drawTube(cr, this._tube)
    cr.restore()
    M.icon.flush()
  }

  // cr is already clipped to the bar. env:
  //   splash      the Splash; level, the water's band levels (band i sits at
  //               x = i * w / (n - 1)), as 0..1 of waveHeight
  //   colors      the palette; timeS, seconds; text, the custom word
  //   impact      (band, dv) => void: a drop landing pushes the water, or null
  // When a wave hits the mark it shows whole and at full strength, not just
  // the part under water.
  draw(cr, w, h, env) {
    const { splash, colors, timeS, level, waveHeight, impact, text } = env
    const n = splash.value.length
    // A vertical or very short taskbar has no room for it.
    if (h < 8 || w < h * 4 || n < 2) return
    const M = this._build(w, h, text)
    if (M.L.total > w * TOO_WIDE) return
    const step = w / (n - 1)
    const i0 = Math.max(0, Math.floor(M.ox / step))
    const i1 = Math.min(n - 1, Math.ceil((M.ox + M.mw) / step))
    const alpha = clamp(splash.peak(i0, i1), 0, 1)
    const dt = clamp(timeS - (this._lastT ?? timeS), 0, 0.1)
    this._lastT = timeS
    if (alpha < 0.004) {
      this._sim.clearParticles()
      return
    }
    const em = M.L.em
    const se = this._simEnv
    se.level = level
    se.bandStep = step
    se.em = em
    se.h = h
    se.w = w
    se.waveHeight = waveHeight
    se.impact = impact
    se.timeS = timeS
    this._sim.step(dt, se)
    stepLogo(this._tube, level, dt)
    this._paintTube(M)

    // One colour for the letters: the wallpaper's lesser colour furthest from
    // the water. The rim and halo take the water's surface line. The drips
    // take a brand colour of their own that stands out from both.
    const fill = colors.glyphA ?? colors.foam
    const line = this._line(fill, colors.foam)
    const style = this._dripStyle(fill, colors.shallow, colors.foam, colors.deep, em)
    const x0 = M.ox

    cr.save()
    // Only the mark and the room below it (drips, falling drops) are drawn.
    cr.rectangle(x0 - 2, M.oy - 4, M.mw + 4, h - M.oy + 4)
    cr.clip()
    cr.pushGroup()

    const sweepX = x0 + ((timeS * 0.35) % 1.6 - 0.3) * M.mw

    // The drips' glow, rim and keyline go under the letters, so the letters
    // close over where the drips leave them.
    drawDripsUnder(cr, this._sim, em, style)

    const shadow = Math.max(1, Math.round(h / 40))
    const sw = M.mw / STRIPS
    for (let s = 0; s < STRIPS; s++) {
      // Whole-pixel strip edges, so neighbouring strips never overlap (a
      // half-pixel overlap painted the glow twice: a thin seam).
      const sx = Math.round(x0 + s * sw)
      const dy = WOBBLE * h * Math.sin(timeS * 7 + sx * 0.09) * alpha
      cr.save()
      cr.rectangle(sx, M.oy - 4, Math.round(x0 + (s + 1) * sw) - sx, M.mh + 8)
      cr.clip()
      cr.setSourceRGBA(...colors.foam, 0.95)
      cr.maskSurface(M.glow, x0, M.oy + dy)
      // A shadow in the water's deepest colour keeps it legible on any wallpaper.
      cr.setSourceRGBA(style.shadow[0], style.shadow[1], style.shadow[2], 0.7)
      cr.maskSurface(M.rim, x0 + shadow * 0.5, M.oy + dy + shadow)
      cr.maskSurface(M.silhouette, x0 + shadow * 0.5, M.oy + dy + shadow)
      cr.setSourceRGBA(...colors.foam, 1)
      cr.maskSurface(M.rim, x0, M.oy + dy)
      cr.setSourceRGBA(...line, 1)
      cr.maskSurface(M.outline, x0, M.oy + dy)
      cr.setSourceRGBA(...fill, 1)
      cr.maskSurface(M.ink, x0, M.oy + dy)
      // The caustic is locked to user space when set: set it moved to sweepX.
      cr.translate(sweepX, 0)
      cr.setSource(M.caustic)
      cr.translate(-sweepX, 0)
      cr.maskSurface(M.ink, x0, M.oy + dy)
      // The live tube in its own colours, untouched by the wallpaper.
      cr.setSourceSurface(M.icon, M.iconOx, M.iconOy + dy)
      cr.paint()
      cr.restore()
    }

    // The paint itself, over the letters: glossy, in its own colour.
    drawDripsOver(cr, this._sim, em, style)

    cr.popGroupToSource()
    cr.paintWithAlpha(alpha)
    cr.restore()
  }

  // Lets go of the masks while the wordmark is turned off.
  release() {
    this._free()
  }

  destroy() {
    this._free()
  }
}

// Per band: how much the mark is showing there. A surge of water up over the
// mark shows it at full strength at once; it holds a moment, then fades fast.
export class Splash {
  constructor(bands) {
    this.resize(bands)
  }

  resize(bands) {
    this.value = new Float32Array(bands) // what is drawn
    this._hold = new Float32Array(bands) // seconds left at full strength
    this._prev = new Float32Array(bands)
  }

  // Strongest value over bands i0..i1.
  peak(i0, i1) {
    let p = 0
    for (let i = Math.max(0, i0); i <= Math.min(this.value.length - 1, i1); i++) p = Math.max(p, this.value[i])
    return p
  }

  // Returns true while anything is still showing.
  step(level, dt, waveHeight, active) {
    if (!(dt > 0)) return this.value.some((v) => v > 0)
    const { _hold: hold, value } = this
    const n = value.length
    const fade = Math.exp(-dt / FADE_S)
    const attack = 1 - Math.exp(-dt / ATTACK_S)
    for (let i = 0; i < n; i++) {
      const rise = (level[i] - this._prev[i]) / dt
      this._prev[i] = level[i]
      // The water has to reach the mark and be surging, not just swelling.
      if (active && rise > RISE_MIN && level[i] * waveHeight > REVEAL_FLOOR) {
        for (let j = Math.max(0, i - SPREAD); j <= Math.min(n - 1, i + SPREAD); j++) hold[j] = HOLD_S
      }
    }
    let any = false
    for (let i = 0; i < n; i++) {
      if (hold[i] > 0) {
        hold[i] -= dt
        value[i] += (1 - value[i]) * attack
        if (value[i] > 0.98) value[i] = 1
      } else {
        value[i] *= fade
        if (value[i] < 0.002) value[i] = 0
      }
      if (value[i]) any = true
    }
    return any
  }

  clear() {
    this.value.fill(0)
    this._hold.fill(0)
  }
}

// Spotify's own MPRIS player (also ncspot, spotifyd, spotify-player).
const SPOTIFY = /^org\.mpris\.MediaPlayer2\.(spotify|ncspot|spotifyd|spotify_player)(\.|$)/
const MPRIS_PATH = '/org/mpris/MediaPlayer2'
const PLAYER_IFACE = 'org.mpris.MediaPlayer2.Player'

// Tells whether Spotify is playing right now, from its MPRIS status.
export class SpotifyWatch {
  constructor(onChange) {
    this._onChange = onChange
    this._bus = Gio.DBus.session
    this._cancel = new Gio.Cancellable()
    this._owners = new Map() // unique bus name -> well-known Spotify name
    this._playing = new Map() // well-known name -> bool
    this.playing = false

    this._nameSub = this._bus.signal_subscribe('org.freedesktop.DBus', 'org.freedesktop.DBus',
      'NameOwnerChanged', '/org/freedesktop/DBus', null, Gio.DBusSignalFlags.NONE,
      (_c, _s, _p, _i, _n, params) => {
        const [name, oldOwner, newOwner] = params.deepUnpack()
        if (!SPOTIFY.test(name)) return
        if (oldOwner) this._owners.delete(oldOwner)
        this._playing.delete(name)
        if (newOwner) this._track(name, newOwner)
        this._update()
      })

    this._propSub = this._bus.signal_subscribe(null, 'org.freedesktop.DBus.Properties',
      'PropertiesChanged', MPRIS_PATH, null, Gio.DBusSignalFlags.NONE,
      (_c, sender, _p, _i, _n, params) => {
        const name = this._owners.get(sender)
        if (!name) return
        const [iface, changed, invalidated] = params.recursiveUnpack()
        if (iface !== PLAYER_IFACE) return
        if ('PlaybackStatus' in changed) {
          this._playing.set(name, changed.PlaybackStatus === 'Playing')
          this._update()
        } else if (invalidated.includes('PlaybackStatus')) {
          this._track(name, sender) // ask for it again
        }
      })

    this._call('org.freedesktop.DBus', '/org/freedesktop/DBus', 'org.freedesktop.DBus',
      'ListNames', null, (r) => {
        for (const name of r.deepUnpack()[0].filter((n) => SPOTIFY.test(n))) {
          this._call('org.freedesktop.DBus', '/org/freedesktop/DBus', 'org.freedesktop.DBus',
            'GetNameOwner', new GLib.Variant('(s)', [name]), (o) => this._track(name, o.deepUnpack()[0]))
        }
      })
  }

  _call(dest, path, iface, method, args, done) {
    this._bus.call(dest, path, iface, method, args, null, Gio.DBusCallFlags.NONE, 2000, this._cancel,
      (bus, res) => {
        let r
        try {
          r = bus.call_finish(res)
        } catch {
          return
        }
        done(r)
      })
  }

  _track(name, owner) {
    this._owners.set(owner, name)
    this._call(owner, MPRIS_PATH, 'org.freedesktop.DBus.Properties', 'Get',
      new GLib.Variant('(ss)', [PLAYER_IFACE, 'PlaybackStatus']), (r) => {
        if (this._owners.get(owner) !== name) return
        this._playing.set(name, r.recursiveUnpack()[0] === 'Playing')
        this._update()
      })
  }

  _update() {
    const playing = [...this._playing.values()].some(Boolean)
    if (playing === this.playing) return
    this.playing = playing
    this._onChange(playing)
  }

  destroy() {
    this._cancel.cancel()
    this._bus.signal_unsubscribe(this._nameSub)
    this._bus.signal_unsubscribe(this._propSub)
    this._owners.clear()
    this._playing.clear()
    this._onChange = () => {}
  }
}
