#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Water Panel audio analyzer.

Captures whatever is playing (monitor of the default output), runs a dual
resolution FFT and writes one frame per hop to stdout:

    0xFF, then BANDS bytes (0..254), low frequency first.

A long window resolves the bass, a short one keeps the highs snappy.
Follows the default output device if it changes.
"""
import ctypes
import os
import signal
import subprocess
import sys
import time

import numpy as np

RATE = 48000
BANDS = int(os.environ.get('LT_BANDS', '72'))
FPS = int(os.environ.get('LT_FPS', '120'))
F_LO, F_HI = 32.0, 16000.0
SPLIT_HZ = 280.0          # below: long window, above: short window
LONG_N, SHORT_N = 4096, 1024
RANGE_DB = 48.0           # dynamic range shown on the bar
TILT_DB_PER_OCT = 3.0     # compensates music's natural pink-noise slope
AGC_RELEASE_DB = 6.0      # per second the ceiling may fall when music gets quieter
SILENCE_DB = -85.0

HOP = RATE // FPS
out = sys.stdout.buffer


def band_bins(n):
    freqs = np.fft.rfftfreq(n, 1.0 / RATE)
    edges = np.geomspace(F_LO, F_HI, BANDS + 1)
    idx = []
    for lo, hi in zip(edges[:-1], edges[1:]):
        sel = np.nonzero((freqs >= lo) & (freqs < hi))[0]
        if sel.size == 0:  # band narrower than one bin: use nearest bin
            sel = np.array([int(np.argmin(np.abs(freqs - np.sqrt(lo * hi))))])
        idx.append(sel)
    # Pad to a matrix (repeating a bin is harmless for max) so one gather does all bands.
    width = max(len(i) for i in idx)
    mat = np.array([np.pad(i, (0, width - len(i)), mode='edge') for i in idx])
    return mat, np.sqrt(edges[:-1] * edges[1:])


long_bins, centers = band_bins(LONG_N)
short_bins, _ = band_bins(SHORT_N)
use_long = centers < SPLIT_HZ
long_win = np.hanning(LONG_N).astype(np.float32)
short_win = np.hanning(SHORT_N).astype(np.float32)
# Normalise so a full scale sine reads ~0 dB in either window.
long_norm = 2.0 / long_win.sum()
short_norm = 2.0 / short_win.sum()
tilt = TILT_DB_PER_OCT * np.log2(centers / 1000.0)


PR_SET_PDEATHSIG = 1


def die_with_parent():
    """Ask the kernel to end this process when its parent goes away."""
    try:
        ctypes.CDLL(None, use_errno=True).prctl(PR_SET_PDEATHSIG, signal.SIGTERM)
    except Exception:
        pass


def default_sink():
    try:
        return subprocess.run(['pactl', 'get-default-sink'], capture_output=True,
                              text=True, timeout=2).stdout.strip()
    except Exception:
        return ''


def start_capture(sink):
    dev = f'{sink}.monitor' if sink else '@DEFAULT_MONITOR@'
    return subprocess.Popen(
        ['parec', '-d', dev, '--format=float32le', f'--rate={RATE}',
         '--channels=1', '--latency-msec=8', '--raw',
         '--client-name=Water Panel', '--stream-name=visualizer'],
        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, preexec_fn=die_with_parent)


def main():
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    # Never outlive the shell that started us. During silence nothing is
    # written, so a closed pipe alone would not end an orphan.
    parent = os.getppid()
    die_with_parent()
    if os.getppid() != parent:
        return
    ring = np.zeros(LONG_N, dtype=np.float32)
    ceiling = -20.0
    was_silent = False
    sink = default_sink()
    proc = start_capture(sink)
    last_check = time.monotonic()
    chunk_bytes = HOP * 4

    while True:
        data = proc.stdout.read(chunk_bytes)
        if not data or len(data) < chunk_bytes:
            proc.kill()
            time.sleep(0.5)
            sink = default_sink()
            proc = start_capture(sink)
            continue

        now = time.monotonic()
        if now - last_check > 2.0:
            last_check = now
            if os.getppid() != parent:
                proc.kill()
                return
            s = default_sink()
            if s and s != sink:
                sink = s
                proc.kill()
                proc = start_capture(sink)
                continue

        ring = np.roll(ring, -HOP)
        ring[-HOP:] = np.frombuffer(data, dtype=np.float32)

        spec_l = np.abs(np.fft.rfft(ring * long_win)) * long_norm
        spec_s = np.abs(np.fft.rfft(ring[-SHORT_N:] * short_win)) * short_norm
        pow_l, pow_s = spec_l ** 2, spec_s ** 2

        power = np.where(use_long, pow_l[long_bins].max(axis=1),
                         pow_s[short_bins].max(axis=1))

        db = 10.0 * np.log10(power + 1e-12) + tilt
        peak = db.max()

        if peak < SILENCE_DB:
            if not was_silent:
                out.write(b'\xff' + bytes(BANDS))
                out.flush()
                was_silent = True
            continue
        was_silent = False

        # Auto gain: jump up instantly, drift down slowly.
        ceiling = max(peak, ceiling - AGC_RELEASE_DB / FPS, -60.0)
        level = np.clip((db - (ceiling - RANGE_DB)) / RANGE_DB, 0.0, 1.0)
        out.write(b'\xff' + (level * 254).astype(np.uint8).tobytes())
        out.flush()


if __name__ == '__main__':
    try:
        main()
    except (BrokenPipeError, KeyboardInterrupt):
        pass
