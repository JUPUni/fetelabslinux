// SPDX-License-Identifier: GPL-2.0-or-later
// The water as a 1D height field, one column per band. Each column has a
// height (its level, 0..1 of the wave height) and a vertical velocity.
//
//   The music drives each column through a spring towards its band's level:
//   stiff and critically damped on the way up, so beats land on time
//   ('responsiveness'), softer and a little underdamped on the way down, so
//   it sloshes as it settles ('fall-speed').
//
//   Neighbours pull on each other through the 1D wave equation,
//   c² (h[i-1] + h[i+1] - 2 h[i]), with a small fourth-difference term for
//   capillary dispersion: shallow capillary-gravity waves follow
//   ω² = (g k + (σ/ρ) k³) k H, so short ripples run faster than long swells.
//   'surface-tension' sets the wave speed c. Viscosity damps the motion,
//   shortest ripples most, and both ends reflect like the walls of a tank.
//
//   Integration is semi-implicit (symplectic) Euler in fixed substeps of at
//   least 240 Hz, short enough that a wave never crosses more than half a
//   band per step (CFL), so it is stable at any frame rate.
//
// Nothing here imports Shell modules, so tools can simulate it offline.

import GLib from 'gi://GLib'

import { OCEAN, copyPalette } from './palette.js'
import { Splash } from './wordmark.js'

const SUBSTEP_HZ = 240 // at least this many substeps a second
const MAX_SUBSTEPS = 40 // per frame; frames are capped at 50 ms anyway
const CFL = 0.5 // a wave crosses at most this many bands per substep
const SPRING = 260 // falling stiffness at fall-speed 1 (as before)
const DAMPING = 22 // falling damping at fall-speed 1: ζ ≈ 0.68, a little slosh
const RISE_CAP = 0.97 // responsiveness above this would need absurdly short steps
const WAVE_MIN = 15 // bands/s at surface-tension 0
const WAVE_PER = 210 // more bands/s per unit of surface-tension (0.5 gives 120)
const CAPILLARY = 0.04 // fourth-difference stiffness, as a share of c²
const VISCOSITY = 1.5 // 1/s, plain damping of the vertical velocity
const VISC_SPREAD = 6 // 1/s, damping of velocity differences (short ripples die first)
const TOP = 1 // levels stay in 0..1
const BACK_RATE = 0.9 // back wave: keeps this share of its gap every 1/60 s

export class Liquid {
  constructor(bands, cfg) {
    this.cfg = cfg
    this.colors = copyPalette(OCEAN)
    this.spotify = false // the wordmark only wakes while Spotify plays
    this.resize(bands)
  }

  resize(bands) {
    this.bands = bands
    this.target = new Float32Array(bands)
    // Heights and velocities with two ghost columns past each end, for the
    // reflecting walls; level and vel are views of the real columns.
    this._lv = new Float32Array(bands + 4)
    this._vv = new Float32Array(bands + 4)
    this.level = this._lv.subarray(2, bands + 2)
    this.vel = this._vv.subarray(2, bands + 2)
    this._acc = new Float32Array(bands)
    this.back = new Float32Array(bands) // slower layer behind for depth
    this.splash = new Splash(bands)
    this.lastAudio = 0
    this._carry = 0
  }

  setFrame(bytes) {
    for (let i = 0; i < this.bands; i++) this.target[i] = bytes[i] / 254
    this.lastAudio = GLib.get_monotonic_time() / 1000
  }

  // A kick to one column's velocity (levels per second), e.g. a drop of paint
  // landing in it (negative pushes it down).
  impulse(i, dv) {
    if (!(i >= 0 && i < this.bands) || !Number.isFinite(dv)) return
    this.vel[i] += dv
    this._kicked = true
  }

  // Coefficients from the settings, worked out again only when they change.
  _coefficients() {
    const { responsiveness, fallSpeed, surfaceTension } = this.cfg
    const k = this._k
    if (k && k.r === responsiveness && k.f === fallSpeed && k.s === surfaceTension) return k
    // The old exponential chase had rate -60 ln(1 - r); a critically damped
    // spring a third faster arrives at about the same time.
    const rate = -60 * Math.log(1 - Math.min(Math.max(responsiveness, 0.05), RISE_CAP)) * 1.35
    const c = WAVE_MIN + WAVE_PER * Math.max(0, surfaceTension)
    const c2 = c * c
    const kDown = SPRING * fallSpeed
    // Fastest mode: the stiffest spring plus the shortest wave on the grid.
    const wMax = Math.sqrt(Math.max(rate * rate, kDown) + 4 * c2 + 16 * CAPILLARY * c2)
    const hz = Math.max(SUBSTEP_HZ, c / CFL, wMax / 0.6)
    this._k = {
      r: responsiveness, f: fallSpeed, s: surfaceTension,
      kUp: rate * rate, dUp: 2 * rate, kDown, dDown: DAMPING * Math.sqrt(fallSpeed),
      c2, beta: CAPILLARY * c2, sub: 1 / hz,
    }
    return this._k
  }

  _substep(k, h) {
    const { target, bands, _lv: lv, _vv: vv, _acc: acc } = this
    // Reflecting ends: the ghost columns mirror the ones inside each wall.
    const n = bands + 2 // index of the first ghost past the right end
    lv[1] = lv[2]
    lv[0] = lv[3]
    lv[n] = lv[n - 1]
    lv[n + 1] = lv[n - 2]
    vv[1] = vv[2]
    vv[n] = vv[n - 1]
    for (let i = 0; i < bands; i++) {
      const j = i + 2
      const y = lv[j]
      const v = vv[j]
      const t = target[i]
      let a = t > y ? k.kUp * (t - y) - k.dUp * v : k.kDown * (t - y) - k.dDown * v
      a += k.c2 * (lv[j - 1] + lv[j + 1] - 2 * y)
      a -= k.beta * (lv[j - 2] - 4 * lv[j - 1] + 6 * y - 4 * lv[j + 1] + lv[j + 2])
      a -= VISCOSITY * v
      a += VISC_SPREAD * (vv[j - 1] + vv[j + 1] - 2 * v)
      acc[i] = a
    }
    // Semi-implicit Euler: the new velocity moves the height.
    for (let i = 0; i < bands; i++) {
      const j = i + 2
      let v = vv[j] + acc[i] * h
      let y = lv[j] + v * h
      if (y < 0) {
        y = 0
        if (v < 0) v = 0
      } else if (y > TOP) {
        y = TOP
        if (v > 0) v = 0
      }
      vv[j] = v
      lv[j] = y
    }
  }

  step(dt) {
    const { level, vel, back, bands, cfg } = this
    if (dt > 0) {
      const k = this._coefficients()
      // Fixed substeps; what is left over carries into the next frame.
      let left = Math.min(dt + this._carry, MAX_SUBSTEPS * k.sub)
      let n = 0
      while (left >= k.sub && n < MAX_SUBSTEPS) {
        this._substep(k, k.sub)
        left -= k.sub
        n++
      }
      this._carry = left
      const bk = 1 - Math.pow(BACK_RATE, dt * 60)
      for (let i = 0; i < bands; i++) back[i] += (level[i] - back[i]) * bk
    }
    let moving = this._kicked
    this._kicked = false
    for (let i = 0; i < bands && !moving; i++) {
      if (level[i] > 0.002 || back[i] > 0.002 || Math.abs(vel[i]) > 0.01) moving = true
    }
    if (this.splash.step(level, dt, cfg.waveHeight, cfg.wordmark && this.spotify)) moving = true
    return moving
  }
}
