// SPDX-License-Identifier: GPL-2.0-or-later
// The paint drips under the wordmark's letters, as pendant drops.
//
// Each drip is Shaw's dripping-faucet oscillator: a mass m of paint hanging
// x below its tip, held up by surface tension acting as a spring and slowed
// by the paint's viscosity:
//     d(m v)/dt = m g - k x - b v      (paint flows in at rest, so the
//     m dv/dt  = m g - k x - b v - v dm/dt   inflow brakes it a little)
// Paint flows in slowly all the time and faster with the music under the
// drip. Once x passes a critical length the neck pinches off (Tate's law
// sets how much a drop can weigh, Rayleigh-Plateau how the thread breaks):
// about 70% of the mass falls as a drop, the rest recoils up and jiggles,
// and sometimes a small satellite droplet breaks from the neck too. The
// thread thins as it stretches; the bulb's radius goes with the cube root of
// its mass. Every drip is a little different (stiffness, flow, how long it
// can stretch), so they never bob in step. A beat kicks the drips under it
// down, harder the sharper the hit, so drops tend to fall on the hits.
//
// A bass hit knocks every drip at once and flings blobs of paint up off the
// letters; they arc over and fall into the water like any other drop.
//
// Each drip also swings sideways as a damped pendulum as long as its thread,
// pushed by the slope of the water under it and knocked by the beats; a drop
// leaves with the swing's speed. When the neck breaks, a thin ligament of
// paint stretches between the drip and the falling drop and snaps back.
//
// Falling drops feel gravity and quadratic air drag (smaller drops reach a
// lower terminal speed), wobble in Rayleigh's mode 2 (smaller drops faster,
// and damped sooner), and stretch a little along their velocity. A drop that
// reaches the water pushes that band down and throws a small crown of
// droplets; with no water there it splats on the floor of the bar and fades.
//
// Lengths are in em (the wordmark's font size), times in seconds, positions
// on screen in pixels. Nothing here imports Shell modules.

import Cairo from 'cairo'

// The hanging drip: a full drop (m = 1) hangs G / K = 0.4 em and wobbles
// at sqrt(K) / 2π = 2 Hz, with a damping ratio of 0.25, like jelly. (A
// longer hang leaves the drops no room to fall on a 40 px bar.)
const K = (2 * Math.PI * 2) ** 2 // spring per unit mass, 1/s²
const G = 0.4 * K // em/s²
const B = 2 * 0.25 * Math.sqrt(K) // viscous damping
const X_CRIT = 0.45 // em: past this the neck pinches off
const M_MIN = 0.06 // never lighter than this
const FALL_SHARE = 0.78 // of the mass leaves with the drop
const SATELLITE_P = 0.4 // chance of a satellite droplet from the neck
const SATELLITE_M = 0.035 // its mass, as a share of the drop's
const RECOIL = 0.9 // em/s: the rest springs back up at least this fast
const FLOW_IDLE = 0.07 // paint per second, always
const FLOW_MUSIC = 1.05 // more per second at full volume
const KICK = 2.8 // em/s down on the sharpest beat
const KICK_RISE = 2.5 // level/s: a rise this sharp starts to kick
const KICK_FULL = 9 // level/s: and this sharp kicks fully
const KICK_GAP_S = 0.1
// Every drip is a little different (multipliers, from its seed).
const VARY_K = [0.8, 1.25] // stiffness: how fast it bobs
const VARY_FLOW = [0.55, 1.5] // how fast paint runs into it
const VARY_CRIT = [0.8, 1.25] // how far it stretches before it breaks
const VARY_R = [0.7, 1.2] // how fat its paint is
// The sideways swing: a pendulum as long as the thread.
const SWAY_LEN = 0.08 // em added to the thread's length
const SWAY_W_MAX = 2 * Math.PI * 4 // rad/s, short drips don't buzz
const SWAY_DAMP = 0.12 // damping ratio
const SWAY_SLOPE = 5 // em/s² per unit of water slope (levels per band) x volume
const SWAY_KICK = 0.9 // em/s sideways, at most, on a full kick
const SWAY_MAX = 0.3 // em either way
// The ligament left between the drip and the drop as the neck breaks.
const LIG_S = 0.09 // s until it snaps
const LIG_W = 0.4 // of the drop's radius, at its thickest
const R_FULL = 0.088 // em: bulb radius of a full drop
const NECK = 0.04 // em: half width of the thread where it leaves the letter
const NECK_REF = 0.12 // em: the thread starts thinning past this length
const NECK_MIN = 0.3 // and gets no thinner than this share

// The bass: a knock for every drip and paint thrown up off the letters.
const BASS_KNOCK = 2.2 // em/s down, at full strength
const SPRAY = [2, 7] // blobs, faintest to strongest hit
const SPRAY_UP = [6, 11] // em/s upwards
const SPRAY_SIDE = 2.5 // em/s sideways, at most
const SPRAY_M = [0.3, 0.7] // mass, as a share of a full drop

// Falling drops.
const DRAG = G * R_FULL / 6 ** 2 // a full drop's terminal speed is 6 em/s
const WATER_DRAG = 12 // times more drag once under water
const WOBBLE_W = 2 * Math.PI * 7 // rad/s for a full drop, ∝ r^-1.5 (Rayleigh, mode 2)
const WOBBLE_W_MAX = 70 // visible wobble only; tinier drops just stay round
const WOBBLE_TAU = 0.22 // s for a full drop, ∝ r² (Lamb's viscous decay)
const STRETCH = 0.035 // per em/s of speed, along the velocity (motion blur)
const STRETCH_MAX = 0.5
const IMPACT = 2.2 // how hard a landing drop pushes the water down
const CROWN_SPEED = [0.3, 0.55] // of the impact speed, upwards
const CROWN_SIDE = [0.15, 0.45] // of the impact speed, sideways
const SPLAT_S = 0.25 // a splat on a dry floor fades in this long
const DRY = 1.5 // px of water or less is a dry floor

const SUB_HZ = 240
const MAX_SUB = 24
const MAX_PARTS = 96 // drops, satellites and crown droplets at once
const MAX_SPLATS = 24

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v))
const bulbR = (m, f = 1) => R_FULL * f * Math.cbrt(m)
const lerp = ([a, b], t) => a + (b - a) * t

export class DripSim {
  // rand: a () => [0, 1) source, so offline renders can be repeatable.
  constructor(rand = Math.random) {
    this.rand = rand
    this.drips = []
    this.parts = []
    for (let i = 0; i < MAX_PARTS; i++) {
      this.parts.push({ x: 0, y: 0, vx: 0, vy: 0, m: 0, r: 0, e: 0, ev: 0, wet: false, crown: false, surface: -1, lig: 0, lx: 0, ly: 0, rf: 1 })
    }
    this.nParts = 0
    this.splats = []
    for (let i = 0; i < MAX_SPLATS; i++) this.splats.push({ x: 0, y: 0, r: 0, age: 0 })
    this.nSplats = 0
    this._carry = 0
  }

  // tips: [[x, y], ...] in pixels, where each drip leaves its letter.
  reset(tips) {
    this.drips = tips.map(([x, y], i) => {
      const seed = (i * 0.6180339 + 0.21) % 1
      const m = 0.25 + 0.5 * seed
      const hash = (k) => (Math.sin((i + 1) * 12.9898 + k * 78.233) * 43758.5453) % 1
      const u = (k) => Math.abs(hash(k))
      const kf = lerp(VARY_K, u(1))
      return {
        x, y, m, ext: G * m / (K * kf * kf), v: 0, prev: 0, lastKick: -1, seed, lvl: 0, t: 0, slope: 0,
        kf, flow: lerp(VARY_FLOW, u(2)), crit: X_CRIT * lerp(VARY_CRIT, u(3)), rf: lerp(VARY_R, u(4)), sx: 0, svx: 0,
      }
    })
    this.clearParticles()
  }

  // A bass hit (strength 0..1): every drip gets knocked down and swung.
  knock(strength) {
    for (const d of this.drips) {
      d.v += BASS_KNOCK * strength * (0.7 + 0.6 * this.rand())
      d.svx += (this.rand() * 2 - 1) * SWAY_KICK * strength
    }
  }

  // And paint flies up from the tops of the letters, between x0 and x1 (px)
  // at height y (px).
  spray(strength, x0, x1, y, em) {
    const n = Math.round(SPRAY[0] + (SPRAY[1] - SPRAY[0]) * strength)
    for (let k = 0; k < n; k++) {
      const up = lerp(SPRAY_UP, this.rand()) * (0.6 + 0.4 * strength)
      const side = (this.rand() * 2 - 1) * SPRAY_SIDE
      const x = x0 + (x1 - x0) * this.rand()
      this._spawn(x, y + this.rand() * 0.15 * em, side * em, -up * em,
        lerp(SPRAY_M, this.rand()), 0.6, false, em, lerp(VARY_R, this.rand()))
    }
  }

  clearParticles() {
    this.nParts = 0
    this.nSplats = 0
    this._carry = 0
  }

  // env: { level, bandStep (px per band), em (px), h (px, the bar), w (px),
  //        waveHeight, impact(i, dv) or null, timeS }
  step(dt, env) {
    if (!(dt > 0)) return
    const { level, bandStep, timeS } = env
    const n = level.length
    // Music under each drip, and a kick on a sharp beat (once per frame).
    for (const d of this.drips) {
      const i = clamp(Math.round(d.x / bandStep), 0, n - 1)
      const lvl = clamp(level[i], 0, 1)
      const rise = (lvl - d.prev) / dt
      d.prev = lvl
      d.lvl = lvl
      d.slope = (level[Math.min(n - 1, i + 1)] - level[Math.max(0, i - 1)]) / 2
      if (rise > KICK_RISE && lvl > 0.15 && timeS - d.lastKick > KICK_GAP_S) {
        const hit = clamp((rise - KICK_RISE) / (KICK_FULL - KICK_RISE), 0, 1)
        d.v += KICK * (0.35 + 0.65 * hit) * (0.6 + 0.4 * lvl)
        d.svx += (this.rand() * 2 - 1) * SWAY_KICK * hit
        d.lastKick = timeS
      }
    }
    const sub = 1 / SUB_HZ
    let left = Math.min(dt + this._carry, MAX_SUB * sub)
    for (let k = 0; left >= sub && k < MAX_SUB; k++, left -= sub) this._substep(sub, env)
    this._carry = left
    this._stepSplats(dt)
  }

  _substep(h, env) {
    const { em } = env
    for (const d of this.drips) {
      d.t += h
      const dm = (FLOW_IDLE + FLOW_MUSIC * d.lvl ** 1.1) * d.flow * h
      // m dv/dt = m g - k x - b v - v dm/dt, semi-implicit Euler.
      const a = G - (K * d.kf * d.kf * d.ext + B * d.kf * d.v) / d.m - d.v * (dm / h) / d.m
      d.v += a * h
      d.ext = Math.max(0, d.ext + d.v * h)
      d.m += dm
      // The swing: x'' = -ω² x - 2ζω x' + push, ω² = g / length.
      const w = Math.min(SWAY_W_MAX, Math.sqrt(G / (SWAY_LEN + d.ext)))
      const push = -SWAY_SLOPE * d.slope * d.lvl
      d.svx += (push - w * w * d.sx - 2 * SWAY_DAMP * w * d.svx) * h
      d.sx = clamp(d.sx + d.svx * h, -SWAY_MAX, SWAY_MAX)
      if (d.ext > d.crit) this._pinch(d, em)
    }
    this._stepParts(h, env)
  }

  // The neck breaks: most of the paint falls as a drop, the rest recoils.
  _pinch(d, em) {
    const fall = d.m * FALL_SHARE
    const bx = d.x + this.sway(d) * em
    const vy = Math.max(d.v, 0.5)
    const vx = d.svx * em * 0.8
    const p = this._spawn(bx, d.y + d.ext * em, vx, vy * em, fall, 0.35, false, em, d.rf)
    if (p) {
      // The ligament: from where the neck broke down to the drop.
      p.lig = 1
      p.lx = bx
      p.ly = d.y + d.ext * 0.3 * em
    }
    if (this.rand() < SATELLITE_P) {
      // A little bead from the thread, just above the drop and a touch slower.
      this._spawn(bx, d.y + d.ext * 0.55 * em, vx, vy * 0.8 * em, fall * SATELLITE_M, 0.2, false, em, d.rf)
    }
    d.m = Math.max(M_MIN, d.m - fall)
    d.ext *= 0.3
    d.v = -Math.max(RECOIL, 0.4 * Math.abs(d.v))
  }

  _spawn(x, y, vx, vy, m, wobble, crown, em, rf = 1) {
    if (this.nParts >= MAX_PARTS) return null
    const p = this.parts[this.nParts++]
    p.x = x
    p.y = y
    p.vx = vx
    p.vy = vy
    p.m = m
    p.r = bulbR(m, rf) * em
    p.rf = rf
    p.e = wobble
    p.ev = 0
    p.wet = false
    p.crown = crown
    p.surface = -1 // not known yet
    p.lig = 0
    return p
  }

  // Water surface (px from the top) at x, or the floor where there is none.
  _surface(x, env) {
    const { level, bandStep, h, waveHeight } = env
    const n = level.length
    const f = clamp(x / bandStep, 0, n - 1)
    const i = Math.floor(f)
    const j = Math.min(n - 1, i + 1)
    const lv = level[i] + (level[j] - level[i]) * (f - i)
    return h - clamp(lv, 0, 1) * h * waveHeight
  }

  _stepParts(h, env) {
    const { em, w } = env
    const g = G * em
    let keep = 0
    for (let i = 0; i < this.nParts; i++) {
      const p = this.parts[i]
      // Born under the water (the mark showing through a high wave): it
      // just sinks slowly, no splash, until a trough leaves it in the air.
      if (p.surface < 0) {
        p.surface = this._surface(p.x, env)
        p.wet = p.y + p.r * 0.5 >= p.surface
      }
      // Quadratic drag, per unit mass: ∝ v² r² / r³.
      const rEm = Math.max(p.r / em, 0.01)
      const speed = Math.hypot(p.vx, p.vy) / em
      const drag = DRAG * (p.wet ? WATER_DRAG : 1) * speed / rEm // 1/s
      p.vx += -drag * p.vx * h
      p.vy += (g - drag * p.vy) * h
      p.x += p.vx * h
      p.y += p.vy * h
      // Mode-2 wobble: e'' = -ω² e - (2/τ) e'.
      const rr = rEm / R_FULL
      const wv = Math.min(WOBBLE_W_MAX, WOBBLE_W * rr ** -1.5)
      const tau = WOBBLE_TAU * rr * rr
      p.ev += (-wv * wv * p.e - 2 * p.ev / Math.max(tau, 0.02)) * h
      p.e += p.ev * h
      if (p.lig > 0) {
        // The ligament snaps and its top springs down after the drop.
        p.lig = Math.max(0, p.lig - h / LIG_S)
        p.ly += (p.y - p.ly) * (1 - Math.exp(-h / (LIG_S * 0.6)))
        p.lx += (p.x - p.lx) * (1 - Math.exp(-h / LIG_S))
      }

      let alive = p.x > -p.r && p.x < w + p.r
      const under = p.y + p.r * 0.5 >= this._surface(p.x, env)
      if (p.wet && !under) {
        p.wet = false // the water fell away from it: falling through air again
      } else if (alive && under && !p.wet) {
        // Into the surface, falling or met by a rising wave.
        alive = false
        this._land(p, env)
      } else if (alive && p.y >= env.h) {
        alive = false
        // Under water it just settles out of sight; on a dry floor it splats.
        if (!p.wet) this._splat(p.x, env.h, p.r)
      }
      if (alive) {
        this.parts[i] = this.parts[keep]
        this.parts[keep++] = p
      }
    }
    this.nParts = keep
  }

  // A drop reaches the surface: dents the water and throws a crown, or
  // splats if there is no water there.
  _land(p, env) {
    const { em, h, waveHeight, bandStep, impact } = env
    const surf = this._surface(p.x, env)
    if (h - surf <= DRY) {
      this._splat(p.x, h, p.r)
      return
    }
    if (p.crown) return // a crown droplet falling back just merges
    if (impact) {
      const i = Math.round(p.x / bandStep)
      // Momentum into the column, in levels per second.
      impact(i, -IMPACT * p.m * p.vy / (h * waveHeight))
    }
    const v = Math.max(p.vy, 0)
    const count = 2 + Math.floor(this.rand() * 3)
    for (let k = 0; k < count; k++) {
      const side = (k % 2 ? 1 : -1) * (CROWN_SIDE[0] + this.rand() * (CROWN_SIDE[1] - CROWN_SIDE[0]))
      const up = CROWN_SPEED[0] + this.rand() * (CROWN_SPEED[1] - CROWN_SPEED[0])
      const c = this._spawn(p.x + side * p.r, surf - p.r, side * v, -up * v,
        p.m * (0.02 + 0.03 * this.rand()), 0.3, true, em, p.rf)
      if (c) c.surface = surf // above the water: it can fall back in
    }
  }

  _splat(x, y, r) {
    if (this.nSplats >= MAX_SPLATS) return
    const s = this.splats[this.nSplats++]
    s.x = x
    s.y = y
    s.r = r
    s.age = 0
  }

  _stepSplats(dt) {
    let keep = 0
    for (let i = 0; i < this.nSplats; i++) {
      const s = this.splats[i]
      s.age += dt
      if (s.age < SPLAT_S) {
        this.splats[i] = this.splats[keep]
        this.splats[keep++] = s
      }
    }
    this.nSplats = keep
  }

  // How far the bulb has swung sideways (em).
  sway(d) {
    return d.sx
  }

  get busy() {
    return this.nParts > 0 || this.nSplats > 0
  }
}

// Every drip as one teardrop, in pixels: from just inside the letter down to
// its bulb. Returns nothing; the shape is left as the current path.
function traceDrip(cr, sim, d, em) {
  const a = Math.max(NECK * d.rf * em * clamp(Math.sqrt(NECK_REF / Math.max(d.ext, NECK_REF)), NECK_MIN, 1), 0.6)
  const rb = Math.max(bulbR(d.m, d.rf) * em, 1.2)
  const y0 = d.y - 0.07 * em
  const yb = Math.max(d.y, d.y + d.ext * em)
  const bx = d.x + sim.sway(d) * em
  cr.newSubPath()
  cr.moveTo(d.x - a, y0)
  cr.curveTo(d.x - a, yb - rb, bx - rb, yb - rb, bx - rb, yb)
  cr.arcNegative(bx, yb, rb, Math.PI, 0)
  cr.curveTo(bx + rb, yb - rb, d.x + a, yb - rb, d.x + a, y0)
  cr.closePath()
}

// A falling drop: an ellipse squashed by its wobble and stretched along its
// velocity. Leaves cr transformed to the drop's own unit circle (caller saves).
function dropSpace(cr, p, em) {
  const speed = Math.hypot(p.vx, p.vy) / em
  const s = Math.min(STRETCH_MAX, speed * STRETCH)
  const r = Math.max(p.r, 0.8)
  cr.translate(p.x, p.y)
  cr.rotate(speed > 0.01 ? Math.atan2(p.vy, p.vx) - Math.PI / 2 : 0)
  // Mode 2: longer one way, shorter the other, about the same volume.
  cr.scale(r * (1 - p.e * 0.5) / Math.sqrt(1 + s), r * (1 + p.e) * (1 + s))
}

function traceAll(cr, sim, em) {
  for (const d of sim.drips) traceDrip(cr, sim, d, em)
  for (let i = 0; i < sim.nParts; i++) {
    cr.save()
    dropSpace(cr, sim.parts[i], em)
    cr.newSubPath()
    cr.arc(0, 0, 1, 0, 2 * Math.PI)
    cr.restore()
  }
}

// Under the letters: a soft glow in the drip colour, the rim in the water's
// surface colour and a dark keyline, so the letters close over where the
// drips leave them.
// style: { drip, line, foam, rimW, keyW } (colours as [r, g, b], widths px)
export function drawDripsUnder(cr, sim, em, style) {
  const { drip, line, foam } = style
  cr.setLineJoin(Cairo.LineJoin.ROUND)
  traceAll(cr, sim, em)
  for (const [width, a] of GLOW) {
    cr.setLineWidth(width * em)
    cr.setSourceRGBA(drip[0], drip[1], drip[2], a)
    cr.strokePreserve()
  }
  cr.setLineWidth(style.rimW)
  cr.setSourceRGBA(foam[0], foam[1], foam[2], 1)
  cr.strokePreserve()
  cr.setLineWidth(style.keyW)
  cr.setSourceRGBA(line[0], line[1], line[2], 1)
  cr.stroke()
}
const GLOW = [[0.5, 0.1], [0.34, 0.16], [0.22, 0.24]]

// Over the letters: the paint itself, glossy. style also carries
// neck (fill colour into the drip colour, a unit-tall linear gradient) and
// bulb (the gloss, a radial gradient on the unit circle).
export function drawDripsOver(cr, sim, em, style) {
  const { drip, neck, bulb } = style
  const neckH = NECK_BLEND * em
  for (const d of sim.drips) {
    // The thread and bulb, fading from the letter's colour into the drip's.
    traceDrip(cr, sim, d, em)
    cr.save()
    cr.translate(0, d.y)
    cr.scale(1, neckH)
    cr.setSource(neck)
    cr.fill()
    cr.restore()
    // The bulb, glossy.
    const rb = Math.max(bulbR(d.m, d.rf) * em, 1.2)
    if (d.ext * em > rb * 0.5) {
      cr.save()
      cr.translate(d.x + sim.sway(d) * em, Math.max(d.y, d.y + d.ext * em))
      cr.scale(rb, rb)
      gloss(cr, bulb)
      cr.restore()
    }
  }
  for (let i = 0; i < sim.nParts; i++) {
    const p = sim.parts[i]
    if (p.lig > 0 && p.y - p.ly > p.r) {
      // The ligament: a thread tapering to a point where it broke.
      const wd = Math.max(0.5, p.r * LIG_W * p.lig)
      cr.newSubPath()
      cr.moveTo(p.lx, p.ly)
      cr.curveTo(p.lx, (p.ly + p.y) / 2, p.x - wd, p.y - p.r, p.x - wd, p.y)
      cr.lineTo(p.x + wd, p.y)
      cr.curveTo(p.x + wd, p.y - p.r, p.lx, (p.ly + p.y) / 2, p.lx, p.ly)
      cr.closePath()
      cr.setSourceRGBA(drip[0], drip[1], drip[2], 0.5 + 0.5 * p.lig)
      cr.fill()
    }
    cr.save()
    dropSpace(cr, p, em)
    gloss(cr, bulb)
    cr.restore()
  }
  // Splats on a dry floor: a flat puddle spreading out and fading.
  for (let i = 0; i < sim.nSplats; i++) {
    const s = sim.splats[i]
    const t = s.age / SPLAT_S
    cr.save()
    cr.translate(s.x, s.y - 0.5)
    cr.scale(s.r * (1.4 + 1.6 * t), Math.max(0.6, s.r * 0.45 * (1 - 0.5 * t)))
    cr.newSubPath()
    cr.arc(0, 0, 1, Math.PI, 2 * Math.PI)
    cr.restore()
    cr.setSourceRGBA(drip[0], drip[1], drip[2], 1 - t)
    cr.fill()
  }
}
const NECK_BLEND = 0.12 // em of each drip that blends from the letter colour

// In the unit circle of a bulb or drop: the gloss, then a white highlight.
function gloss(cr, bulb) {
  cr.newSubPath()
  cr.arc(0, 0, 1, 0, 2 * Math.PI)
  cr.setSource(bulb)
  cr.fill()
  cr.newSubPath()
  cr.arc(-0.36, -0.42, 0.26, 0, 2 * Math.PI)
  cr.setSourceRGBA(1, 1, 1, 0.85)
  cr.fill()
}

// The gradients for a drip colour, made once per palette.
export function dripGradients(fill, drip) {
  const neck = new Cairo.LinearGradient(0, 0, 0, 1)
  neck.addColorStopRGBA(0, fill[0], fill[1], fill[2], 1)
  neck.addColorStopRGBA(1, drip[0], drip[1], drip[2], 1)
  // Lit from the upper left: lighter there, darker round the lower edge.
  const bulb = new Cairo.RadialGradient(-0.35, -0.4, 0.05, 0, 0, 1)
  const lift = (t) => drip.map((v) => v + (1 - v) * t)
  const sink = (t) => drip.map((v) => v * (1 - t))
  bulb.addColorStopRGBA(0, ...lift(0.55), 1)
  bulb.addColorStopRGBA(0.5, ...drip, 1)
  bulb.addColorStopRGBA(1, ...sink(0.42), 1)
  return { neck, bulb }
}
