// SPDX-License-Identifier: GPL-2.0-or-later
// Water Panel's settings pages. Shared by Water Panel's own preferences and
// Fetelabs Task Bar's (where the water is built in), like water.js.

import Adw from 'gi://Adw'
import Gdk from 'gi://Gdk'
import Gio from 'gi://Gio'
import GLib from 'gi://GLib'
import Gtk from 'gi://Gtk'

const hexOf = (rgba) =>
  '#' + [rgba.red, rgba.green, rgba.blue]
    .map((c) => Math.round(c * 255).toString(16).padStart(2, '0'))
    .join('')
    .toUpperCase()

function rgbaOf(hex) {
  const rgba = new Gdk.RGBA()
  rgba.parse(hex)
  return rgba
}

function colorButton() {
  return new Gtk.ColorDialogButton({
    dialog: new Gtk.ColorDialog({ with_alpha: false }),
    valign: Gtk.Align.CENTER,
  })
}

// Combo row bound to a string (enum) setting.
function choiceRow(settings, key, title, subtitle, choices) {
  const row = new Adw.ComboRow({
    title,
    subtitle,
    model: Gtk.StringList.new(choices.map(([, label]) => label)),
  })
  const sync = () => {
    const i = choices.findIndex(([v]) => v === settings.get_string(key))
    if (i >= 0 && row.selected !== i) row.selected = i
  }
  sync()
  row.connect('notify::selected', () => settings.set_string(key, choices[row.selected][0]))
  watch(settings, `changed::${key}`, sync)
  return row
}

function spinRow(settings, key, title, subtitle, lower, upper, step, digits) {
  const row = new Adw.SpinRow({
    title,
    subtitle,
    digits,
    adjustment: new Gtk.Adjustment({ lower, upper, step_increment: step, page_increment: step * 5 }),
  })
  settings.bind(key, row, 'value', Gio.SettingsBindFlags.DEFAULT)
  return row
}

function switchRow(settings, key, title, subtitle) {
  const row = new Adw.SwitchRow({ title, subtitle })
  settings.bind(key, row, 'active', Gio.SettingsBindFlags.DEFAULT)
  return row
}

// Runs a command and reports whether it succeeded.
function check(argv) {
  return new Promise((resolve) => {
    try {
      const proc = Gio.Subprocess.new(argv,
        Gio.SubprocessFlags.STDOUT_SILENCE | Gio.SubprocessFlags.STDERR_SILENCE)
      proc.wait_check_async(null, (p, res) => {
        try {
          resolve(p.wait_check_finish(res))
        } catch {
          resolve(false)
        }
      })
    } catch {
      resolve(false)
    }
  })
}

// Pages for a preferences window to add. Standalone: Look, Motion and
// Taskbar tabs. builtIn (inside Fetelabs Task Bar): everything on one Water
// tab, without the "needs a taskbar" requirement.
export function waterPages(settings, { builtIn = false } = {}) {
  handlers = []
  const pages = buildPages(settings, builtIn)
  // Settings objects outlive the window (the Extensions app keeps running),
  // so drop every handler on them when the pages go.
  const mine = handlers
  handlers = null
  let dropped = false
  for (const page of pages) {
    page.connect('destroy', () => {
      if (dropped) return
      dropped = true
      mine.forEach(([obj, id]) => obj.disconnect(id))
    })
  }
  return pages
}

// Handlers on settings objects made while building the pages.
let handlers = null
function watch(obj, signal, fn) {
  const id = obj.connect(signal, fn)
  handlers?.push([obj, id])
  return id
}

function buildPages(settings, builtIn) {
  const page = (title, icon_name) => new Adw.PreferencesPage({ title, icon_name })
  if (builtIn) {
    const water = page('Water', 'weather-showers-symbolic')
    lookPage(settings, water)
    motionPage(settings, water)
    taskbarPage(settings, water, true)
    return [water]
  }
  return [
    lookPage(settings, page('Look', 'applications-graphics-symbolic')),
    motionPage(settings, page('Motion', 'media-playlist-shuffle-symbolic')),
    taskbarPage(settings, page('Taskbar', 'view-app-grid-symbolic'), false),
  ]
}

function lookPage(settings, page) {
  // Built into Fetelabs Task Bar: a master switch for the water.
  if (settings.settings_schema.has_key('enabled')) {
    const water = new Adw.PreferencesGroup({ title: 'Water Panel' })
    page.add(water)
    water.add(switchRow(settings, 'enabled', 'Liquid audio visualizer',
      'The taskbar becomes water that moves with whatever is playing'))
  }

  // Colour
  const colour = new Adw.PreferencesGroup({ title: 'Colour' })
  page.add(colour)
  colour.add(choiceRow(settings, 'color-mode', 'Colour source', null, [
    ['wallpaper', 'Match the wallpaper'],
    ['custom', 'Single colour'],
  ]))

  const customRow = new Adw.ActionRow({
    title: 'Single colour',
    subtitle: 'Used in single-colour mode, and for wallpapers with no real colour',
  })
  const customBtn = colorButton()
  customBtn.rgba = rgbaOf(settings.get_string('custom-color'))
  customBtn.connect('notify::rgba', () => {
    const hex = hexOf(customBtn.rgba)
    if (hex !== settings.get_string('custom-color')) settings.set_string('custom-color', hex)
  })
  watch(settings, 'changed::custom-color', () => {
    const hex = settings.get_string('custom-color')
    if (hex !== hexOf(customBtn.rgba)) customBtn.rgba = rgbaOf(hex)
  })
  const resetBtn = new Gtk.Button({
    icon_name: 'edit-undo-symbolic',
    tooltip_text: 'Back to ocean blue',
    valign: Gtk.Align.CENTER,
    css_classes: ['flat'],
  })
  resetBtn.connect('clicked', () => settings.reset('custom-color'))
  customRow.add_suffix(resetBtn)
  customRow.add_suffix(customBtn)
  colour.add(customRow)

  colour.add(pinRow(settings))

  // Shape
  const shape = new Adw.PreferencesGroup({ title: 'Shape' })
  page.add(shape)
  shape.add(choiceRow(settings, 'corner-style', 'Corners', null, [
    ['taskbar', 'Match the taskbar'],
    ['pill', 'Pill'],
    ['custom', 'Custom radius'],
  ]))
  const radius = spinRow(settings, 'corner-radius', 'Corner radius', 'Pixels', 0, 60, 1, 0)
  const syncRadius = () => (radius.sensitive = settings.get_string('corner-style') === 'custom')
  syncRadius()
  watch(settings, 'changed::corner-style', syncRadius)
  shape.add(radius)

  // Liquid
  const liquid = new Adw.PreferencesGroup({ title: 'Liquid' })
  page.add(liquid)
  liquid.add(spinRow(settings, 'wave-height', 'Wave height', 'Tallest wave, as a share of the taskbar height', 0.2, 1, 0.02, 2))
  liquid.add(spinRow(settings, 'opacity', 'Opacity', null, 0.1, 1, 0.05, 2))
  liquid.add(switchRow(settings, 'surface-line', 'Surface line', 'A bright line along the top of the water'))
  liquid.add(switchRow(settings, 'back-wave', 'Back wave', 'A slower wave behind, for depth'))
  liquid.add(switchRow(settings, 'wordmark', 'Fetelabs wordmark',
    'While Spotify plays, the logo shows through the water where waves splash over it'))
  liquid.add(wordmarkTextRow(settings))
  return page
}

// The word before the test tube. Printable ASCII only (the wordmark's font
// has nothing else), at most 12 characters; empty is allowed.
const MAX_WORDMARK_TEXT = 12
function wordmarkTextRow(settings) {
  const row = new Adw.EntryRow({ title: 'Wordmark text (left of the logo)', show_apply_button: true })
  row.get_delegate()?.set_max_length(MAX_WORDMARK_TEXT)
  const clean = (s) => s.replace(/[^\x20-\x7e]/g, '').slice(0, MAX_WORDMARK_TEXT)
  const sync = () => {
    const text = settings.get_string('wordmark-text')
    if (row.text !== text) row.text = text
  }
  sync()
  watch(settings, 'changed::wordmark-text', sync)
  row.connect('apply', () => {
    const text = clean(row.text)
    if (text !== row.text) row.text = text
    settings.set_string('wordmark-text', text)
  })
  // Greyed out while the wordmark is off.
  settings.bind('wordmark', row, 'sensitive', Gio.SettingsBindFlags.GET)
  return row
}
function pinRow(settings) {
  const bg = new Gio.Settings({ schema_id: 'org.gnome.desktop.background' })
  const iface = new Gio.Settings({ schema_id: 'org.gnome.desktop.interface' })
  const row = new Adw.ActionRow({ title: 'Pin a colour to this wallpaper' })
  const btn = colorButton()
  const clear = new Gtk.Button({
    icon_name: 'edit-clear-symbolic',
    tooltip_text: 'Unpin',
    valign: Gtk.Align.CENTER,
    css_classes: ['flat'],
  })
  row.add_suffix(clear)
  row.add_suffix(btn)

  const current = () => {
    const dark = iface.get_string('color-scheme') === 'prefer-dark'
    const uri = bg.get_string(dark ? 'picture-uri-dark' : 'picture-uri')
    const path = uri ? Gio.File.new_for_uri(uri).get_path() : null
    return path ? GLib.path_get_basename(path) : null
  }
  const pins = () => settings.get_value('wallpaper-colors').deepUnpack()
  let syncing = false
  const sync = () => {
    syncing = true
    const name = current()
    const pin = name ? pins()[name] : null
    row.subtitle = name
      ? (pin ? `${name}: pinned` : `${name}: automatic`)
      : 'No wallpaper image'
    row.sensitive = !!name
    clear.sensitive = !!pin
    btn.rgba = rgbaOf(pin ? pin.split(/\s+/)[0] : '#808080')
    syncing = false
  }
  btn.connect('notify::rgba', () => {
    const name = current()
    if (syncing || !name) return
    const all = pins()
    all[name] = hexOf(btn.rgba)
    settings.set_value('wallpaper-colors', new GLib.Variant('a{ss}', all))
  })
  clear.connect('clicked', () => {
    const all = pins()
    delete all[current()]
    settings.set_value('wallpaper-colors', new GLib.Variant('a{ss}', all))
  })
  for (const sig of ['changed::picture-uri', 'changed::picture-uri-dark'])
    watch(bg, sig, sync)
  watch(iface, 'changed::color-scheme', sync)
  watch(settings, 'changed::wallpaper-colors', sync)
  sync()
  return row
}
function motionPage(settings, page) {
  const feel = new Adw.PreferencesGroup({ title: 'Feel' })
  page.add(feel)
  feel.add(spinRow(settings, 'responsiveness', 'Rise', 'How fast the water jumps to a beat', 0.1, 1, 0.05, 2))
  feel.add(spinRow(settings, 'fall-speed', 'Fall', 'How fast it settles back (1 = default)', 0.25, 3, 0.05, 2))
  feel.add(spinRow(settings, 'surface-tension', 'Surface tension', 'How much neighbouring bars pull on each other', 0, 0.5, 0.01, 2))

  const detail = new Adw.PreferencesGroup({
    title: 'Detail',
    description: 'Higher values look smoother but use a little more CPU.',
  })
  page.add(detail)
  detail.add(spinRow(settings, 'bands', 'Bars', 'Frequency bands across the taskbar', 16, 128, 4, 0))
  detail.add(spinRow(settings, 'frame-rate', 'Analysis rate', 'Audio frames per second', 30, 144, 10, 0))
  return page
}
function taskbarPage(settings, page, builtIn) {
  const apps = new Adw.PreferencesGroup({
    title: 'Hidden apps',
    description: 'Keep these apps off the taskbar, e.g. a music player you control from the top bar. ' +
      'Use desktop file IDs separated by commas, like spotify.desktop.',
  })
  page.add(apps)
  const entry = new Adw.EntryRow({ title: 'Desktop file IDs', show_apply_button: true })
  const sync = () => (entry.text = settings.get_strv('hidden-apps').join(', '))
  sync()
  watch(settings, 'changed::hidden-apps', sync)
  entry.connect('apply', () => {
    const ids = entry.text.split(',').map((s) => s.trim()).filter(Boolean)
    settings.set_strv('hidden-apps', ids)
  })
  apps.add(entry)

  const req = new Adw.PreferencesGroup({
    title: 'Requirements',
    description: 'The audio analysis runs in a small Python helper.',
  })
  page.add(req)
  const items = [
    ['Python 3 with NumPy', ['python3', '-c', 'import numpy'], 'Install python3-numpy'],
    ['parec', ['sh', '-c', 'command -v parec'], 'Install pulseaudio-utils (works with PipeWire too)'],
    ['pactl', ['sh', '-c', 'command -v pactl'], 'Install pulseaudio-utils'],
    ...(builtIn ? [] : [['Fetelabs Task Bar, Zorin Taskbar or Dash to Panel', null, null]]),
  ]
  for (const [title, argv, fix] of items) {
    const row = new Adw.ActionRow({ title })
    const icon = new Gtk.Image({ icon_name: 'content-loading-symbolic' })
    row.add_suffix(icon)
    req.add(row)
    if (!argv) {
      row.subtitle = 'One of these extensions must be enabled'
      icon.icon_name = 'dialog-information-symbolic'
      continue
    }
    check(argv).then((ok) => {
      icon.icon_name = ok ? 'emblem-ok-symbolic' : 'dialog-warning-symbolic'
      row.subtitle = ok ? 'Found' : fix
    })
  }
  return page
}
