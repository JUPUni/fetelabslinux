// SPDX-License-Identifier: GPL-2.0-or-later
// The live Fetelabs test tube, the same drawing and motion as the start
// button logo in Fetelabs Menu (menu@fetelabs/widgets/logoDraw.js): no
// outline, the teal, lime and pink liquid sloshing with the music, bubbles
// streaming up through it and popping at the surface, the three bubbles above
// the tube bobbing on bass, mid and treble, and a sway on the kick. The
// wordmark draws it between the custom text and FETELABS, driven by the same
// water levels as the start button, so the two move in step.
//
// Nothing here imports Shell modules, so tools can render it offline.

const hex = (s) => [1, 3, 5].map((i) => parseInt(s.slice(i, i + 2), 16) / 255)
export const LOGO = {
  cream: hex('#fff6e6'),
  glass: hex('#2a1f3d'),
  teal: hex('#1fb5a8'),
  lime: hex('#9be22d'),
  pink: hex('#ff2e88'),
  gold: hex('#f4b400'),
}
const BUBBLE_COLOURS = [LOGO.lime, LOGO.gold, LOGO.teal, LOGO.cream, LOGO.pink]
const BAND_KEYS = ['all', 'bass', 'mid', 'high']

// The tube's ink at rest, tilted, in the logo's own units (the artwork is
// 96 x 203). The bubbles above it bob a little past this box with the music.
export const TUBE_BOX = { x: 48, y: -12, w: 94, h: 202 }
// How far past TUBE_BOX the moving parts can reach, in logo units.
export const TUBE_REACH = 30
const MAX_BUBBLES = 26

export function traceTube(cr) {
  cr.moveTo(70, 38)
  cr.lineTo(70, 160)
  cr.arcNegative(100, 160, 30, Math.PI, 0)
  cr.lineTo(130, 38)
  cr.closePath()
}

// One liquid band: a wave across the tube, filled to the bottom.
function traceWave(cr, y, amp, phase) {
  cr.moveTo(40, 220)
  for (let x = 40; x <= 160; x += 4) cr.lineTo(x, y + Math.sin(x / 28 * Math.PI + phase) * amp)
  cr.lineTo(160, 220)
  cr.closePath()
}

const circle = (cr, x, y, r) => {
  cr.newSubPath()
  cr.arc(x, y, r, 0, 2 * Math.PI)
}

function roundRect(cr, x, y, w, h, r) {
  cr.newSubPath()
  cr.arc(x + w - r, y + r, r, -Math.PI / 2, 0)
  cr.arc(x + w - r, y + h - r, r, 0, Math.PI / 2)
  cr.arc(x + r, y + h - r, r, Math.PI / 2, Math.PI)
  cr.arc(x + r, y + r, r, Math.PI, 1.5 * Math.PI)
  cr.closePath()
}

// rand: a () => [0, 1) source, so offline renders can be repeatable.
export function newLogoState(rand = Math.random) {
  const bubbles = []
  for (let i = 0; i < MAX_BUBBLES; i++) bubbles.push({ x: 0, y: 0, r: 0, vy: 0, wob: 0, c: LOGO.lime })
  return {
    snd: { all: 0, bass: 0, mid: 0, high: 0, kick: 0 },
    raw: { all: 0, bass: 0, mid: 0, high: 0 },
    prevBass: 0, phase: 0, bubbles, live: 0, spawn: 0, t: 0, rand,
  }
}

function surfaceY(st) {
  return 100 - 34 * st.snd.all - 8 * st.snd.kick
}

function avg(lv, a, b) {
  let s = 0
  for (let i = a; i < b; i++) s += lv[i]
  return s / Math.max(1, b - a)
}

// Average the water's band levels into overall, bass, mid and treble.
// Writes into out (reused every frame).
export function bandsOf(lv, out) {
  out.all = out.bass = out.mid = out.high = 0
  if (!lv?.length) return out
  const n = lv.length
  const b1 = Math.max(1, Math.round(n * 0.15))
  const b2 = Math.round(n * 0.5)
  out.all = avg(lv, 0, n)
  out.bass = avg(lv, 0, b1)
  out.mid = avg(lv, b1, b2)
  out.high = avg(lv, b2, n)
  return out
}

// How far a bubble above the tube bobs.
const bob = (st, k, f) => Math.sin(st.t * f + k) * (2 + 8 * st.snd.all)

// One step of motion from the water's levels. Returns true while anything
// is still moving.
export function stepLogo(st, level, dt) {
  if (!(dt > 0)) return true
  const raw = bandsOf(level, st.raw)
  st.t += dt
  const s = st.snd
  for (const k of BAND_KEYS) {
    // Up fast, down slower, like the water itself.
    const tau = raw[k] > s[k] ? 0.04 : 0.25
    s[k] += (raw[k] - s[k]) * (1 - Math.exp(-dt / tau))
  }
  // A kick: the bass jumping up.
  const jump = (raw.bass - st.prevBass) / dt
  st.prevBass = raw.bass
  if (jump > 4 && raw.bass > 0.3) s.kick = 1
  s.kick *= Math.exp(-dt / 0.18)

  // The liquid churns faster the louder it is.
  st.phase += dt * (1.2 + 9 * s.all + 6 * s.bass)

  // Bubbles stream up with the music, and burst out on a kick.
  if (s.all > 0.02) st.spawn += dt * (2 + 40 * s.all ** 1.2)
  if (s.kick > 0.95) st.spawn += 4
  const rand = st.rand
  while (st.spawn >= 1) {
    st.spawn -= 1
    if (st.live >= MAX_BUBBLES) continue
    const b = st.bubbles[st.live++]
    b.r = 2 + rand() * (2.5 + 4 * s.bass)
    b.x = 78 + rand() * 44
    b.y = 180 + rand() * 6
    b.vy = -(40 + 160 * s.all + rand() * 40)
    b.wob = rand() * 6.28
    b.c = BUBBLE_COLOURS[Math.floor(rand() * BUBBLE_COLOURS.length)]
  }
  // Bubbles rise and pop at the surface (the live ones are kept at the front).
  const surface = surfaceY(st)
  let n = 0
  for (let i = 0; i < st.live; i++) {
    const b = st.bubbles[i]
    b.y += b.vy * dt * (1 + 1.5 * s.mid)
    b.wob += dt * (4 + 10 * s.high)
    b.x += Math.sin(b.wob) * dt * 18
    if (b.y > surface - 4) {
      st.bubbles[i] = st.bubbles[n]
      st.bubbles[n++] = b
    }
  }
  st.live = n

  return !(s.all < 0.004 && s.kick < 0.01 && !st.live)
}

const fillWith = (cr, c, a = 1) => {
  cr.setSourceRGBA(c[0], c[1], c[2], a)
  cr.fill()
}

// The logo in its own units, tilted like on the site.
export function drawTube(cr, st) {
  const s = st.snd
  cr.save()
  cr.translate(100, 110)
  // A little sway on the beat.
  cr.rotate((-12 + 4 * s.kick * Math.sin(st.t * 20)) * Math.PI / 180)
  cr.translate(-100, -110)

  // Glass (no outline).
  traceTube(cr)
  fillWith(cr, LOGO.glass)

  cr.save()
  traceTube(cr)
  cr.clip()
  const top = surfaceY(st)
  const amp = 8 + 14 * s.bass + 10 * s.kick
  const ph = st.phase
  traceWave(cr, top, amp, ph)
  fillWith(cr, LOGO.teal)
  traceWave(cr, top + 32 - 10 * s.mid, amp * 0.85, ph * 1.3 + 2)
  fillWith(cr, LOGO.lime)
  traceWave(cr, top + 62 - 12 * s.bass, amp * 0.7, ph * 0.8 + 4)
  fillWith(cr, LOGO.pink)
  // Bubbles rising through it.
  for (let i = 0; i < st.live; i++) {
    const b = st.bubbles[i]
    circle(cr, b.x, b.y, b.r)
    fillWith(cr, b.c, 0.9)
    circle(cr, b.x - b.r * 0.35, b.y - b.r * 0.35, b.r * 0.3)
    fillWith(cr, LOGO.cream, 0.7)
  }
  // The resting bubble from the logo.
  circle(cr, 90, 74 + (100 - top) * 0.3, 5 * (1 + 0.4 * s.mid))
  fillWith(cr, LOGO.lime)
  cr.restore()

  circle(cr, 110, 60, 3.5 * (1 + 0.5 * s.high))
  fillWith(cr, LOGO.gold)
  roundRect(cr, 64, 30, 72, 12, 6)
  fillWith(cr, LOGO.cream)
  cr.setLineWidth(5)
  cr.setLineCap(1) // Cairo.LineCap.ROUND
  cr.moveTo(82, 56)
  cr.lineTo(82, 84)
  cr.moveTo(82, 96)
  cr.lineTo(82, 102)
  cr.setSourceRGBA(LOGO.cream[0], LOGO.cream[1], LOGO.cream[2], 1)
  cr.stroke()

  // The bubbles above the tube bob and swell: bass, mid, treble.
  circle(cr, 94, 18 + bob(st, 0, 5), 6 * (1 + 0.6 * s.bass + 0.4 * s.kick))
  fillWith(cr, LOGO.teal)
  circle(cr, 112 + bob(st, 1, 4) * 0.5, 4 + bob(st, 2, 6) - 6 * s.mid, 4 * (1 + 0.7 * s.mid))
  fillWith(cr, LOGO.pink)
  circle(cr, 100 + bob(st, 3, 3) * 0.5, -10 + bob(st, 4, 7) - 8 * s.high, 3 * (1 + 0.9 * s.high))
  fillWith(cr, LOGO.pink)
  cr.restore()
}

// The tube's shape at rest, glass, cap and the bubbles above, as one path in
// logo units: the static silhouette under the shadow and glow.
export function traceSilhouette(cr) {
  cr.save()
  cr.translate(100, 110)
  cr.rotate(-12 * Math.PI / 180)
  cr.translate(-100, -110)
  traceTube(cr)
  roundRect(cr, 64, 30, 72, 12, 6)
  circle(cr, 94, 18, 6)
  circle(cr, 112, 4, 4)
  circle(cr, 100, -10, 3)
  cr.restore()
}
