// SPDX-License-Identifier: GPL-2.0-or-later
// Sets the wordmark's custom text (the word before the test tube, "JOLA" by
// default) in Rubik Wet Paint at runtime, from the outlines, advances and
// pair kerning in wordmark-font.json (made by tools/wordmark-font.py).
//
// Nothing here imports Shell modules, so tools can render it offline.

import Gio from 'gi://Gio'

export const MAX_TEXT = 12
export const DEFAULT_TEXT = 'JOLA'

let font = null
let lastText = null
let lastSet = null

// Read once, on the first wordmark built with a custom text.
function loadFont() {
  if (font) return font
  const file = Gio.File.new_for_uri(import.meta.url).get_parent().get_child('wordmark-font.json')
  const [, bytes] = file.load_contents(null)
  font = JSON.parse(new TextDecoder().decode(bytes))
  return font
}

// Reads the font and sets text now, so the first frame that shows the mark
// doesn't have to (call from an idle callback).
export function prewarmText(text) {
  setText(text)
}

// Printable ASCII only (the font file has nothing else), at most MAX_TEXT.
export function cleanText(s) {
  return (s ?? '').replace(/[^\x20-\x7e]/g, '').slice(0, MAX_TEXT)
}

// The text as one outline (em units, y down, baseline at 0, starting at
// x = 0), each inked letter's horizontal extent, and the ink's bounds.
// Null when there is nothing to draw.
export function setText(text) {
  text = cleanText(text)
  if (text === lastText) return lastSet
  lastText = text
  lastSet = null
  if (!text.trim()) return null
  const { glyphs, kern, track } = loadFont()
  const path = []
  const letters = []
  let x = 0
  let top = Infinity, bottom = -Infinity
  for (let i = 0; i < text.length; i++) {
    const ch = text[i]
    const g = glyphs[ch] ?? glyphs['?']
    if (g.path) {
      const p = g.path
      for (let k = 0; k < p.length; k++) {
        const v = p[k]
        // Ops are strings; numbers alternate x, y after each op.
        if (typeof v === 'string') {
          path.push(v)
          let n = 0
          for (k++; k < p.length && typeof p[k] === 'number'; k++, n++) path.push(n % 2 ? p[k] : p[k] + x)
          k--
        }
      }
      letters.push([x + g.box[0], x + g.box[2]])
      top = Math.min(top, g.box[1])
      bottom = Math.max(bottom, g.box[3])
    }
    x += g.adv + track + (i + 1 < text.length ? kern[ch + text[i + 1]] ?? 0 : 0)
  }
  if (!letters.length) return null
  lastSet = {
    text,
    path,
    letters,
    box: { top, bottom, left: Math.min(...letters.map(([l]) => l)), right: Math.max(...letters.map(([, r]) => r)) },
  }
  return lastSet
}
