// SPDX-License-Identifier: GPL-2.0-or-later
// The Water Panel engine: turns a taskbar's background (Fetelabs Task Bar,
// Zorin Taskbar or Dash to Panel) into a liquid audio visualizer. analyzer.py
// does the FFT; this file only does physics and drawing, synced to the
// compositor's frame clock.
//
// Shared by two extensions: Water Panel (standalone, for any of those
// taskbars) and Fetelabs Task Bar (built in). The Water Panel repo is the
// source; tools/sync-to-taskbar.sh copies it into the task bar's water/ folder.

import Cairo from 'cairo'
import Clutter from 'gi://Clutter'
import Gio from 'gi://Gio'
import GLib from 'gi://GLib'
import Meta from 'gi://Meta'
import St from 'gi://St'

import * as Main from 'resource:///org/gnome/shell/ui/main.js'

import { PALETTE_KEYS, PaletteCache, copyPalette, paletteFromColor, pinnedPalette } from './palette.js'
import { Liquid } from './physics.js'
import { SpotifyWatch, Wordmark } from './wordmark.js'
import { prewarmText } from './wordText.js'

// The physics (a height field driven by the music) is in physics.js.
const BACK_ALPHA_RATIO = 0.51 // back wave opacity relative to the front
const TRANSPARENT = 'background-color: transparent;'

// Colours fade over the same 1000ms ease-out-quad as GNOME's own wallpaper
// crossfade, starting on the same signal.
const COLOUR_FADE_MS = 1000
const PREWARM_DELAY_S = 20
const IDLE_STOP_MS = 1500

// If the analyzer keeps dying straight away, a dependency is missing: stop
// retrying instead of spawning it forever.
const QUICK_EXIT_S = 5
const MAX_QUICK_EXITS = 5

// Each analyzer process gets a number that is never reused, not even across
// disable/enable (GNOME does that around the lock screen). An exit or a read
// from an older process is then never mistaken for the current one's.
let analyzerSerial = 0

// The taskbar extensions this works with; all expose the same panel API.
export const anyTaskbar = () => global.fetelabsTaskbar ?? global.zorinTaskbar ?? global.dashToPanel

// Settings read on every frame, kept as plain values.
function readConfig(s) {
  return {
    colorMode: s.get_string('color-mode'),
    customColor: s.get_string('custom-color'),
    wallpaperColors: s.get_value('wallpaper-colors').deepUnpack(),
    cornerStyle: s.get_string('corner-style'),
    cornerRadius: s.get_int('corner-radius'),
    waveHeight: s.get_double('wave-height'),
    opacity: s.get_double('opacity'),
    surfaceLine: s.get_boolean('surface-line'),
    backWave: s.get_boolean('back-wave'),
    responsiveness: s.get_double('responsiveness'),
    fallSpeed: s.get_double('fall-speed'),
    surfaceTension: s.get_double('surface-tension'),
    frameRate: s.get_int('frame-rate'),
    bands: s.get_int('bands'),
    hiddenApps: s.get_strv('hidden-apps'),
    wordmark: s.get_boolean('wordmark'),
    wordmarkText: s.get_string('wordmark-text'),
  }
}


function parseRgba(css) {
  const m = /rgba?\(([^)]+)\)/.exec(css || '')
  if (!m) return [0, 0, 0, 0]
  const p = m[1].split(',').map(Number)
  return [p[0] / 255, p[1] / 255, p[2] / 255, p.length > 3 ? p[3] : 1]
}

// Smooth curve through the band points (Catmull-Rom as cubic Béziers).
function tracePath(cr, pts) {
  cr.moveTo(pts[0][0], pts[0][1])
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[Math.max(0, i - 1)]
    const p1 = pts[i]
    const p2 = pts[i + 1]
    const p3 = pts[Math.min(pts.length - 1, i + 2)]
    cr.curveTo(
      p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6,
      p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6,
      p2[0], p2[1],
    )
  }
}

function roundedRect(cr, w, h, r) {
  r = Math.min(r, h / 2, w / 2)
  if (r <= 0) {
    cr.rectangle(0, 0, w, h)
    return
  }
  cr.newSubPath()
  cr.arc(w - r, r, r, -Math.PI / 2, 0)
  cr.arc(w - r, h - r, r, 0, Math.PI / 2)
  cr.arc(r, h - r, r, Math.PI / 2, Math.PI)
  cr.arc(r, r, r, Math.PI, 1.5 * Math.PI)
  cr.closePath()
}

const scaleFactor = () => St.ThemeContext.get_for_stage(global.stage).scale_factor

// Corner radius the taskbar itself has: from its theme node, or from the brN
// class Zorin puts on uiGroup for its "global border radius" setting.
function panelRadius(panel) {
  const r = panel.get_stage() ? panel.get_theme_node().get_border_radius(St.Corner.TOPLEFT) : 0
  if (r) return r
  const m = /(?:^|\s)br(\d+)(?:\s|$)/.exec(Main.layoutManager.uiGroup.get_style_class_name() ?? '')
  return m ? +m[1] * scaleFactor() : 0
}

// Paints the liquid behind one taskbar panel. The taskbar's own background is
// made transparent and its colour is drawn here instead, under the water.
class PanelSkin {
  // primary: the first bar. Only its drops push the shared water, so two
  // monitors don't land every drop twice. The engine moves it to the next
  // bar if this one goes.
  constructor(panel, liquid, cfg, onPanelDestroyed, primary) {
    this.primary = primary
    this.panel = panel
    this.liquid = liquid
    this.cfg = cfg
    this.bg = [0, 0, 0, 0.8]
    this.wordmark = new Wordmark()
    // What the wordmark needs each frame (one object, refilled).
    this._markEnv = {
      splash: null, colors: null, timeS: 0, level: null, waveHeight: 1, text: '',
      impact: (i, dv) => {
        if (this.primary) this.liquid?.impulse(i, dv)
      },
    }

    this.area = new St.DrawingArea({ reactive: false })
    this._areaIds = [
      this.area.connect('repaint', (a) => this._repaint(a)),
      this.area.connect('destroy', () => {
        this._areaDestroyed = true
        this._areaIds = []
      }),
    ]
    panel.clipContainer.insert_child_below(this.area, panel.panelBox)

    // The taskbar settles its final position only after GNOME's startup
    // animation, and moves again whenever its margins or size change.
    this._syncLater = 0
    this._actorIds = [
      [panel, panel.connect('notify::allocation', () => this._queueSync())],
      [panel.panelBox, panel.panelBox.connect('notify::allocation', () => this._queueSync())],
      [panel, panel.connect('destroy', () => onPanelDestroyed(this))],
    ]
    this._queueSync()

    this._takeOverBackground()
    this._hideApps()
  }

  _takeOverBackground() {
    const dt = this.panel.dynamicTransparency
    const skin = this
    this._dt = dt
    this._origSetBackground = dt._setBackground
    // Work out the colour the taskbar wants but never apply it: the original
    // sets it with a 300ms transition, so clearing it afterwards flashed the bar.
    // Once this skin is gone the wrapper just passes through, in case another
    // wrapper was stacked on top of it and still calls it.
    const orig = this._origSetBackground
    this._wrapper = dt._setBackground = function () {
      if (skin._gone) return orig.call(this)
      const c = this.backgroundColorRgb
      const a = Math.max(0, Math.floor(this.alpha * 100) / 100)
      this.currentBackgroundColor = a > 0 ? `rgba(${c.red},${c.green},${c.blue},${a}); ` : 'transparent; '
      skin.bg = parseRgba(this.currentBackgroundColor)
      if (skin.panel.get_style() !== TRANSPARENT) skin.panel.set_style(TRANSPARENT)
      skin.area.queue_repaint()
    }
    dt._setBackground()
  }

  _hideApps() {
    const tb = this.panel.taskbar
    const orig = tb.getAppInfos
    const cfg = this.cfg
    this._taskbar = tb
    this._origGetAppInfos = orig
    const skin = this
    this._appsWrapper = tb.getAppInfos = function () {
      const infos = orig.call(this)
      if (skin._gone) return infos
      return cfg.hiddenApps.length ? infos.filter((info) => !cfg.hiddenApps.includes(info.app?.get_id())) : infos
    }
    tb._redisplay()
  }

  refreshApps() {
    this._taskbar._redisplay()
  }

  repaint() {
    this.area.queue_repaint()
  }

  _queueSync() {
    if (this._syncLater) return
    this._syncLater = global.compositor.get_laters().add(Meta.LaterType.BEFORE_REDRAW, () => {
      this._syncLater = 0
      this._syncGeometry()
      return GLib.SOURCE_REMOVE
    })
  }

  _syncGeometry() {
    const { panel, area } = this
    // Read allocation boxes, not .x/.y: while the taskbar still needs a relayout
    // those return 0, which left the background 16px left and 12px up (the
    // panel margin) until something else moved it. get_allocation_box() settles
    // the layout first.
    const box = panel.panelBox.get_allocation_box()
    const bar = panel.get_allocation_box()
    const x = box.x1 + bar.x1
    const y = box.y1 + bar.y1
    const [w, h] = [bar.get_width(), bar.get_height()]
    if (area.x !== x || area.y !== y) area.set_position(x, y)
    if (area.width !== w || area.height !== h) area.set_size(w, h)
  }

  _radius() {
    switch (this.cfg.cornerStyle) {
    case 'pill':
      return Infinity
    case 'custom':
      return this.cfg.cornerRadius * scaleFactor()
    default:
      return panelRadius(this.panel)
    }
  }

  _repaint(area) {
    const cr = area.get_context()
    // Always let go of the context, even if drawing throws.
    try {
      const [w, h] = area.get_surface_size()
      const { level, back, colors, bands } = this.liquid
      const { waveHeight, opacity, surfaceLine, backWave } = this.cfg

      roundedRect(cr, w, h, this._radius())
      cr.clip()

      cr.setSourceRGBA(...this.bg)
      cr.paint()

      const step = w / (bands - 1)
      const surfaceOf = (vals) => {
        const pts = []
        for (let i = 0; i < bands; i++)
          pts.push([i * step, h - vals[i] * h * waveHeight])
        return pts
      }
      const traceWater = (pts) => {
        tracePath(cr, pts)
        cr.lineTo(w, h)
        cr.lineTo(0, h)
        cr.closePath()
      }
      const front = surfaceOf(level)

      const layer = (pts, alpha) => {
        traceWater(pts)
        const g = new Cairo.LinearGradient(0, h, 0, h * (1 - waveHeight))
        g.addColorStopRGBA(0, ...colors.deep, alpha)
        g.addColorStopRGBA(1, ...colors.shallow, Math.min(1, alpha * 1.25))
        cr.setSource(g)
        cr.fill()
      }

      if (backWave) layer(surfaceOf(back), opacity * BACK_ALPHA_RATIO)
      layer(front, opacity)
      // The wordmark sits in the water, under the surface line, and shows whole
      // when a wave hits it.
      if (this.cfg.wordmark) {
        const env = this._markEnv
        env.splash = this.liquid.splash
        env.colors = colors
        env.timeS = GLib.get_monotonic_time() / 1e6
        env.level = level
        env.waveHeight = waveHeight
        env.text = this.cfg.wordmarkText
        this.wordmark.draw(cr, w, h, env)
      }
      if (surfaceLine && front.some(([, y]) => y < h - 0.01 * h)) {
        tracePath(cr, front)
        cr.setLineWidth(1.6 * scaleFactor())
        cr.setSourceRGBA(...colors.foam, 0.85)
        cr.stroke()
      }
    } finally {
      cr.$dispose()
    }
  }

  // orphan: the taskbar destroyed or dropped this panel (it was turned off),
  // so its objects are not ours to touch any more.
  destroy(orphan = false) {
    // From here on both wrappers pass straight through to the taskbar's own code.
    this._gone = true
    if (this._syncLater) {
      global.compositor.get_laters().remove(this._syncLater)
      this._syncLater = 0
    }
    this._actorIds.forEach(([actor, id]) => actor.disconnect(id))
    this._actorIds = []
    if (!orphan) {
      // Only unhook if nothing has wrapped on top since; otherwise the wrapper
      // stays in the chain and passes straight through (_gone).
      if (this._dt._setBackground === this._wrapper) this._dt._setBackground = this._origSetBackground
      this._dt._setBackground()
      if (this._taskbar.getAppInfos === this._appsWrapper) this._taskbar.getAppInfos = this._origGetAppInfos
      this._taskbar._redisplay()
    }
    this.wordmark.destroy()
    // A destroyed panel has already taken the area (its child) with it.
    if (!this._areaDestroyed) {
      this._areaIds.forEach((id) => this.area.disconnect(id))
      this._areaIds = []
      this.area.destroy()
    }
    this.area = null
  }
}

// One running visualizer.
//   settings  Gio.Settings with the Water Panel keys
//   dir       folder holding analyzer.py
//   host      () => the taskbar's global object (panels + 'panels-created')
//   standalone  the Water Panel extension: steps aside while Fetelabs Task Bar
//               runs its own built-in water, so it is never drawn twice
export class WaterEngine {
  constructor({ settings, dir, host = anyTaskbar, standalone = false }) {
    this._settingsIn = settings
    this._dir = dir
    this._hostOf = host
    this._standalone = standalone
  }

  enable() {
    this._settings = this._settingsIn
    this._cfg = readConfig(this._settings)
    this._settingsId = this._settings.connect('changed', (_s, key) => this._onSetting(key))

    this._liquid = new Liquid(this._cfg.bands, this._cfg)
    this._skins = []
    this._cancel = new Gio.Cancellable()
    this._buf = new Uint8Array(0)
    this._running = false
    this._quickExits = 0

    this._attachWhenReady()
    // The taskbar makes a new global object each time it is turned on; follow
    // whichever one is current, or the water would stay off after a toggle.
    this._hostPollId = GLib.timeout_add_seconds(GLib.PRIORITY_LOW, 2, () => {
      // (?? null: no taskbar reads as undefined, an unwatched one as null.)
      if ((this._hostOf() ?? null) !== (this._host ?? null)) this._hostReplaced()
      return GLib.SOURCE_CONTINUE
    })
    this._watchWallpaper()
    this._spotify = new SpotifyWatch((playing) => {
      if (this._liquid) this._liquid.spotify = playing
    })
    this._prewarmText()
  }

  _onSetting(key) {
    Object.assign(this._cfg, readConfig(this._settings))
    switch (key) {
    case 'bands':
      this._liquid.resize(this._cfg.bands)
      this._restartAnalyzer()
      break
    case 'frame-rate':
      this._restartAnalyzer()
      break
    case 'color-mode':
    case 'custom-color':
    case 'wallpaper-colors':
      this._updatePalette()
      break
    case 'hidden-apps':
      this._skins.forEach((s) => s.refreshApps())
      break
    case 'wordmark':
      this._liquid.splash.clear()
      if (!this._cfg.wordmark) this._skins.forEach((s) => s.wordmark.release())
      else this._prewarmText()
      break
    case 'wordmark-text':
      // The wordmark rebuilds its masks for the new text on the next frame;
      // set the text first, off the frame path.
      this._prewarmText()
      break
    }
    this._repaintAll()
  }

  // Reads the wordmark's font and sets its text in an idle moment, not in
  // the middle of the frame that first shows the mark.
  _prewarmText() {
    if (this._prewarmTextId || !this._cfg.wordmark) return
    this._prewarmTextId = GLib.idle_add(GLib.PRIORITY_LOW, () => {
      this._prewarmTextId = 0
      try {
        prewarmText(this._cfg.wordmarkText)
      } catch (e) {
        console.error(`Water Panel: cannot read the wordmark font: ${e}`)
      }
      return GLib.SOURCE_REMOVE
    })
  }

  _repaintAll() {
    this._skins.forEach((s) => s.repaint())
  }

  _watchWallpaper() {
    this._palettes = new PaletteCache(this._cancel)
    this._bgSettings = new Gio.Settings({ schema_id: 'org.gnome.desktop.background' })
    this._ifaceSettings = new Gio.Settings({ schema_id: 'org.gnome.desktop.interface' })
    // A settings change only starts working out the colour; the fade itself
    // waits for GNOME to finish loading the new image and start its crossfade.
    const onSetting = () => {
      // The new image loads asynchronously, so there is still time to catch
      // its 'changed' if the manager being watched has been replaced.
      if (!this._watchingLiveManager()) this._watchBgManagers()
      const path = this._wallpaperPath()
      if (path && this._skins.length) this._palettes.get(path)
      if (!this._bgWatched.length) this._updatePalette()
    }
    this._bgIds = ['changed::picture-uri', 'changed::picture-uri-dark'].map((sig) =>
      this._bgSettings.connect(sig, onSetting))
    this._ifaceId = this._ifaceSettings.connect('changed::color-scheme', onSetting)

    this._bgWatched = []
    this._watchBgManagers()
    // Background managers are rebuilt when monitors change, and once more
    // during the login animation without any monitors-changed signal.
    this._layoutIds = ['monitors-changed', 'startup-prepared', 'startup-complete'].map((sig) =>
      Main.layoutManager.connect(sig, () => {
        this._watchBgManagers()
        this._updatePalette()
      }))
    this._updatePalette()

    this._prewarmId = GLib.timeout_add_seconds(GLib.PRIORITY_LOW, PREWARM_DELAY_S, () => {
      this._prewarmId = 0
      const path = this._wallpaperPath()
      if (path && !this._yielding()) this._palettes.prewarm(GLib.path_get_dirname(path))
      return GLib.SOURCE_REMOVE
    })
  }

  _watchBgManagers() {
    this._unwatchBgManagers()
    const mgr = Main.layoutManager._bgManagers?.[Main.layoutManager.primaryIndex] ??
      Main.layoutManager._bgManagers?.[0]
    if (!mgr) return
    this._bgWatched = [[mgr, mgr.connect('changed', () => this._updatePalette())]]
  }

  _watchingLiveManager() {
    const mgr = this._bgWatched[0]?.[0]
    return !!mgr && !!Main.layoutManager._bgManagers?.includes(mgr)
  }

  _unwatchBgManagers() {
    this._bgWatched.forEach(([mgr, id]) => mgr.disconnect(id))
    this._bgWatched = []
  }

  _wallpaperPath() {
    const dark = this._ifaceSettings.get_string('color-scheme') === 'prefer-dark'
    const uri = this._bgSettings.get_string(dark ? 'picture-uri-dark' : 'picture-uri')
    const path = uri ? Gio.File.new_for_uri(uri).get_path() : null
    // Slideshow .xml wallpapers and missing files use the single colour.
    return path && !path.endsWith('.xml') ? path : null
  }

  async _palette() {
    const { colorMode, customColor, wallpaperColors } = this._cfg
    const fallback = paletteFromColor(customColor)
    if (colorMode === 'custom') return fallback
    const path = this._wallpaperPath()
    if (!path) return fallback
    const auto = await this._palettes.get(path)
    if (!auto) return null // cancelled: shutting down
    const pinned = wallpaperColors[GLib.path_get_basename(path)]
    if (pinned) return pinnedPalette(pinned, auto)
    return auto.grey ? fallback : auto
  }

  async _updatePalette() {
    // Standing aside for the task bar's own water: no image work until needed
    // (_attach catches up when this takes over again).
    if (!this._skins.length) {
      this._paletteStale = true
      return
    }
    this._paletteStale = false
    const token = (this._paletteToken = (this._paletteToken ?? 0) + 1)
    let palette
    try {
      palette = await this._palette()
    } catch (e) {
      console.error(`Water Panel: cannot work out colours: ${e}\n${e?.stack}`)
      return
    }
    // A newer wallpaper or setting arrived while this one was loading.
    if (!palette || token !== this._paletteToken || !this._liquid) return
    this._fadeTo(palette)
  }

  _fadeTo(palette) {
    const colors = this._liquid.colors
    const from = copyPalette(colors)
    const start = GLib.get_monotonic_time()
    if (this._fadeId) GLib.source_remove(this._fadeId)
    this._fadeId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 16, () => {
      const t = Math.min(1, (GLib.get_monotonic_time() - start) / 1000 / COLOUR_FADE_MS)
      const e = 1 - (1 - t) * (1 - t) // ease-out-quad, same as GNOME's wallpaper fade
      for (const k of PALETTE_KEYS) {
        const to = palette[k] ?? from[k]
        for (let c = 0; c < 3; c++) colors[k][c] = from[k][c] + (to[c] - from[k][c]) * e
      }
      this._repaintAll()
      if (t < 1) return GLib.SOURCE_CONTINUE
      this._fadeId = 0
      return GLib.SOURCE_REMOVE
    })
  }

  // Watch the current taskbar (if any) and draw on its panels. With no
  // taskbar yet, the host poll in enable() calls this again when one appears.
  _attachWhenReady() {
    const host = this._hostOf()
    if (!host) return
    if (!this._hostId) {
      this._host = host
      // The taskbar rebuilds its panels when its settings change. The signal
      // fires in the middle of the taskbar's own enable(), before it can build
      // app icons, so attach once it has finished. Attaching there directly
      // knocked the taskbar into an error state.
      this._hostId = host.connect('panels-created', () => this._attachSoon())
      // Fetelabs Task Bar's built-in water switching on or off.
      // Stepping aside happens at once, before the task bar's water hooks in.
      if (this._standalone) {
        this._hostWaterId = host.connect('water-changed', () => {
          if (this._yielding()) this._attach()
          else this._attachSoon()
        })
      }
    }
    if (host.panels?.length) this._attach()
  }

  _attachSoon() {
    if (this._attachId) return
    this._attachId = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
      this._attachId = 0
      this._attach()
      return GLib.SOURCE_REMOVE
    })
  }

  // True while the standalone extension should leave the bar to the task
  // bar's own built-in water.
  _yielding() {
    return this._standalone && !!this._hostOf()?.builtInWater
  }

  _attach() {
    if (!this._liquid) return
    const host = this._hostOf()
    // A new taskbar object (it was turned off and on): watch that one instead.
    if (host !== this._host) {
      this._hostReplaced()
      return
    }
    this._releaseSkins(false)
    this._skins = this._yielding() ? [] : (host?.panels ?? [])
      .filter((p) => p.clipContainer && p.dynamicTransparency)
      .map((p, i) => new PanelSkin(p, this._liquid, this._cfg, (skin) => this._dropSkin(skin), i === 0))

    // The analyzer only runs while there is a bar to draw on.
    if (!this._skins.length) {
      this._stopAnalyzer()
      return
    }
    if (!this._proc && !this._restartId) {
      this._quickExits = 0
      this._startAnalyzer()
    }
    if (this._paletteStale) this._updatePalette()
    this._startTimeline()
  }

  // The frame clock lives on the first skin's area.
  _startTimeline() {
    this._timeline = new Clutter.Timeline({
      actor: this._skins[0].area,
      duration: 1000,
      repeat_count: -1,
    })
    this._frameId = this._timeline.connect('new-frame', () => this._frame())
    this._lastFrame = 0
    // Pause the moment the bar leaves the screen (the taskbar being turned off
    // detaches it): a running timeline off the stage makes Clutter complain.
    this._mapArea = this._skins[0].area
    this._mapId = this._mapArea.connect('notify::mapped', (a) => {
      if (!a.mapped) this._sleep()
    })
  }

  _sleep() {
    this._timeline?.stop()
    this._running = false
    this._lastFrame = 0
  }

  _dropSkin(skin) {
    // The timeline runs on the first skin's area: move it before that goes.
    const ownsClock = skin.area && skin.area === this._mapArea
    if (ownsClock) {
      // A destroyed area has already dropped its handlers; don't touch it.
      if (skin._areaDestroyed) this._mapId = 0
      this._dropTimeline()
      this._running = false
    }
    skin.destroy(true)
    this._skins = this._skins.filter((s) => s !== skin)
    // The next bar's drops push the water now.
    if (this._skins.length) this._skins[0].primary = true
    if (!this._skins.length) {
      this._dropTimeline()
      this._stopAnalyzer()
    } else if (ownsClock) {
      this._startTimeline()
      this._wake()
    }
  }

  // Drop the skins on the current panels. orphan: the taskbar that owned them
  // is gone, so leave its objects alone.
  _releaseSkins(orphan) {
    this._dropTimeline()
    this._running = false
    this._skins.forEach((s) => s.destroy(orphan))
    this._skins = []
  }

  // The taskbar was turned off, or off and on (a new global object).
  _hostReplaced() {
    this._releaseSkins(true)
    this._unwatchHost()
    if (this._hostOf()) this._attachWhenReady()
    else this._stopAnalyzer()
  }

  _unwatchHost() {
    if (this._host) {
      delete this._host.waterLevels
      delete this._host.waterColors
    }
    if (this._hostId) this._host?.disconnect(this._hostId)
    if (this._hostWaterId) this._host?.disconnect(this._hostWaterId)
    this._hostId = this._hostWaterId = 0
    this._host = null
  }

  _dropTimeline() {
    if (this._mapId) this._mapArea.disconnect(this._mapId)
    this._mapId = 0
    this._mapArea = null
    if (!this._timeline) return
    this._timeline.stop()
    this._timeline.disconnect(this._frameId)
    this._frameId = 0
    this._timeline = null
  }

  _frame() {
    const now = GLib.get_monotonic_time() / 1000
    const dt = this._lastFrame ? Math.min(0.05, (now - this._lastFrame) / 1000) : 1 / 60
    this._lastFrame = now
    const moving = this._liquid.step(dt)
    this._repaintAll()
    // Share the levels with the Fetelabs Menu logo, whose bubbles follow the water.
    if (this._host) {
      this._host.waterLevels = this._liquid.level
      this._host.waterColors = this._liquid.colors
      this._host.emit('water-frame')
    }
    if (!moving && now - this._liquid.lastAudio > IDLE_STOP_MS) this._sleep()
  }

  _wake() {
    // Not until the bar is on screen: a timeline on an actor off the stage has
    // no frame clock (Clutter warns). The next audio frame tries again.
    if (!this._running && this._timeline && this._skins[0]?.area?.mapped) {
      this._running = true
      this._timeline.start()
    }
  }

  _startAnalyzer() {
    const cancel = this._cancel
    if (cancel.is_cancelled()) return
    const gen = this._analyzerGen = ++analyzerSerial
    this._buf = new Uint8Array(0)
    const launcher = new Gio.SubprocessLauncher({ flags: Gio.SubprocessFlags.STDOUT_PIPE })
    launcher.setenv('LT_BANDS', String(this._cfg.bands), true)
    launcher.setenv('LT_FPS', String(this._cfg.frameRate), true)
    let proc
    try {
      proc = launcher.spawnv(['python3', GLib.build_filenamev([this._dir, 'analyzer.py'])])
    } catch (e) {
      console.error(`Water Panel: cannot start analyzer: ${e}`)
      return
    }
    this._proc = proc
    const started = GLib.get_monotonic_time()
    this._read(proc.get_stdout_pipe(), gen, cancel)
    // Checks use this run's own cancellable: by the time an old process's
    // exit arrives, enable() may already have made a new one.
    proc.wait_async(cancel, () => {
      if (cancel.is_cancelled() || gen !== this._analyzerGen) return
      // Analyzer died (not by us). Dying straight away again and again means
      // python3, numpy or parec is missing, so give up after a few tries.
      const ranFor = (GLib.get_monotonic_time() - started) / 1e6
      this._quickExits = ranFor < QUICK_EXIT_S ? this._quickExits + 1 : 0
      if (this._quickExits >= MAX_QUICK_EXITS) {
        console.warn('Water Panel: the audio analyzer keeps exiting. ' +
          'Check that python3, python3-numpy and parec (pulseaudio-utils) are installed.')
        return
      }
      this._restartId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 2, () => {
        this._restartId = 0
        this._startAnalyzer()
        return GLib.SOURCE_REMOVE
      })
    })
  }

  _stopAnalyzer() {
    if (this._restartId) GLib.source_remove(this._restartId)
    this._restartId = 0
    this._analyzerGen = ++analyzerSerial // the old process's exit is no longer ours to handle
    this._proc?.force_exit()
    this._proc = null
  }

  _restartAnalyzer() {
    this._stopAnalyzer()
    if (!this._skins.length) return // starts again when there is a bar
    this._quickExits = 0
    this._startAnalyzer()
  }

  _read(stream, gen, cancel) {
    stream.read_bytes_async(4096, GLib.PRIORITY_HIGH, cancel, (s, res) => {
      let bytes
      try {
        bytes = s.read_bytes_finish(res)
      } catch {
        return
      }
      if (!bytes || bytes.get_size() === 0 || gen !== this._analyzerGen) return
      this._consume(bytes.toArray())
      this._read(stream, gen, cancel)
    })
  }

  _consume(chunk) {
    const bands = this._liquid.bands
    const buf = new Uint8Array(this._buf.length + chunk.length)
    buf.set(this._buf)
    buf.set(chunk, this._buf.length)

    // Use the newest complete frame; frames start with 0xFF.
    let latest = -1
    let i = 0
    while (i + bands < buf.length) {
      if (buf[i] === 0xff) {
        latest = i
        i += bands + 1
      } else {
        i++
      }
    }
    if (latest >= 0) {
      this._liquid.setFrame(buf.subarray(latest + 1, latest + 1 + bands))
      this._wake()
    }
    this._buf = buf.slice(i)
  }

  disable() {
    this._spotify?.destroy()
    this._spotify = null
    this._cancel.cancel()
    this._stopAnalyzer()
    if (this._hostPollId) GLib.source_remove(this._hostPollId)
    this._hostPollId = 0
    if (this._fadeId) GLib.source_remove(this._fadeId)
    this._fadeId = 0
    if (this._attachId) GLib.source_remove(this._attachId)
    this._attachId = 0
    if (this._prewarmTextId) GLib.source_remove(this._prewarmTextId)
    this._prewarmTextId = 0
    this._bgIds.forEach((id) => this._bgSettings.disconnect(id))
    this._ifaceSettings.disconnect(this._ifaceId)
    this._unwatchBgManagers()
    this._layoutIds.forEach((id) => Main.layoutManager.disconnect(id))
    this._layoutIds = []
    if (this._prewarmId) GLib.source_remove(this._prewarmId)
    this._prewarmId = 0
    this._palettes?.destroy()
    this._palettes = null
    this._bgSettings = null
    this._ifaceSettings = null
    // Skins on a taskbar that has since gone (or been replaced) are orphans.
    this._releaseSkins((this._hostOf() ?? null) !== (this._host ?? null))
    this._unwatchHost()
    this._liquid = null
    this._settings.disconnect(this._settingsId)
    this._settings = null
    this._cfg = null
  }

  destroy() {
    this._settingsIn = null
  }
}
