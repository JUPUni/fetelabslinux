// SPDX-License-Identifier: GPL-2.0-or-later
// Fetelabs Player: media controls built into the task bar. It follows the
// media apps listed in the settings (MPRIS players), stays in the bar even
// when none is running (press play to start the first one), can start
// playing at login with the app's window kept out of the way, and answers on
// D-Bus as ai.fetelabs.TaskbarPlayer so voice assistants and scripts can
// drive the same player the bar shows.

import Clutter from 'gi://Clutter'
import Gio from 'gi://Gio'
import GLib from 'gi://GLib'
import GObject from 'gi://GObject'
import Pango from 'gi://Pango'
import Shell from 'gi://Shell'
import St from 'gi://St'

import * as Main from 'resource:///org/gnome/shell/ui/main.js'
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js'
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js'
import * as Slider from 'resource:///org/gnome/shell/ui/slider.js'
import { EventEmitter } from 'resource:///org/gnome/shell/misc/signals.js'

import { H as SPLASH_H, PaintSim } from './splash.js'

const MPRIS_PREFIX = 'org.mpris.MediaPlayer2.'
const MPRIS_PATH = '/org/mpris/MediaPlayer2'
const PLAYER_IFACE = 'org.mpris.MediaPlayer2.Player'
const SERVICE_NAME = 'ai.fetelabs.TaskbarPlayer'
const SERVICE_PATH = '/ai/fetelabs/TaskbarPlayer'
const STATUS_AREA_ID = 'fetelabs-player'

const ROOT_XML = `<node><interface name="org.mpris.MediaPlayer2">
  <method name="Raise"/>
  <property name="CanRaise" type="b" access="read"/>
  <property name="Identity" type="s" access="read"/>
  <property name="DesktopEntry" type="s" access="read"/>
</interface></node>`

const PLAYER_XML = `<node><interface name="org.mpris.MediaPlayer2.Player">
  <method name="PlayPause"/>
  <method name="Play"/>
  <method name="Pause"/>
  <method name="Next"/>
  <method name="Previous"/>
  <method name="OpenUri"><arg type="s" direction="in"/></method>
  <method name="SetPosition"><arg type="o" direction="in"/><arg type="x" direction="in"/></method>
  <signal name="Seeked"><arg type="x"/></signal>
  <property name="PlaybackStatus" type="s" access="read"/>
  <property name="LoopStatus" type="s" access="readwrite"/>
  <property name="Shuffle" type="b" access="readwrite"/>
  <property name="Metadata" type="a{sv}" access="read"/>
  <property name="CanGoNext" type="b" access="read"/>
  <property name="CanGoPrevious" type="b" access="read"/>
  <property name="CanPlay" type="b" access="read"/>
  <property name="CanSeek" type="b" access="read"/>
</interface></node>`

const SERVICE_XML = `<node><interface name="${SERVICE_NAME}">
  <method name="PlayPause"><arg type="b" direction="out"/></method>
  <method name="Play"><arg type="b" direction="out"/></method>
  <method name="Pause"><arg type="b" direction="out"/></method>
  <method name="Next"><arg type="b" direction="out"/></method>
  <method name="Previous"><arg type="b" direction="out"/></method>
  <method name="PlayDefault"><arg type="b" direction="out"/></method>
  <method name="PlayUri">
    <arg type="s" direction="in" name="uri"/>
    <arg type="b" direction="in" name="shuffle"/>
    <arg type="b" direction="out"/>
  </method>
  <method name="Status">
    <arg type="s" direction="out" name="status"/>
    <arg type="s" direction="out" name="title"/>
    <arg type="s" direction="out" name="artist"/>
    <arg type="s" direction="out" name="app"/>
  </method>
</interface></node>`

const RootProxy = Gio.DBusProxy.makeProxyWrapper(ROOT_XML)
const PlayerProxy = Gio.DBusProxy.makeProxyWrapper(PLAYER_XML)

const makeProxy = (Wrapper, name) => new Promise((resolve, reject) => {
  Wrapper(Gio.DBus.session, name, MPRIS_PATH, (proxy, error) => (error ? reject(error) : resolve(proxy)),
    null, Gio.DBusProxyFlags.GET_INVALIDATED_PROPERTIES)
})

const ignore = () => {}

// "3:07" from microseconds.
function clock(us) {
  const s = Math.max(0, Math.floor(us / 1e6))
  const h = Math.floor(s / 3600)
  const m = Math.floor(s / 60) % 60
  const ss = String(s % 60).padStart(2, '0')
  return h ? `${h}:${String(m).padStart(2, '0')}:${ss}` : `${m}:${ss}`
}

// The app behind a media ID or desktop entry, if it is installed.
export function lookupApp(...ids) {
  const sys = Shell.AppSystem.get_default()
  for (const id of ids.filter(Boolean)) {
    const app = sys.lookup_app(`${id}.desktop`) ?? sys.lookup_desktop_wmclass(id)
    if (app) return app
  }
  return null
}

// Spotify links and URIs as a spotify: URI; anything else as it is.
export function normaliseUri(s) {
  s = (s ?? '').trim()
  const m = /open\.spotify\.com\/(?:intl-[\w-]+\/)?(track|album|artist|playlist|show|episode)\/([A-Za-z0-9]{22})/.exec(s)
  return m ? `spotify:${m[1]}:${m[2]}` : s
}

// The signed-in Spotify user's Liked Songs, read from the desktop app's own
// folder (no web API or login needed).
function spotifyLikedUri() {
  const home = GLib.get_home_dir()
  for (const dir of [
    GLib.build_filenamev([GLib.get_user_config_dir(), 'spotify', 'Users']),
    GLib.build_filenamev([home, '.var', 'app', 'com.spotify.Client', 'config', 'spotify', 'Users']),
    GLib.build_filenamev([home, 'snap', 'spotify', 'current', '.config', 'spotify', 'Users']),
  ]) {
    try {
      const en = Gio.File.new_for_path(dir).enumerate_children('standard::name', Gio.FileQueryInfoFlags.NONE, null)
      let info
      while ((info = en.next_file(null))) {
        const name = info.get_name()
        if (name.endsWith('-user')) return `spotify:user:${name.slice(0, -5)}:collection`
      }
    } catch {}
  }
  return null
}

// ------------------------------------------------------------------ MPRIS

class Player extends EventEmitter {
  constructor(busName) {
    super()
    this.busName = busName
    this.id = busName.slice(MPRIS_PREFIX.length).split('.')[0].toLowerCase()
    this.ready = false
    this.lastActive = 0
    this._init().catch(ignore)
  }

  async _init() {
    const [root, player] = await Promise.all([makeProxy(RootProxy, this.busName), makeProxy(PlayerProxy, this.busName)])
    if (this._closed) return
    this._root = root
    this._player = player
    this._propsId = player.connect('g-properties-changed', () => this._changed())
    this._seekedId = player.connectSignal('Seeked', () => this.emit('seeked'))
    this.ready = true
    this._changed()
  }

  _changed() {
    if (this.status === 'Playing') this.lastActive = GLib.get_monotonic_time()
    this.emit('changed')
  }

  _meta(key) {
    try {
      return this._player?.Metadata?.[key]?.recursiveUnpack()
    } catch {
      return undefined
    }
  }

  get status() {
    return this._player?.PlaybackStatus || 'Stopped'
  }

  get title() {
    return this._meta('xesam:title') || ''
  }

  get artist() {
    const a = this._meta('xesam:artist')
    return Array.isArray(a) ? a.join(', ') : a || ''
  }

  get album() {
    return this._meta('xesam:album') || ''
  }

  get artUrl() {
    return this._meta('mpris:artUrl') || ''
  }

  get length() {
    return Number(this._meta('mpris:length') || 0)
  }

  get trackId() {
    return this._meta('mpris:trackid') || ''
  }

  get canNext() {
    return !!this._player?.CanGoNext
  }

  get canPrevious() {
    return !!this._player?.CanGoPrevious
  }

  get canPlay() {
    return !!this._player?.CanPlay
  }

  get canSeek() {
    return !!this._player?.CanSeek && this.length > 0
  }

  get shuffle() {
    return !!this._player?.Shuffle
  }

  get loop() {
    return this._player?.LoopStatus || 'None'
  }

  get identity() {
    return this._root?.Identity || this.id
  }

  get desktopEntry() {
    return this._root?.DesktopEntry || ''
  }

  get app() {
    return lookupApp(this.desktopEntry, this.id)
  }

  // Whether this player belongs to one of the listed media apps.
  matches(apps) {
    const entry = this.desktopEntry.toLowerCase()
    return apps.some((a) => a === this.id || (entry && (a === entry || entry.endsWith(`.${a}`))))
  }

  _call(method, ...args) {
    this._player?.[`${method}Async`]?.(...args).catch(ignore)
  }

  playPause() {
    this._call('PlayPause')
  }

  play() {
    this._call('Play')
  }

  pause() {
    this._call('Pause')
  }

  next() {
    this._call('Next')
  }

  previous() {
    this._call('Previous')
  }

  openUri(uri) {
    this._call('OpenUri', uri)
  }

  setPosition(us) {
    if (this.trackId) this._call('SetPosition', this.trackId, Math.round(us))
  }

  set shuffle(on) {
    if (this._player) this._player.Shuffle = on
  }

  set loop(mode) {
    if (this._player) this._player.LoopStatus = mode
  }

  raise() {
    this._root?.RaiseAsync().catch(ignore)
  }

  // Position is never announced, so it is asked for.
  position() {
    return new Promise((resolve) => {
      Gio.DBus.session.call(this.busName, MPRIS_PATH, 'org.freedesktop.DBus.Properties', 'Get',
        new GLib.Variant('(ss)', [PLAYER_IFACE, 'Position']), null, Gio.DBusCallFlags.NONE, 1000, null,
        (bus, res) => {
          try {
            resolve(Number(bus.call_finish(res).recursiveUnpack()[0]))
          } catch {
            resolve(0)
          }
        })
    })
  }

  destroy() {
    this._closed = true
    if (this._propsId) this._player.disconnect(this._propsId)
    if (this._seekedId) this._player.disconnectSignal(this._seekedId)
    this._player = this._root = null
    this.ready = false
  }
}

// Every MPRIS player on the session bus.
class PlayerWatch extends EventEmitter {
  constructor() {
    super()
    this.players = new Map()
    this._cancel = new Gio.Cancellable()
    this._sub = Gio.DBus.session.signal_subscribe('org.freedesktop.DBus', 'org.freedesktop.DBus',
      'NameOwnerChanged', '/org/freedesktop/DBus', null, Gio.DBusSignalFlags.NONE,
      (_c, _s, _p, _i, _n, params) => {
        const [name, oldOwner, newOwner] = params.deepUnpack()
        if (!name.startsWith(MPRIS_PREFIX)) return
        if (oldOwner) this._remove(name)
        if (newOwner) this._add(name)
      })
    Gio.DBus.session.call('org.freedesktop.DBus', '/org/freedesktop/DBus', 'org.freedesktop.DBus', 'ListNames',
      null, null, Gio.DBusCallFlags.NONE, 2000, this._cancel, (bus, res) => {
        try {
          for (const n of bus.call_finish(res).deepUnpack()[0]) if (n.startsWith(MPRIS_PREFIX)) this._add(n)
        } catch {}
      })
  }

  _add(name) {
    if (this.players.has(name)) return
    const p = new Player(name)
    p.connect('changed', () => this.emit('changed'))
    this.players.set(name, p)
  }

  _remove(name) {
    const p = this.players.get(name)
    if (!p) return
    this.players.delete(name)
    p.destroy()
    this.emit('changed')
  }

  // The one to show: whichever listed app played most recently, else the
  // first running one in the list's order.
  pick(apps) {
    const list = [...this.players.values()].filter((p) => p.ready && p.matches(apps))
    const rank = (p) => apps.findIndex((a) => p.matches([a]))
    list.sort((a, b) => (b.lastActive - a.lastActive) || (rank(a) - rank(b)))
    return list[0] ?? null
  }

  destroy() {
    this._cancel.cancel()
    Gio.DBus.session.signal_unsubscribe(this._sub)
    for (const p of this.players.values()) p.destroy()
    this.players.clear()
  }
}

// ------------------------------------------------------------------ album art

const artDir = () => GLib.build_filenamev([GLib.get_user_cache_dir(), 'fetelabs-taskbar', 'art'])

// A local path for the cover, downloading (once) when it is on the web.
function fetchArt(url, cancellable) {
  return new Promise((resolve) => {
    if (url.startsWith('file://')) {
      resolve(Gio.File.new_for_uri(url).get_path())
      return
    }
    if (!/^https?:\/\//.test(url)) {
      resolve(null)
      return
    }
    const path = GLib.build_filenamev([artDir(), GLib.compute_checksum_for_string(GLib.ChecksumType.MD5, url, -1)])
    const dest = Gio.File.new_for_path(path)
    if (dest.query_exists(null)) {
      resolve(path)
      return
    }
    Gio.File.new_for_uri(url).load_contents_async(cancellable, (src, res) => {
      let data
      try {
        // GJS 1.80 returns [ok, bytes, etag]. [0] is the boolean `true`,
        // and feeding that to GLib.Bytes threw, so the cover was never saved.
        const result = src.load_contents_finish(res)
        data = result.find((part) => part instanceof Uint8Array)
      } catch (e) {
        if (!e.matches?.(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED))
          console.error(`Fetelabs Task Bar: album art: ${e}`)
        resolve(null)
        return
      }
      if (!data?.length) {
        resolve(null)
        return
      }
      GLib.mkdir_with_parents(artDir(), 0o755)
      dest.replace_contents_bytes_async(new GLib.Bytes(data), null, false, Gio.FileCreateFlags.NONE, null,
        (f, r) => {
          try {
            f.replace_contents_finish(r)
            resolve(path)
          } catch (e) {
            console.error(`Fetelabs Task Bar: album art: ${e}`)
            resolve(null)
          }
        })
    })
  })
}

// Keeps the art cache from growing without end: past 400 covers, clear it.
function pruneArt() {
  const dir = Gio.File.new_for_path(artDir())
  dir.enumerate_children_async('standard::name', Gio.FileQueryInfoFlags.NONE, GLib.PRIORITY_LOW, null, (d, res) => {
    let en
    try {
      en = d.enumerate_children_finish(res)
    } catch {
      return
    }
    en.next_files_async(1000, GLib.PRIORITY_LOW, null, (e, r) => {
      let infos = []
      try {
        infos = e.next_files_finish(r)
      } catch {}
      if (infos.length > 400) for (const i of infos) dir.get_child(i.get_name()).delete_async(GLib.PRIORITY_LOW, null, ignore)
    })
  })
}

// ------------------------------------------------------------------ panel button

// While the popup is open the controls in the bar step aside for a paint
// splash that plays to the vocals (splash.js), in a tile that glows with the
// music the same way the start button's does.
const STALE_MS = 250 // no water frame for this long: no spectrum to listen to
const EXIT_MS = 650 // the paint gets at most this long to drain away

const SplashArea = GObject.registerClass(
class SplashArea extends St.DrawingArea {
  _init(tile) {
    super._init({ x_expand: true, y_expand: true, opacity: 0, visible: false, reactive: false })
    this._tile = tile
    this._sim = new PaintSim()
    this._lastWater = 0
    this._last = 0
    this.connect('repaint', () => {
      const cr = this.get_context()
      const [w, h] = this.get_surface_size()
      const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor
      this._sim.draw(cr, w, h, 10 * scale)
      cr.$dispose()
    })
    this._timeline = new Clutter.Timeline({ actor: this, duration: 1000, repeat_count: -1 })
    this._timeline.connect('new-frame', () => this._frame())
    this.connect('destroy', () => this._onDestroy())
  }

  get active() {
    return this.visible && !this._sim.exiting
  }

  set playing(on) {
    this._sim.playing = on
  }

  start() {
    this._clearExit()
    this.remove_all_transitions()
    this.visible = true
    this.reactive = true // clicks land here (and toggle the menu), not on the hidden buttons
    this._watchHost()
    this._sim.setColors(this._host?.waterColors)
    // Size the paint to the tile before the first throw (not drawn yet).
    const [w, h] = this._tile.get_size()
    if (w > 0 && h > 0) this._sim.resize((w / h) * SPLASH_H)
    this._sim.intro()
    this._last = 0
    this._timeline.start()
    this.ease({ opacity: 255, duration: 140, delay: 70, mode: Clutter.AnimationMode.EASE_OUT_QUAD })
  }

  // Drains the paint, then calls done (once).
  stop(done) {
    if (this._destroyed || !this.visible) return done()
    if (this._exitId) {
      // Already draining: run this one too when it ends.
      const prev = this._exitDone
      this._exitDone = () => (prev?.(), done())
      return
    }
    this.reactive = false
    this._sim.exit()
    this._exitDone = done
    this._exitId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, EXIT_MS, () => {
      this._exitId = 0
      this._finishExit()
      return GLib.SOURCE_REMOVE
    })
    if (!this._timeline.is_playing()) this._finishExit()
  }

  _finishExit() {
    const done = this._exitDone
    this._clearExit()
    this.ease({
      opacity: 0, duration: 120, mode: Clutter.AnimationMode.EASE_OUT_QUAD,
      onStopped: () => {
        if (this._destroyed || !this._sim.exiting) return // gone, or opened again meanwhile
        this._timeline.stop()
        this.visible = false
        this._unwatchHost()
        this._styleTile(true)
      },
    })
    done?.()
  }

  _clearExit() {
    if (this._exitId) GLib.source_remove(this._exitId)
    this._exitId = 0
    this._exitDone = null
  }

  _watchHost() {
    const host = global.fetelabsTaskbar ?? null
    if (host === this._host) return
    this._unwatchHost()
    this._host = host
    if (host?.connect) this._hostId = host.connect('water-frame', () => (this._lastWater = GLib.get_monotonic_time() / 1000))
  }

  _unwatchHost() {
    if (this._hostId) {
      try {
        this._host?.disconnect(this._hostId)
      } catch {}
    }
    this._hostId = 0
    this._host = null
  }

  _frame() {
    const now = GLib.get_monotonic_time() / 1000
    const dt = this._last ? Math.min(0.05, Math.max(0, (now - this._last) / 1000)) : 1 / 60
    this._last = now
    const raw = now - this._lastWater < STALE_MS ? this._host?.waterRaw ?? this._host?.waterLevels : null
    if (this._host?.waterColors) this._sim.setColors(this._host.waterColors)
    const hear = this._sim.listen(raw, dt)
    const engine = !!(this._host?.waterRaw ?? this._host?.waterLevels)
    this._sim.step(dt, this._sim.playing ? hear : null, engine)
    this.queue_repaint()
    this._styleTile()
    if (this._exitId && this._sim.done) this._finishExit()
  }

  // The tile's border takes the water's surface colour and glows with the
  // music, exactly like the start button's (Fetelabs Menu, logoIcon.js).
  // Only colour and shadow change, never sizes, so nothing in the bar moves.
  _styleTile(rest = false) {
    const tile = this._tile
    if (rest) {
      this._tileKey = null
      tile.set_style(null)
      return
    }
    const swell = this._sim.exiting ? 0 : Math.round(this._sim.swell * 8) / 8
    const key = Math.round(swell * 8)
    if (key === this._tileKey) return
    const now = GLib.get_monotonic_time() / 1000
    if (now - (this._tileAt ?? 0) < 80) return
    this._tileAt = now
    this._tileKey = key
    const base = 'background-color: rgba(128,128,128,0.13); '
    if (!key) {
      tile.set_style(base + 'border-color: rgba(128,128,128,0.16);')
      return
    }
    const [r, g, b] = (this._host?.waterColors?.foam ?? [1, 0.96, 0.9]).map((v) => Math.round(v * 255))
    const a = (0.25 + 0.75 * swell).toFixed(2)
    const glow = (0.6 * swell).toFixed(2)
    tile.set_style(base + `border-color: rgba(${r},${g},${b},${a}); ` +
      `box-shadow: 0 0 ${Math.round(2 + 10 * swell)}px rgba(${r},${g},${b},${glow});`)
  }

  _onDestroy() {
    this._destroyed = true
    this._clearExit()
    this._unwatchHost()
    this._timeline?.stop()
    this._timeline = null
  }
})

const iconButton = (icon, style, fn) => {
  const b = new St.Button({
    style_class: style,
    can_focus: true,
    y_align: Clutter.ActorAlign.CENTER,
    child: new St.Icon({ icon_name: icon }),
  })
  b.connect('clicked', fn)
  return b
}

const PlayerButton = GObject.registerClass(
class PlayerButton extends PanelMenu.Button {
  _init(ctl) {
    super._init(0.5, 'Fetelabs Player', false)
    this._ctl = ctl
    this.add_style_class_name('fetelabs-player-button')

    // The tile holds the controls and, on top, the splash that replaces them.
    this._tile = new St.Widget({ style_class: 'fetelabs-player-tile', layout_manager: new Clutter.BinLayout(), y_align: Clutter.ActorAlign.CENTER })
    this.add_child(this._tile)
    const box = new St.BoxLayout({ style_class: 'fetelabs-player', y_align: Clutter.ActorAlign.CENTER })
    this._box = box
    this._tile.add_child(box)
    this._splash = new SplashArea(this._tile)
    this._tile.add_child(this._splash)
    this._appIcon = new St.Icon({ style_class: 'fetelabs-player-app', y_align: Clutter.ActorAlign.CENTER })
    box.add_child(this._appIcon)
    this._prev = iconButton('media-skip-backward-symbolic', 'fetelabs-player-control', () => ctl.previous())
    this._play = iconButton('media-playback-start-symbolic', 'fetelabs-player-control', () => ctl.playPause())
    this._next = iconButton('media-skip-forward-symbolic', 'fetelabs-player-control', () => ctl.next())
    for (const b of [this._prev, this._play, this._next]) {
      b.child.add_style_class_name('system-status-icon')
      box.add_child(b)
    }

    this._artUrl = null
    this._artCancel = null
    this._buildMenu()
  }

  _buildMenu() {
    this.menu.box.add_style_class_name('fetelabs-player-menu')

    // The cover is the card: a locked square with the title laid over a fade.
    const head = new PopupMenu.PopupBaseMenuItem({ reactive: false, can_focus: false, style_class: 'fetelabs-player-item' })
    const stack = new St.Widget({ style_class: 'fetelabs-player-cover', layout_manager: new Clutter.BinLayout(), x_align: Clutter.ActorAlign.CENTER })
    this._art = new St.Bin({ style_class: 'fetelabs-player-art', x_expand: true, y_expand: true })
    this._artIcon = new St.Icon({ icon_name: 'audio-x-generic-symbolic', icon_size: 64, opacity: 120 })
    this._art.set_child(this._artIcon)
    const text = new St.BoxLayout({
      style_class: 'fetelabs-player-caption', vertical: true,
      x_expand: true, y_expand: true, y_align: Clutter.ActorAlign.END,
    })
    const label = (style) => {
      const l = new St.Label({ style_class: style, x_expand: true })
      l.clutter_text.ellipsize = Pango.EllipsizeMode.END
      text.add_child(l)
      return l
    }
    this._title = label('fetelabs-player-title')
    this._artist = label('fetelabs-player-artist')
    stack.add_child(this._art)
    stack.add_child(text)
    head.add_child(stack)
    this.menu.addMenuItem(head)

    // Progress: a slider to seek with, elapsed and length underneath.
    this._progress = new PopupMenu.PopupBaseMenuItem({ reactive: false, can_focus: false, style_class: 'fetelabs-player-item' })
    const bar = new St.BoxLayout({ style_class: 'fetelabs-player-progress', vertical: true, x_expand: true })
    this._slider = new Slider.Slider(0)
    this._slider.x_expand = true
    this._slider.add_style_class_name('fetelabs-player-slider')
    const times = new St.BoxLayout({ x_expand: true })
    this._elapsed = new St.Label({ style_class: 'fetelabs-player-time', x_expand: true })
    this._total = new St.Label({ style_class: 'fetelabs-player-time' })
    times.add_child(this._elapsed)
    times.add_child(this._total)
    bar.add_child(this._slider)
    bar.add_child(times)
    this._progress.add_child(bar)
    this.menu.addMenuItem(this._progress)
    this._sliderSetting = false
    this._slider.connect('drag-begin', () => (this._dragging = true))
    this._slider.connect('drag-end', () => {
      this._dragging = false
      this._seek()
    })
    this._slider.connect('notify::value', () => {
      if (!this._sliderSetting && !this._dragging) this._seek()
    })

    const controls = new PopupMenu.PopupBaseMenuItem({ reactive: false, can_focus: false, style_class: 'fetelabs-player-item' })
    this._controls = controls
    const cbox = new St.BoxLayout({ style_class: 'fetelabs-player-controls', x_expand: true, x_align: Clutter.ActorAlign.CENTER })
    this._shuffle = iconButton('media-playlist-shuffle-symbolic', 'fetelabs-player-toggle', () => this._ctl.toggleShuffle())
    this._mPrev = iconButton('media-skip-backward-symbolic', 'fetelabs-player-menu-control', () => this._ctl.previous())
    this._mPlay = iconButton('media-playback-start-symbolic', 'fetelabs-player-menu-control fetelabs-player-big', () => this._ctl.playPause())
    this._mNext = iconButton('media-skip-forward-symbolic', 'fetelabs-player-menu-control', () => this._ctl.next())
    this._loop = iconButton('media-playlist-repeat-symbolic', 'fetelabs-player-toggle', () => this._ctl.cycleLoop())
    for (const b of [this._shuffle, this._mPrev, this._mPlay, this._mNext, this._loop]) cbox.add_child(b)
    controls.add_child(cbox)
    this.menu.addMenuItem(controls)

    // A quiet footer instead of full-width menu rows.
    const footer = new PopupMenu.PopupBaseMenuItem({ reactive: false, can_focus: false, style_class: 'fetelabs-player-item' })
    const fbox = new St.BoxLayout({ style_class: 'fetelabs-player-footer', x_expand: true, x_align: Clutter.ActorAlign.CENTER })
    const link = (fn) => {
      const b = new St.Button({ style_class: 'fetelabs-player-link', can_focus: true })
      b.connect('clicked', () => {
        this.menu.close()
        fn()
      })
      fbox.add_child(b)
      return b
    }
    this._startItem = link(() => this._ctl.playDefault())
    this._openItem = link(() => this._ctl.raise())
    footer.add_child(fbox)
    this.menu.addMenuItem(footer)

    this.menu.connect('open-state-changed', (_m, open) => {
      if (open) this._tick()
      else this._stopTick()
      this._morph(open)
    })
  }

  // The app icon and the controls shrink away one after another and the
  // paint splashes in; on closing the paint drains and they pop back.
  _morph(open) {
    if (this._gone) return
    const parts = [this._appIcon, this._prev, this._play, this._next]
    if (open) {
      // With animations off the bar just stays as it is.
      if (!St.Settings.get().enable_animations) return
      this._box.remove_all_transitions()
      this._box.ease({ opacity: 0, duration: 200, mode: Clutter.AnimationMode.EASE_IN_QUAD })
      parts.forEach((a, i) => {
        a.set_pivot_point(0.5, 0.5)
        a.remove_all_transitions()
        a.ease({ scale_x: 0.2, scale_y: 0.2, translation_y: -3, duration: 190, delay: i * 30, mode: Clutter.AnimationMode.EASE_IN_BACK })
      })
      this._splash.start()
      return
    }
    this._splash.stop(() => {
      if (this.menu.isOpen) return
      this._box.remove_all_transitions()
      this._box.ease({ opacity: 255, duration: 220, mode: Clutter.AnimationMode.EASE_OUT_QUAD })
      parts.forEach((a, i) => {
        a.remove_all_transitions()
        a.ease({ scale_x: 1, scale_y: 1, translation_y: 0, duration: 340, delay: 40 + (parts.length - 1 - i) * 45, mode: Clutter.AnimationMode.EASE_OUT_BACK })
      })
    })
  }

  vfunc_event(event) {
    const type = event.type()
    if (type === Clutter.EventType.BUTTON_PRESS) {
      // Double click brings the app up; middle click plays and pauses.
      if (event.get_button() === 1 && event.get_click_count?.() === 2) {
        this.menu.close()
        this._ctl.raise()
        return Clutter.EVENT_STOP
      }
      if (event.get_button() === 2) {
        this._ctl.playPause()
        return Clutter.EVENT_STOP
      }
    }
    return super.vfunc_event(event)
  }

  update(p, idle) {
    const app = p ? p.app : idle.app
    this._appIcon.gicon = app?.get_icon() ?? Gio.ThemedIcon.new('multimedia-player-symbolic')
    this._appIcon.opacity = p ? 255 : 150

    const playing = p?.status === 'Playing'
    const playIcon = playing ? 'media-playback-pause-symbolic' : 'media-playback-start-symbolic'
    this._play.child.icon_name = this._mPlay.child.icon_name = playIcon
    for (const [b, on] of [[this._prev, p?.canPrevious], [this._next, p?.canNext], [this._mPrev, p?.canPrevious], [this._mNext, p?.canNext]]) {
      b.reactive = !!on
      b.opacity = on ? 255 : 110
    }

    if (p) {
      this._title.text = p.title || p.identity
      this._artist.text = p.artist
      this._artist.visible = !!p.artist
      this._shuffle.checked = p.shuffle
      this._loop.checked = p.loop !== 'None'
      this._loop.child.icon_name = p.loop === 'Track' ? 'media-playlist-repeat-song-symbolic' : 'media-playlist-repeat-symbolic'
      this._setArt(p.artUrl)
    } else {
      this._title.text = idle.name
      this._artist.text = idle.hint
      this._artist.visible = true
      this._setArt('')
    }
    this._progress.visible = !!p?.canSeek
    this._shuffle.visible = this._loop.visible = !!p
    this._startItem.label = idle.startLabel
    this._startItem.visible = !!idle.startLabel
    this._openItem.label = `Open ${p ? p.identity : idle.name}`
    this._openItem.visible = !!(p || idle.app)
    this._player = p
    this._splash.playing = playing
    if (this.menu.isOpen) this._tick(true)
  }

  _setArt(url) {
    if (url === this._artUrl) return
    this._artUrl = url
    this._artCancel?.cancel()
    this._artCancel = null
    this._art.style = null
    this._artIcon.show()
    if (!url) return
    const cancel = (this._artCancel = new Gio.Cancellable())
    fetchArt(url, cancel).then((path) => {
      if (!path || cancel.is_cancelled() || url !== this._artUrl) return
      this._art.style = `background-image: url("${path.replace(/"/g, '\\"')}");`
      this._artIcon.hide()
    })
  }

  _seek() {
    const p = this._player
    if (p?.canSeek) p.setPosition(this._slider.value * p.length)
  }

  // While the menu is open, the progress follows the track once a second.
  _tick(once = false) {
    const p = this._player
    if (p?.canSeek) {
      p.position().then((pos) => {
        if (this._player !== p || this._dragging) return
        this._sliderSetting = true
        this._slider.value = Math.min(1, pos / p.length)
        this._sliderSetting = false
        this._elapsed.text = clock(pos)
        this._total.text = clock(p.length)
      })
    }
    if (once || this._tickId) return
    this._tickId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 1, () => {
      this._tick(true)
      return GLib.SOURCE_CONTINUE
    })
  }

  _stopTick() {
    if (this._tickId) GLib.Source.remove(this._tickId)
    this._tickId = 0
  }

  _onDestroy() {
    this._gone = true
    this._stopTick()
    this._artCancel?.cancel()
    super._onDestroy()
  }
})

// ------------------------------------------------------------------ keeping a window out of the way

// Minimises the app's windows while it starts up (and when opening a track
// pops it back up), so playing at login never puts a window in your face.
class WindowHider {
  constructor(id) {
    const esc = id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
    this._match = new RegExp(esc, 'i')
    this._until = 0
  }

  start(ms) {
    this._until = Math.max(this._until, GLib.get_monotonic_time() + ms * 1000)
    if (!this._createdId) this._createdId = global.display.connect('window-created', (_d, w) => this._hide(w))
    if (!this._tickId) {
      this._tickId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 100, () => {
        for (const a of global.get_window_actors()) this._hide(a.meta_window)
        if (GLib.get_monotonic_time() < this._until) return GLib.SOURCE_CONTINUE
        this._tickId = 0
        this.stop()
        return GLib.SOURCE_REMOVE
      })
    }
  }

  _hide(win) {
    if (!win || win.minimized || !win.can_minimize()) return
    if (this._match.test(`${win.get_wm_class() ?? ''} ${win.get_wm_class_instance() ?? ''}`)) win.minimize()
  }

  stop() {
    if (this._createdId) global.display.disconnect(this._createdId)
    if (this._tickId) GLib.Source.remove(this._tickId)
    this._createdId = this._tickId = 0
  }
}

// ------------------------------------------------------------------ the player

export class FetelabsPlayer {
  constructor(settings) {
    this._settings = settings
    this._timers = new Set()
  }

  enable() {
    this._watch = new PlayerWatch()
    this._watch.connect('changed', () => this._sync())
    this._settingsId = this._settings.connect('changed', (_s, key) => {
      if (key.startsWith('player-')) this._syncSettings()
    })
    this._syncSettings()
    this._export()
    pruneArt()
    this._autoplayAtLogin()
  }

  get apps() {
    return this._settings.get_strv('player-apps').map((a) => a.trim().toLowerCase()).filter(Boolean)
  }

  get player() {
    return this._watch?.pick(this.apps) ?? null
  }

  // What the bar shows while none of the apps is running.
  _idle() {
    const id = this.apps[0]
    const app = id ? lookupApp(id) : null
    const name = app?.get_name() ?? id ?? 'Media'
    const uri = this._defaultUri(id)
    const startLabel = uri?.includes(':collection') ? 'Play Liked Songs' : uri ? `Play in ${name}` : ''
    return {
      app,
      name,
      hint: id ? (startLabel ? `Not running · press play for ${startLabel.slice(5)}` : 'Not running · press play to start it') : 'No media apps in the settings',
      startLabel,
    }
  }

  _defaultUri(id = this.apps[0]) {
    const custom = normaliseUri(this._settings.get_string('player-autoplay-uri'))
    if (custom) return custom
    return id === 'spotify' ? spotifyLikedUri() : null
  }

  _sync() {
    this._button?.update(this.player, this._idle())
  }

  _syncSettings() {
    const on = this._settings.get_boolean('player-enabled')
    if (on && !this._button) {
      this._button = new PlayerButton(this)
      Main.panel.addToStatusArea(STATUS_AREA_ID, this._button, 0, 'left')
    } else if (!on && this._button) {
      this._button.destroy()
      this._button = null
    }
    this._hideMediaCard(on && this._settings.get_boolean('player-hide-notification'))
    this._sync()
  }

  // The calendar's own media card, which would repeat the player.
  _hideMediaCard(hide) {
    const section = Main.panel.statusArea.dateMenu?._messageList?._mediaSection
    if (!section || hide === !!this._cardHidden) return
    this._cardHidden = hide
    if (hide) section._shouldShow = () => false
    else delete section._shouldShow
    section._sync?.()
  }

  // ---- controls (the bar, the menu and D-Bus all come through here)

  playPause() {
    const p = this.player
    if (p) p.playPause()
    else this.playDefault()
  }

  play() {
    const p = this.player
    if (p) p.play()
    else this.playDefault()
  }

  pause() {
    this.player?.pause()
  }

  next() {
    this.player?.next()
  }

  previous() {
    this.player?.previous()
  }

  toggleShuffle() {
    const p = this.player
    if (p) p.shuffle = !p.shuffle
  }

  cycleLoop() {
    const p = this.player
    if (p) p.loop = { None: 'Playlist', Playlist: 'Track', Track: 'None' }[p.loop] ?? 'None'
  }

  raise() {
    const p = this.player
    const app = p?.app ?? lookupApp(this.apps[0])
    if (app) app.activate()
    else p?.raise()
  }

  // Starts the first media app and plays its default (Liked Songs for Spotify).
  playDefault() {
    return this.playUri(this._defaultUri(), this._settings.get_boolean('player-autoplay-shuffle'))
  }

  // One run at a time; a second request while starting up waits for it.
  playUri(uri, shuffle) {
    this._busy ??= this._playUri(normaliseUri(uri), shuffle).catch((e) => {
      console.error(`Fetelabs Task Bar: player could not start: ${e}`)
      return false
    }).finally(() => (this._busy = null))
    return this._busy
  }

  async _playUri(uri, shuffle) {
    const id = uri?.startsWith('spotify:') ? 'spotify' : this.apps[0]
    if (!id) return false
    // Only a window this starts is kept out of the way; one you opened stays.
    let p = this._find(id)
    let hider = null
    if (!p) {
      if (this._settings.get_boolean('player-hide-window')) {
        hider = this._hider ??= new WindowHider(id)
        hider.start(20000)
      }
      this._launch(id)
      p = await this._until(() => this._find(id), 45000)
    }
    if (!p || !(await this._until(() => p.canPlay && p, 30000))) return false
    if (!uri) {
      p.play()
      return true
    }
    // Spotify restores its last session right after it can play, and drops a
    // track sent too early; so wait, send it, and check it took.
    await this._sleep(1500)
    if (shuffle !== null) p.shuffle = shuffle
    for (let attempt = 0; attempt < 4; attempt++) {
      const before = p.trackId
      p.openUri(uri)
      const took = await this._until(() => p.status === 'Playing' && (attempt > 0 || p.trackId !== before), 4000)
      if (took) break
    }
    if (shuffle !== null) p.shuffle = shuffle
    if (p.status !== 'Playing') p.play()
    hider?.start(8000) // opening a track likes to bring the window back
    return p.status === 'Playing'
  }

  _find(id) {
    return this._watch ? [...this._watch.players.values()].find((p) => p.ready && p.matches([id])) ?? null : null
  }

  _launch(id) {
    const app = lookupApp(id)
    try {
      if (app) app.get_app_info().launch([], global.create_app_launch_context(0, -1))
      else Gio.Subprocess.new([id], Gio.SubprocessFlags.NONE)
    } catch (e) {
      console.error(`Fetelabs Task Bar: could not start ${id}: ${e}`)
    }
  }

  _sleep(ms) {
    return new Promise((resolve) => {
      const tid = GLib.timeout_add(GLib.PRIORITY_DEFAULT, ms, () => {
        this._timers.delete(tid)
        resolve()
        return GLib.SOURCE_REMOVE
      })
      this._timers.add(tid)
    })
  }

  // Polls fn every 250 ms until it gives something truthy or time runs out.
  async _until(fn, ms) {
    for (let t = 0; t <= ms; t += 250) {
      if (!this._watch) return null
      const v = fn()
      if (v) return v
      await this._sleep(250)
    }
    return null
  }

  // Once per login (not on every turn off and on): start playing if asked to.
  _autoplayAtLogin() {
    if (!this._settings.get_boolean('player-autoplay') || !this._settings.get_boolean('player-enabled')) return
    const file = GLib.build_filenamev([GLib.get_user_runtime_dir(), 'fetelabs-taskbar-autoplay'])
    const pid = String(new Gio.Credentials().get_unix_pid())
    try {
      if (new TextDecoder().decode(GLib.file_get_contents(file)[1]) === pid) return
    } catch {}
    try {
      GLib.file_set_contents(file, pid)
    } catch {}
    // Give already-running players a moment to show up first.
    this._sleep(3000).then(() => {
      if (this._watch && this.player?.status !== 'Playing') this.playDefault()
    })
  }

  // ---- D-Bus, for ALFRED and scripts

  _export() {
    this._dbus = Gio.DBusExportedObject.wrapJSObject(SERVICE_XML, {
      PlayPause: () => (this.playPause(), true),
      Play: () => (this.play(), true),
      Pause: () => (this.pause(), !!this.player),
      Next: () => (this.next(), !!this.player),
      Previous: () => (this.previous(), !!this.player),
      PlayDefaultAsync: (_params, inv) => {
        this.playDefault().then((ok) => inv.return_value(new GLib.Variant('(b)', [!!ok])))
      },
      PlayUriAsync: ([uri, shuffle], inv) => {
        this.playUri(uri, shuffle).then((ok) => inv.return_value(new GLib.Variant('(b)', [!!ok])))
      },
      Status: () => {
        const p = this.player
        return p ? [p.status, p.title, p.artist, p.identity] : ['NotRunning', '', '', this._idle().name]
      },
    })
    this._dbus.export(Gio.DBus.session, SERVICE_PATH)
    this._nameId = Gio.bus_own_name_on_connection(Gio.DBus.session, SERVICE_NAME, Gio.BusNameOwnerFlags.REPLACE, null, null)
  }

  disable() {
    if (this._nameId) Gio.bus_unown_name(this._nameId)
    this._nameId = 0
    this._dbus?.unexport()
    this._dbus = null
    for (const t of this._timers) GLib.Source.remove(t)
    this._timers.clear()
    this._hider?.stop()
    this._hider = null
    if (this._settingsId) this._settings.disconnect(this._settingsId)
    this._settingsId = 0
    this._hideMediaCard(false)
    this._button?.destroy()
    this._button = null
    this._watch?.destroy()
    this._watch = null
  }
}
