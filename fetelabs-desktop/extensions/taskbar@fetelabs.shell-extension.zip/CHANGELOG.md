# Changelog

## 4.2.3 (version 89): mini player water in the cover's colours, livelier drips

- **The mini player's water matches the artwork.** The tank under the cover
  takes its deep, surface and foam colours from the album art (the bar's own
  wallpaper maths, run on the cover) and fades to the next cover's colours
  when the track changes. Grey covers get grey water. With no art it follows
  the wallpaper as before. The bar's water still follows the wallpaper.
- **Livelier wordmark drips** (Water Panel 2b7c62f). Up to four drips per
  letter (50 instead of 32), slimmer and each a little different in size, flow
  and length. Beats kick the drips under them harder the sharper the hit,
  each drip swings like a pendulum pushed by the slope of the water, drops
  leave with that swing, and a thin ligament of paint snaps back as each drop
  breaks off. More music, more paint, more drops.

## 4.2.2 (version 88): media controls glow with the music

- **The media controls glow like the start button.** In the bar the player
  tile now has the start tile's outline and lights up with the music, in step
  with it. While the popup player is open the paint splash styles it as
  before (cover art colours).
- **The glow contrasts with the water.** Both tiles glow in a vivid colour
  opposite the water's hue (orange on blue water, blue on orange, violet on
  yellow), following the wallpaper as it changes; grey water gets white. It
  used to be the water's own foam colour. Shared code in `tileGlow.js`.

## 4.2.1 (version 87): ArcMenu fork integrated

- **The start button belongs to the task bar.** The live Fetelabs logo (its
  bubbles and liquid follow the music, the tile glows) used to come from the
  separate Fetelabs Menu extension. It now sits first in every task bar panel
  (`startButton.js`, with `logoIcon.js` / `logoDraw.js` from the live-logo
  patch). With no menu attached a click opens the app grid.
- **ArcMenu fork integrated.** Fetelabs ArcMenu (`arcmenu@fetelabs`, a fork of
  ArcMenu 70 with its own settings, translations and D-Bus name) attaches its
  menu to that button through `panel.startButton.setMenuHandler()` and reports
  open/close with `setMenuOpen()`, which lights the tile. It adds no panel
  button of its own while the task bar is on, so there is one start button
  per panel and Super opens the menu once. The menu opens from the button on
  that monitor, towards whichever side the bar is on.
- New **Start Menu** page in the settings, with a link to the Fetelabs ArcMenu
  settings.
- Removed the 4.20 experiment that made the task bar pretend to be Dash to
  Panel (`global.dashToPanel`). ArcMenu ignored it (it checks that the real
  Dash to Panel is running), and it could confuse other extensions.
- The player tile goes right after the start button.
