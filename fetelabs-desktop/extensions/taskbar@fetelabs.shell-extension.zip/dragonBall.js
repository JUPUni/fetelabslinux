// SPDX-License-Identifier: GPL-2.0-or-later
// A Dragon Ball for the Show Desktop button, drawn live: an orange glass ball
// half full of liquid in the ball's own oranges that sloshes with the music
// (the bar's physics, water/physics.js, driven by the analyser levels in
// global.fetelabsTaskbar.waterRaw). The stars sit on top of everything and
// never change: faceted red gems with a white glint, always bright.
//
// With no music the liquid settles and the frame clock stops.

import Cairo from 'cairo'
import Clutter from 'gi://Clutter'
import GLib from 'gi://GLib'
import GObject from 'gi://GObject'
import St from 'gi://St'

import { Liquid } from './water/physics.js'

const BANDS = 18
const STALE_MS = 250 // no water frame for this long: the music has stopped
const REST = 0.36 // calm level (share of the ball's height)
const GAIN = 0.3 // how far the music lifts it (loud music: about the middle)
const CFG = { responsiveness: 0.6, fallSpeed: 0.6, surfaceTension: 0.35, waveHeight: 1, wordmark: false }

// The ball's colours (from the classic four-star ball).
const BODY = [[1, 0.88, 0.42], [1, 0.72, 0.2], [0.96, 0.5, 0.04]] // light, mid, edge
const DEEP = [0.78, 0.18, 0.03]
const SHALLOW = [0.98, 0.45, 0.0]
const FOAM = [1, 0.95, 0.7]
const RIM = [0.76, 0.25, 0.05]
const STAR_LIGHT = [1, 0.27, 0.2]
const STAR_DARK = [0.7, 0.07, 0.07]
// Star centres in ball radii from the middle, as on the ball (slightly
// skewed, as if seen on a sphere), and their size.
const STARS = {
  1: [[0, 0]],
  2: [[-0.24, -0.02], [0.24, 0.02]],
  3: [[-0.26, -0.2], [0.22, -0.16], [-0.02, 0.24]],
  4: [[-0.3, -0.24], [0.22, -0.24], [-0.22, 0.27], [0.3, 0.27]],
  5: [[-0.3, -0.26], [0.22, -0.26], [0, 0], [-0.24, 0.3], [0.28, 0.3]],
  6: [[-0.32, -0.26], [0.04, -0.3], [0.38, -0.2], [-0.3, 0.18], [0.06, 0.24], [0.36, 0.26]],
  7: [[-0.36, -0.28], [0, -0.34], [0.36, -0.26], [-0.2, 0], [0.18, 0.02], [-0.18, 0.34], [0.22, 0.34]],
}
const STAR_R = { 1: 0.34, 2: 0.26, 3: 0.23, 4: 0.23, 5: 0.19, 6: 0.17, 7: 0.16 }

function tracePath(cr, pts) {
  cr.moveTo(pts[0][0], pts[0][1])
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[Math.max(0, i - 1)]
    const p1 = pts[i]
    const p2 = pts[i + 1]
    const p3 = pts[Math.min(pts.length - 1, i + 2)]
    cr.curveTo(
      p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6,
      p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6,
      p2[0], p2[1],
    )
  }
}

// A five-point star as a cut gem: ten facets from the centre, lit from the
// top left, a dark keyline and a white glint.
function drawStar(cr, x, y, r) {
  const pts = []
  for (let i = 0; i < 10; i++) {
    const a = -Math.PI / 2 + (i * Math.PI) / 5
    const rr = i % 2 ? r * 0.45 : r
    pts.push([x + Math.cos(a) * rr, y + Math.sin(a) * rr])
  }
  const light = [-0.6, -0.8] // towards the top left
  for (let i = 0; i < 10; i++) {
    const [ax, ay] = pts[i]
    const [bx, by] = pts[(i + 1) % 10]
    // Facet normal ~ direction of its middle from the centre.
    const mx = (ax + bx) / 2 - x, my = (ay + by) / 2 - y
    const len = Math.hypot(mx, my) || 1
    const lit = Math.max(0, (mx * light[0] + my * light[1]) / len) // 0..1
    const odd = i % 2 // alternate faces of each point
    const t = Math.min(1, lit * 0.8 + (odd ? 0.15 : 0.45))
    cr.moveTo(x, y)
    cr.lineTo(ax, ay)
    cr.lineTo(bx, by)
    cr.closePath()
    cr.setSourceRGB(...STAR_DARK.map((d, k) => d + (STAR_LIGHT[k] - d) * t))
    cr.fill()
  }
  cr.moveTo(...pts[0])
  for (let i = 1; i < 10; i++) cr.lineTo(...pts[i])
  cr.closePath()
  cr.setLineWidth(Math.max(0.6, r * 0.09))
  cr.setSourceRGBA(0.45, 0, 0, 0.7)
  cr.stroke()
  // The glint: a tiny bright spot on the upper left point.
  const g = new Cairo.RadialGradient(x - r * 0.28, y - r * 0.32, 0, x - r * 0.28, y - r * 0.32, r * 0.42)
  g.addColorStopRGBA(0, 1, 1, 1, 0.95)
  g.addColorStopRGBA(1, 1, 1, 1, 0)
  cr.setSource(g)
  cr.arc(x - r * 0.28, y - r * 0.32, r * 0.42, 0, 2 * Math.PI)
  cr.fill()
}

// Draws the ball into a w x h surface; level/back are the liquid's columns
// (0..1 of the ball's height). Shell-free, so tools can render it offline.
export function drawBall(cr, w, h, level, back, stars = 4) {
  const s = Math.min(w, h)
  const cx = w / 2, cy = h / 2
  const R = s / 2 - Math.max(0.75, s * 0.02)

  // Body: the glass ball, lit from the top left.
  const body = new Cairo.RadialGradient(cx - R * 0.3, cy - R * 0.35, R * 0.05, cx, cy, R)
  body.addColorStopRGB(0, ...BODY[0])
  body.addColorStopRGB(0.6, ...BODY[1])
  body.addColorStopRGB(1, ...BODY[2])
  cr.arc(cx, cy, R, 0, 2 * Math.PI)
  cr.setSource(body)
  cr.fill()

  // The liquid inside, clipped to the ball.
  cr.save()
  cr.arc(cx, cy, R, 0, 2 * Math.PI)
  cr.clip()
  const x0 = cx - R, span = 2 * R, top = cy - R, depth = 2 * R
  const n = level.length
  const step = span / (n - 1)
  const surfaceOf = (vals) => Array.from({ length: n }, (_, i) => [x0 + i * step, top + depth * (1 - vals[i])])
  const fillUnder = (pts) => {
    tracePath(cr, pts)
    cr.lineTo(x0 + span, top + depth)
    cr.lineTo(x0, top + depth)
    cr.closePath()
  }
  const layer = (pts, alpha) => {
    fillUnder(pts)
    const g = new Cairo.LinearGradient(0, top + depth, 0, top)
    g.addColorStopRGBA(0, ...DEEP, alpha)
    g.addColorStopRGBA(1, ...SHALLOW, alpha * 0.85)
    cr.setSource(g)
    cr.fill()
  }
  layer(surfaceOf(back), 0.4)
  const front = surfaceOf(level)
  layer(front, 0.85)
  tracePath(cr, front)
  cr.setLineWidth(Math.max(1.3, s * 0.05))
  cr.setSourceRGBA(...FOAM, 1)
  cr.stroke()

  // Depth: the edge of the sphere darkens over body and liquid alike.
  const shade = new Cairo.RadialGradient(cx - R * 0.15, cy - R * 0.15, R * 0.55, cx, cy, R)
  shade.addColorStopRGBA(0, 0.6, 0.15, 0, 0)
  shade.addColorStopRGBA(1, 0.55, 0.12, 0, 0.4)
  cr.setSource(shade)
  cr.paint()
  cr.restore()

  // Rim.
  cr.arc(cx, cy, R, 0, 2 * Math.PI)
  cr.setLineWidth(Math.max(0.8, s * 0.035))
  cr.setSourceRGBA(...RIM, 0.95)
  cr.stroke()

  // Stars: on top, untouched by the liquid.
  const r = R * STAR_R[stars]
  for (const [sx, sy] of STARS[stars]) drawStar(cr, cx + sx * R, cy + sy * R, r)

  // Gloss: a soft white highlight at the top left.
  cr.save()
  cr.translate(cx - R * 0.42, cy - R * 0.52)
  cr.rotate(-Math.PI / 5)
  cr.scale(1, 0.55)
  const gl = new Cairo.RadialGradient(0, 0, 0, 0, 0, R * 0.42)
  gl.addColorStopRGBA(0, 1, 1, 1, 0.9)
  gl.addColorStopRGBA(0.6, 1, 1, 1, 0.45)
  gl.addColorStopRGBA(1, 1, 1, 1, 0)
  cr.setSource(gl)
  cr.arc(0, 0, R * 0.42, 0, 2 * Math.PI)
  cr.fill()
  cr.restore()
}

export const DragonBall = GObject.registerClass(
class DragonBall extends St.DrawingArea {
  _init(size, stars = 4) {
    super._init({ y_align: Clutter.ActorAlign.CENTER, x_align: Clutter.ActorAlign.CENTER })
    this._stars = Math.max(1, Math.min(7, stars | 0))
    this._liquid = new Liquid(BANDS, CFG)
    this._liquid.level.fill(REST)
    this._liquid.back.fill(REST)
    this._liquid.target.fill(REST)
    this._clock = 0
    this._last = 0
    this._lastWater = 0
    this.setSize(size)

    this.connect('repaint', () => this._repaint())
    this._timeline = new Clutter.Timeline({ actor: this, duration: 1000, repeat_count: -1 })
    this._timeline.connect('new-frame', () => this._frame())
    this.connect('notify::mapped', () => {
      if (!this.mapped) this._timeline?.stop()
    })
    this._watchHost()
    // The task bar can be turned off and on (a new global object).
    this._pollId = GLib.timeout_add_seconds(GLib.PRIORITY_LOW, 2, () => {
      if ((global.fetelabsTaskbar ?? null) !== this._host) this._watchHost()
      return GLib.SOURCE_CONTINUE
    })
    this.connect('destroy', () => this._onDestroy())
  }

  setSize(size) {
    const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor
    this.set_size(size * scale, size * scale)
    this.queue_repaint()
  }

  setStars(n) {
    this._stars = Math.max(1, Math.min(7, n | 0))
    this.queue_repaint()
  }

  _watchHost() {
    this._unwatchHost()
    this._host = global.fetelabsTaskbar ?? null
    if (this._host?.connect) this._hostId = this._host.connect('water-frame', () => this._onWater())
  }

  _unwatchHost() {
    if (this._hostId) {
      try {
        this._host?.disconnect(this._hostId)
      } catch {}
    }
    this._hostId = 0
    this._host = null
  }

  _onWater() {
    this._lastWater = GLib.get_monotonic_time() / 1000
    if (this.mapped && this._timeline && !this._timeline.is_playing()) {
      this._last = 0
      this._timeline.start()
    }
  }

  _frame() {
    const now = GLib.get_monotonic_time() / 1000
    const dt = this._last ? Math.min(0.05, Math.max(0, (now - this._last) / 1000)) : 1 / 60
    this._last = now
    this._clock += dt
    const host = this._host
    const raw = now - this._lastWater < STALE_MS ? host?.waterRaw ?? host?.waterLevels : null
    const t = this._liquid.target
    for (let i = 0; i < BANDS; i++) {
      let music = 0
      if (raw?.length) {
        const a = Math.floor((i / BANDS) * raw.length)
        const b = Math.max(a + 1, Math.floor(((i + 1) / BANDS) * raw.length))
        for (let j = a; j < b; j++) music += raw[j]
        music /= b - a
      }
      t[i] = raw ? Math.min(0.94, REST + 0.02 * Math.sin(this._clock * 1.3 + i * 0.5) + GAIN * music) : REST
    }
    this._liquid.step(dt)
    this.queue_repaint()
    if (!raw) {
      // Settled: every column at rest and still.
      const { level, vel } = this._liquid
      let still = true
      for (let i = 0; i < BANDS && still; i++) if (Math.abs(level[i] - REST) > 0.003 || Math.abs(vel[i]) > 0.01) still = false
      if (still) this._timeline.stop()
    }
  }

  _repaint() {
    const cr = this.get_context()
    try {
      const [w, h] = this.get_surface_size()
      drawBall(cr, w, h, this._liquid.level, this._liquid.back, this._stars)
    } finally {
      cr.$dispose()
    }
  }

  _onDestroy() {
    if (this._pollId) GLib.source_remove(this._pollId)
    this._pollId = 0
    this._unwatchHost()
    this._timeline?.stop()
    this._timeline = null
  }
})
