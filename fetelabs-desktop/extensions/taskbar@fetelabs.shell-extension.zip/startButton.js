// SPDX-License-Identifier: GPL-2.0-or-later
// The start button: the live Fetelabs logo (logoIcon.js) in its tile, first
// in the bar. It belongs to the task bar, one per panel (panel.startButton).
// A menu extension (Fetelabs ArcMenu) never adds a button of its own: it
// hangs its menu off this one with setMenuHandler() and reports its open
// state with setMenuOpen(), so the logo and its animations stay ours.
// With no menu attached a click opens the app grid.

import Clutter from 'gi://Clutter'
import GObject from 'gi://GObject'
import St from 'gi://St'

import * as Main from 'resource:///org/gnome/shell/ui/main.js'
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js'

import { LogoIcon } from './logoIcon.js'

export const STATUS_AREA_ID = 'fetelabs-start'

// The logo fills the square tile: the bar minus 2 x (3px tile margin + 1px
// border + 3px padding), so the padding is even on all four sides.
const TILE_INSET = 14
const DEFAULT_PANEL_SIZE = 42

export const StartButton = GObject.registerClass(
  class StartButton extends PanelMenu.Button {
    _init(dtpPanel) {
      // No menu of its own (dontCreateMenu): the menu, if any, is attached.
      super._init(0.5, 'Fetelabs Start', true)
      this.add_style_class_name('fetelabs-start-button')

      this._dtpPanel = dtpPanel
      this._handler = null
      this._iconSize = 0

      this._tile = new St.BoxLayout({
        style_class: 'panel-status-menu-box fetelabs-start',
      })
      this._logo = new LogoIcon(DEFAULT_PANEL_SIZE - TILE_INSET)
      this._tile.add_child(this._logo)
      this.add_child(this._tile)

      // The panel's size can still be 0 at startup: size again once mapped.
      dtpPanel.connectObject(
        'notify::height',
        () => this._adjustIconSize(),
        'notify::width',
        () => this._adjustIconSize(),
        this,
      )
      this.connect('notify::mapped', () => this._adjustIconSize())
      this._adjustIconSize()
    }

    // fn(event) handles presses instead of the app grid and returns a
    // Clutter.EVENT_* value; null gives the button back.
    setMenuHandler(fn) {
      this._handler = fn ?? null
      if (!this._handler) this.setMenuOpen(false)
    }

    // The attached menu's open state lights the tile
    // (.panel-button:active .fetelabs-start in stylesheet.css).
    setMenuOpen(open) {
      if (open) this.add_style_pseudo_class('active')
      else this.remove_style_pseudo_class('active')
    }

    vfunc_event(event) {
      const type = event.type()
      const press =
        type === Clutter.EventType.BUTTON_PRESS ||
        type === Clutter.EventType.TOUCH_BEGIN
      if (!press) return Clutter.EVENT_PROPAGATE

      if (this._handler) return this._handler(event)

      if (
        type === Clutter.EventType.TOUCH_BEGIN ||
        event.get_button() === Clutter.BUTTON_PRIMARY
      ) {
        if (Main.overview.visible) Main.overview.hide()
        else Main.overview.showApps()
      }
      return Clutter.EVENT_PROPAGATE
    }

    _adjustIconSize() {
      if (!this._dtpPanel) return
      const scale = St.ThemeContext.get_for_stage(global.stage).scale_factor
      const panelSize = Math.min(
        this._dtpPanel.get_height(),
        this._dtpPanel.get_width(),
      )
      const size = Math.max(
        16,
        Math.floor(
          (panelSize > 0 ? panelSize / scale : DEFAULT_PANEL_SIZE) - TILE_INSET,
        ),
      )
      if (size === this._iconSize) return
      this._iconSize = size
      this._logo.setSize(size)
    }

    _onDestroy() {
      this._dtpPanel?.disconnectObject(this)
      this._dtpPanel = null
      this._handler = null
      super._onDestroy()
    }
  },
)
