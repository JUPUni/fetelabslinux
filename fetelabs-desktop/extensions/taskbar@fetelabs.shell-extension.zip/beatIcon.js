// SPDX-License-Identifier: GPL-2.0-or-later
// Makes an St.Icon (the Show Desktop button's) move with the music: it kicks
// bigger on the beat and glows in the water's foam colour. The levels come
// from the built-in Water Panel (global.fetelabsTaskbar.waterRaw, announced
// by 'water-frame'); with no music it rests and its frame clock stops.
//
// Only the scale (a transform, no relayout) changes every frame. The glow is
// CSS, so it is restyled in a few steps at most ~12 times a second, like the
// start and player tiles, so nothing in the bar moves.

import Clutter from 'gi://Clutter'
import GLib from 'gi://GLib'

const STALE_MS = 250 // no water frame for this long: the music has stopped
const KICK = 0.22 // extra scale on a full beat
const LEVEL = 0.06 // extra scale from the bass level itself

export class BeatIcon {
  constructor(icon, baseStyle = '') {
    this._icon = icon
    this._baseStyle = baseStyle
    this._bass = 0
    this._avg = 0
    this._kick = 0
    this._lastWater = 0
    this._last = 0
    icon.set_pivot_point(0.5, 0.5)
    this.setBaseStyle(baseStyle)

    this._timeline = new Clutter.Timeline({ actor: icon, duration: 1000, repeat_count: -1 })
    this._timeline.connect('new-frame', () => this._frame())
    this._mappedId = icon.connect('notify::mapped', () => {
      if (!icon.mapped) this._rest()
    })
    this._watchHost()
    // The task bar can be turned off and on (a new global object).
    this._pollId = GLib.timeout_add_seconds(GLib.PRIORITY_LOW, 2, () => {
      if ((global.fetelabsTaskbar ?? null) !== this._host) this._watchHost()
      return GLib.SOURCE_CONTINUE
    })
  }

  setBaseStyle(style) {
    this._baseStyle = style
    this._styleKey = null
    this._icon.set_style(style || null)
  }

  _watchHost() {
    this._unwatchHost()
    this._host = global.fetelabsTaskbar ?? null
    if (this._host?.connect) this._hostId = this._host.connect('water-frame', () => this._onWater())
  }

  _unwatchHost() {
    if (this._hostId) {
      try {
        this._host?.disconnect(this._hostId)
      } catch {}
    }
    this._hostId = 0
    this._host = null
  }

  _onWater() {
    this._lastWater = GLib.get_monotonic_time() / 1000
    if (this._icon.mapped && this._timeline && !this._timeline.is_playing()) {
      this._last = 0
      this._timeline.start()
    }
  }

  _frame() {
    const now = GLib.get_monotonic_time() / 1000
    const dt = this._last ? Math.min(0.05, Math.max(0, (now - this._last) / 1000)) : 1 / 60
    this._last = now
    const raw = now - this._lastWater < STALE_MS ? this._host?.waterRaw ?? this._host?.waterLevels : null

    let bass = 0
    if (raw?.length) {
      const n = Math.max(1, Math.round(raw.length * 0.12))
      for (let i = 0; i < n; i++) bass += raw[i]
      bass /= n
    }
    const ease = (v, cur, up, down) => cur + (v - cur) * (1 - Math.exp(-dt / (v > cur ? up : down)))
    this._bass = ease(bass, this._bass, 0.03, 0.2)
    // A beat = the bass jumping clear of its recent average.
    this._avg = ease(this._bass, this._avg, 0.6, 0.6)
    const hit = Math.min(1, Math.max(0, (this._bass - this._avg * 1.15 - 0.03) * 6))
    this._kick = hit > this._kick ? hit : this._kick * Math.exp(-dt / 0.14)

    const s = 1 + KICK * this._kick + LEVEL * Math.min(1, this._bass * 1.5)
    this._icon.set_scale(s, s)
    this._style(Math.min(1, this._kick * 0.7 + this._bass * 0.6))

    if (!raw && this._bass < 0.005 && this._kick < 0.005) this._rest()
  }

  _style(swell) {
    const key = Math.round(swell * 8)
    if (key === this._styleKey) return
    const now = GLib.get_monotonic_time() / 1000
    if (key && now - (this._styleAt ?? 0) < 80) return
    this._styleAt = now
    this._styleKey = key
    if (!key) {
      this._icon.set_style(this._baseStyle || null)
      return
    }
    const [r, g, b] = (this._host?.waterColors?.foam ?? [1, 0.96, 0.9]).map((v) => Math.round(v * 255))
    const sw = key / 8
    this._icon.set_style(
      this._baseStyle + `icon-shadow: 0 0 ${Math.round(3 + 9 * sw)}px rgba(${r},${g},${b},${(0.35 + 0.6 * sw).toFixed(2)});`,
    )
  }

  _rest() {
    this._timeline?.stop()
    this._bass = this._avg = this._kick = 0
    this._icon.set_scale(1, 1)
    this._style(0)
  }

  destroy() {
    if (this._pollId) GLib.source_remove(this._pollId)
    this._pollId = 0
    this._unwatchHost()
    this._timeline?.stop()
    this._timeline = null
    if (this._mappedId) this._icon.disconnect(this._mappedId)
    this._mappedId = 0
    this._icon.set_scale(1, 1)
  }
}
