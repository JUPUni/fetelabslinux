// SPDX-License-Identifier: GPL-2.0-or-later
// Drawing and motion for the live Fetelabs logo on the start button. No Shell
// imports here, so tools can render it offline.

const hex = (s) => [1, 3, 5].map((i) => parseInt(s.slice(i, i + 2), 16) / 255)
const C = {
    cream: hex('#fff6e6'),
    glass: hex('#2a1f3d'),
    teal: hex('#1fb5a8'),
    lime: hex('#9be22d'),
    pink: hex('#ff2e88'),
    gold: hex('#f4b400'),
}
const BUBBLE_COLOURS = [C.lime, C.gold, C.teal, C.cream, C.pink]

// Same view box as fetelabs-menu-icon.svg.
const VIEW = { x: -17.37, y: -22.38, size: 223.28 }
const MAX_BUBBLES = 26

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v))

function traceTube(cr) {
    cr.moveTo(70, 38)
    cr.lineTo(70, 160)
    cr.arcNegative(100, 160, 30, Math.PI, 0)
    cr.lineTo(130, 38)
    cr.closePath()
}

// One liquid band: a wave across the tube, filled to the bottom.
function traceWave(cr, y, amp, phase) {
    cr.moveTo(40, 220)
    for (let x = 40; x <= 160; x += 4)
        cr.lineTo(x, y + Math.sin(x / 28 * Math.PI + phase) * amp)
    cr.lineTo(160, 220)
    cr.closePath()
}

const circle = (cr, x, y, r) => {
    cr.newSubPath()
    cr.arc(x, y, r, 0, 2 * Math.PI)
}

function roundRect(cr, x, y, w, h, r) {
    cr.newSubPath()
    cr.arc(x + w - r, y + r, r, -Math.PI / 2, 0)
    cr.arc(x + w - r, y + h - r, r, 0, Math.PI / 2)
    cr.arc(x + r, y + h - r, r, Math.PI / 2, Math.PI)
    cr.arc(x + r, y + r, r, Math.PI, 1.5 * Math.PI)
    cr.closePath()
}


export function newLogoState() {
    return { snd: { all: 0, bass: 0, mid: 0, high: 0, kick: 0 }, prevBass: 0, phase: 0, bubbles: [], spawn: 0, t: 0 }
}

function surfaceY(st) {
    return 100 - 34 * st.snd.all - 8 * st.snd.kick
}

// Average the water's band levels into overall, bass, mid and treble.
export function bandsOf(lv) {
    if (!lv?.length)
        return { all: 0, bass: 0, mid: 0, high: 0 }
    const n = lv.length
    const avg = (a, b) => {
        let s = 0
        for (let i = a; i < b; i++) s += lv[i]
        return s / Math.max(1, b - a)
    }
    const b1 = Math.max(1, Math.round(n * 0.15))
    const b2 = Math.round(n * 0.5)
    return { all: avg(0, n), bass: avg(0, b1), mid: avg(b1, b2), high: avg(b2, n) }
}

// One step of motion. Returns true while anything is still moving.
export function swellOf(st) {
    const s = st.snd
    return Math.min(1, 1.5 * s.all + 1.2 * s.bass + 1.5 * s.kick)
}

export function stepLogo(st, raw, dt) {
    if (!(dt > 0))
        return true
    st.t += dt
    const s = st.snd
    for (const k of ['all', 'bass', 'mid', 'high']) {
        // Up fast, down slower, like the water itself.
        const tau = raw[k] > s[k] ? 0.04 : 0.25
        s[k] += (raw[k] - s[k]) * (1 - Math.exp(-dt / tau))
    }
    // A kick: the bass jumping up.
    const jump = (raw.bass - st.prevBass) / dt
    st.prevBass = raw.bass
    if (jump > 4 && raw.bass > 0.3)
        s.kick = 1
    s.kick *= Math.exp(-dt / 0.18)

    // The liquid churns faster the louder it is.
    st.phase += dt * (1.2 + 9 * s.all + 6 * s.bass)

    // Bubbles stream up with the music, and burst out on a kick.
    // Silence: no new bubbles, so it settles and stops drawing.
    if (s.all > 0.02)
        st.spawn += dt * (2 + 40 * s.all ** 1.2)
    if (s.kick > 0.95)
        st.spawn += 4
    while (st.spawn >= 1) {
        st.spawn -= 1
        if (st.bubbles.length < MAX_BUBBLES) {
            const r = 2 + Math.random() * (2.5 + 4 * s.bass)
            st.bubbles.push({
                x: 78 + Math.random() * 44,
                y: 180 + Math.random() * 6,
                r,
                vy: -(40 + 160 * s.all + Math.random() * 40),
                wob: Math.random() * 6.28,
                c: BUBBLE_COLOURS[Math.floor(Math.random() * BUBBLE_COLOURS.length)],
            })
        }
    }
    const surface = surfaceY(st)
    for (const b of st.bubbles) {
        b.y += b.vy * dt * (1 + 1.5 * s.mid)
        b.wob += dt * (4 + 10 * s.high)
        b.x += Math.sin(b.wob) * dt * 18
    }
    // Bubbles pop at the surface.
    st.bubbles = st.bubbles.filter((b) => b.y > surface - 4)

    return !(s.all < 0.004 && s.kick < 0.01 && !st.bubbles.length)
}

// Draws the logo filling a w x h surface.
export function drawLogo(cr, w, h, st) {
    const s = st.snd
    const scale = Math.min(w, h) / VIEW.size
    cr.scale(scale, scale)
    cr.translate(-VIEW.x, -VIEW.y)

    cr.translate(100, 110)
    // A little sway on the beat.
    cr.rotate((-12 + 4 * s.kick * Math.sin(st.t * 20)) * Math.PI / 180)
    cr.translate(-100, -110)

    const fill = (c, a = 1) => {
        cr.setSourceRGBA(...c, a)
        cr.fill()
    }

    // Glass (no outline).
    traceTube(cr)
    fill(C.glass)

    cr.save()
    traceTube(cr)
    cr.clip()
    const top = surfaceY(st)
    const amp = 8 + 14 * s.bass + 10 * s.kick
    const ph = st.phase
    traceWave(cr, top, amp, ph)
    fill(C.teal)
    traceWave(cr, top + 32 - 10 * s.mid, amp * 0.85, ph * 1.3 + 2)
    fill(C.lime)
    traceWave(cr, top + 62 - 12 * s.bass, amp * 0.7, ph * 0.8 + 4)
    fill(C.pink)
    // Bubbles rising through it.
    for (const b of st.bubbles) {
        circle(cr, b.x, b.y, b.r)
        fill(b.c, 0.9)
        circle(cr, b.x - b.r * 0.35, b.y - b.r * 0.35, b.r * 0.3)
        fill(C.cream, 0.7)
    }
    // The resting bubble from the logo.
    circle(cr, 90, 74 + (100 - top) * 0.3, 5 * (1 + 0.4 * s.mid))
    fill(C.lime)
    cr.restore()

    circle(cr, 110, 60, 3.5 * (1 + 0.5 * s.high))
    fill(C.gold)
    roundRect(cr, 64, 30, 72, 12, 6)
    fill(C.cream)
    cr.setLineWidth(5)
    cr.setLineCap(1) // Cairo.LineCap.ROUND
    cr.moveTo(82, 56)
    cr.lineTo(82, 84)
    cr.moveTo(82, 96)
    cr.lineTo(82, 102)
    cr.setSourceRGBA(...C.cream, 1)
    cr.stroke()

    // The bubbles above the tube bob and swell: bass, mid, treble.
    const bob = (k, f) => Math.sin(st.t * f + k) * (2 + 8 * s.all)
    circle(cr, 94, 18 + bob(0, 5), 6 * (1 + 0.6 * s.bass + 0.4 * s.kick))
    fill(C.teal)
    circle(cr, 112 + bob(1, 4) * 0.5, 4 + bob(2, 6) - 6 * s.mid, 4 * (1 + 0.7 * s.mid))
    fill(C.pink)
    circle(cr, 100 + bob(3, 3) * 0.5, -10 + bob(4, 7) - 8 * s.high, 3 * (1 + 0.9 * s.high))
    fill(C.pink)


}
