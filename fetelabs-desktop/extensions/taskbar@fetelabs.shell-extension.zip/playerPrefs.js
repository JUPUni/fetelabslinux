// SPDX-License-Identifier: GPL-2.0-or-later
// The Player page of the task bar's settings: which media apps the player
// follows (add or remove them), and what happens at login.

import Adw from 'gi://Adw'
import Gio from 'gi://Gio'
import GLib from 'gi://GLib'
import Gtk from 'gi://Gtk'

const MPRIS_PREFIX = 'org.mpris.MediaPlayer2.'

// A media ID's app, if it is installed: name and icon for the list.
function appFor(id) {
  for (const name of [`${id}.desktop`, `org.gnome.${id[0]?.toUpperCase()}${id.slice(1)}.desktop`]) {
    try {
      const info = Gio.DesktopAppInfo.new(name)
      if (info) return info
    } catch {}
  }
  return null
}

const switchRow = (settings, key, title, subtitle) => {
  const row = new Adw.SwitchRow({ title, subtitle: subtitle ?? '' })
  settings.bind(key, row, 'active', Gio.SettingsBindFlags.DEFAULT)
  return row
}

export function playerPage(settings) {
  const page = new Adw.PreferencesPage({ title: 'Player', icon_name: 'multimedia-player-symbolic' })

  const show = new Adw.PreferencesGroup({
    title: 'Media controls',
    description: 'Back, play and next at the start of the task bar. Click the app icon for the track, cover and more; double-click it to open the app.',
  })
  show.add(switchRow(settings, 'player-enabled', 'Show the player'))
  show.add(switchRow(settings, 'player-hide-notification', 'Hide the media card in the calendar', 'The player already shows it'))
  page.add(show)

  // ---- the list of apps

  const apps = new Adw.PreferencesGroup({
    title: 'Media apps',
    description: 'The player follows these apps and nothing else. The first one starts when you press play while none is running.',
  })
  page.add(apps)
  const rows = []
  const addEntry = new Adw.EntryRow({ title: 'Add an app by its media name (e.g. vlc, firefox)', show_apply_button: true })

  const strv = () => settings.get_strv('player-apps')
  const add = (id) => {
    id = id.trim().toLowerCase().replace(new RegExp(`^${MPRIS_PREFIX.replace(/\./g, '\\.')}`), '').split('.')[0]
    if (id && !strv().includes(id)) settings.set_strv('player-apps', [...strv(), id])
  }

  const rebuild = () => {
    for (const r of rows.splice(0)) apps.remove(r)
    if (addEntry._added) apps.remove(addEntry)
    addEntry._added = true
    const list = strv()
    list.forEach((id, i) => {
      const info = appFor(id)
      const row = new Adw.ActionRow({ title: info?.get_name() ?? id, subtitle: i === 0 ? `${id} · starts when you press play` : id })
      const icon = new Gtk.Image({ gicon: info?.get_icon() ?? Gio.ThemedIcon.new('multimedia-player-symbolic'), pixel_size: 32 })
      row.add_prefix(icon)
      if (i > 0) {
        const up = new Gtk.Button({ icon_name: 'go-up-symbolic', valign: Gtk.Align.CENTER, tooltip_text: 'Move up' })
        up.add_css_class('flat')
        up.connect('clicked', () => {
          const l = strv()
          ;[l[i - 1], l[i]] = [l[i], l[i - 1]]
          settings.set_strv('player-apps', l)
        })
        row.add_suffix(up)
      }
      const del = new Gtk.Button({ icon_name: 'user-trash-symbolic', valign: Gtk.Align.CENTER, tooltip_text: 'Remove' })
      del.add_css_class('flat')
      del.connect('clicked', () => settings.set_strv('player-apps', strv().filter((x) => x !== id)))
      row.add_suffix(del)
      apps.add(row)
      rows.push(row)
    })
    apps.add(addEntry)
    refreshRunning()
  }
  addEntry.connect('apply', () => {
    add(addEntry.text)
    addEntry.text = ''
  })

  // ---- apps playing right now that are not on the list, one click to add

  const running = new Adw.PreferencesGroup({
    title: 'Playing on this computer',
    description: 'Media apps running right now that the player does not follow yet.',
  })
  page.add(running)
  const runRows = []
  function refreshRunning() {
    Gio.DBus.session.call('org.freedesktop.DBus', '/org/freedesktop/DBus', 'org.freedesktop.DBus', 'ListNames',
      null, null, Gio.DBusCallFlags.NONE, 2000, null, (bus, res) => {
        let names = []
        try {
          names = bus.call_finish(res).deepUnpack()[0]
        } catch {}
        for (const r of runRows.splice(0)) running.remove(r)
        const list = strv()
        const found = [...new Set(names.filter((n) => n.startsWith(MPRIS_PREFIX))
          .map((n) => n.slice(MPRIS_PREFIX.length).split('.')[0].toLowerCase()))].filter((id) => !list.includes(id))
        for (const id of found) {
          const info = appFor(id)
          const row = new Adw.ActionRow({ title: info?.get_name() ?? id, subtitle: id })
          row.add_prefix(new Gtk.Image({ gicon: info?.get_icon() ?? Gio.ThemedIcon.new('multimedia-player-symbolic'), pixel_size: 32 }))
          const b = new Gtk.Button({ label: 'Add', valign: Gtk.Align.CENTER })
          b.connect('clicked', () => add(id))
          row.add_suffix(b)
          running.add(row)
          runRows.push(row)
        }
        running.visible = found.length > 0
      })
  }

  // ---- login

  const login = new Adw.PreferencesGroup({
    title: 'At login',
    description: 'Start the first media app and play, without its window getting in the way.',
  })
  login.add(switchRow(settings, 'player-autoplay', 'Start playing at login'))
  const uri = new Adw.EntryRow({ title: 'What to play (Spotify link; empty = your Liked Songs)', show_apply_button: true })
  settings.bind('player-autoplay-uri', uri, 'text', Gio.SettingsBindFlags.GET)
  uri.connect('apply', () => settings.set_string('player-autoplay-uri', uri.text.trim()))
  login.add(uri)
  login.add(switchRow(settings, 'player-autoplay-shuffle', 'Shuffle'))
  login.add(switchRow(settings, 'player-hide-window', "Keep the app's window out of the way", 'Minimise it when the player starts it'))
  page.add(login)

  const id = settings.connect('changed::player-apps', rebuild)
  page.connect('destroy', () => settings.disconnect(id))
  page.connect('map', () => GLib.idle_add(GLib.PRIORITY_DEFAULT, () => (refreshRunning(), GLib.SOURCE_REMOVE)))
  rebuild()
  return page
}
